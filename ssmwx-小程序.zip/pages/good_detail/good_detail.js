//import { request } from "../../request/index2.js";
const { request } = require('../../request/index.js')
Page({
  data: {
    tabs: [{
      id: 0,
      name: '商品描述',
      isActive: true
  }, {
      id: 1,
      name: '留言评论',
      isActive: false
  }
    ],
    address:{},
    cart:[],
    cartNow:{},//立即购买
    userInfo: {},
    goodsDetail:[],
    isCollect: false,   //是否收藏
    goodsId:0,
  },
  Goods:{},
  GoodsNow:{},
  Id:0,
  onShow: function (options) {
    const address = wx.getStorageSync('address');
    const cart = wx.getStorageSync('cart') || [];
    const cartNow = wx.getStorageSync('cartNow');
    var userInfo = wx.getStorageSync('userInfo');
    let pages = getCurrentPages();
    let id1 = pages[pages.length - 1].options.id;
    console.log(id1);
    this.setData({
      userInfo:userInfo,
      address:address,
      cart:cart,
      goodsId:id1,
      cartNow:cartNow,  
    })
    this.getGoodsDetail(id1);
  },
  async getGoodsDetail(id2){
    let res = await request({ url: "/good/"+id2 });
    let goodsDetail =res.good;
    console.log(goodsDetail);
    this.Goods=res.good;
    this.Id=goodsDetail.id;
    const id=goodsDetail.id;
    //获取缓存中商品收藏数组
    let collect=wx.getStorageSync("collect")||[];
    let index=collect.some(v=>v.id===this.Goods.id);
    this.setData({
    goodsDetail:res,
    isCollect: index !== -1 ? false:true
    })
  },
  // 获取商品详情数据
  // getGoodsDetail(id){
  //   request({
  //     url:"http://localhost:8888/ssmShop/good/"+id
  //   })
  //   .then(res=>{
  //   //  console.log(res.data.extend.good);
  //     this.Goods=res.data.extend.good;
  //     this.Id=res.data.extend.good.id;
  //     const id=res.data.extend.good.id;
  //    //获取缓存中商品收藏数组
  //     let collect=wx.getStorageSync("collect")||[];
  //     let index=collect.some(v=>v.id===this.Goods.id);
  //     this.setData({
  //       goodsDetail:res.data.extend,
  //       isCollect: index !== -1 ? false:true
  //     })
  //     let goods = this.data.goodsDetail;
  //   let newArr1=[];
  //   goods.forEach(function(item){
  //     if(item.status == 0){
  //       console.log("11111111111");
  //      this.setData({status:'该商品已下架！'})
  //       //  newArr1.push({
  //       //    status:item.status==0?'该商品已下架！':'',
  //       //  })
  //     }
  //   });

  //   })
  // },
  //点击加入购物车
  //加入购物车
  addCart(){
    var status=this.data.goodsDetail.good;
   // console.log("a:"+a.good.status);
    if(this.data.userInfo.id){
      console.log(this.data.userInfo.id);
      //console.log("购物车");
        if(this.data.goodsDetail.good.status==1){
          console.log("this.data.goodsDetail"+this.data.goodsDetail[0]);
          let cart=wx.getStorageSync("cart")||[];
          let index=cart.findIndex(v=>v.id===this.Goods.id);
          if(index===-1){
            this.Goods.num=1
            this.Goods.checked = true
            cart.push(this.Goods)
          }
          wx.setStorageSync("cart", cart);
          wx.showToast({
            title: '加入购物车成功',
            icon: 'success',
            mask:true
          })
        }else {
          wx.showToast({
            title: '该商品已下架,不能加入购物车！',
            icon:'none'
          })
        }
    }else{
      wx.navigateTo({
        url: '/pages/user/login/login',
      })
    }
  },
   //点击收藏
    collectHandle() {
      if(this.data.userInfo.id){
        let isCollect = false;
        let collect = wx.getStorageSync("collect") || [];
        console.log(collect);
        let index = collect.findIndex(v => v.id === this.Goods.id)
        if (index !== -1) {
            collect.splice(index, 1)
            isCollect = false
            wx.showToast({
              title: '取消收藏',
              icon: 'none',
              mask: true,
            });
        } else {
          isCollect = true
          collect.push(
            this.Goods
        );
        
        wx.showToast({
          title: '收藏成功',
          icon: 'none',
          mask: true,
        });
        }
        wx.setStorageSync("collect", collect);
        this.setData({ isCollect:isCollect });
    
      }else{
        wx.setStorageSync('collect', '')
        wx.showToast({
          title: '您还未登录哦~',
          icon: 'none',
          mask: true,
        });
      }
      
    },
    //点击查看评论
    viewComment(){
      let id=this.data.goodsId;
      console.log("goodId:"+this.data.goodsId);
      console.log('评论');
      wx.navigateTo({
       url: '/pages/comments/comments?goodId='+id,
      })
    },
    //立即购买
    buyNow(){
      if(this.data.userInfo.id){
       if(this.data.goodsDetail.good.status==1){
        let cartNow=wx.getStorageSync("cartNow")||[];
        let index=cartNow.findIndex(v=>v.id===this.Goods.id);
        if(index===-1){
          this.Goods.num=1
          this.Goods.checked = true
          cartNow.push(this.Goods)
        }
        wx.setStorageSync("cartNow", cartNow);
        wx.navigateTo({
          url: '/pages/pay2/pay2',
        })
       }else{
         wx.showToast({
           title: '该商品已下架,不能购买！',
           icon:'none'
         })
       }
      }else{
        wx.navigateTo({
          url: '/pages/user/login/login',
        })
      }
      
    },
    handleTabsItemChange(e){
      //1 获取被点击事件标题索引
      const {index}=e.detail;
      //2 修改原数组
      let {tabs}=this.data;
      tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
      //3 赋值到data中
      this.setData(
        {tabs}
      )
    }, 

    //客服
    chat(e){
      console.log("客服");
      let id = e.currentTarget.dataset.id;
      let id2 = e.currentTarget.dataset.cid;
     console.log("detail-userId:"+id);
     console.log("detail-userId:"+id2);
      wx.navigateTo({
        url: '/pages/chat/chat?userId='+id+'&goodId='+id2,
      })
    }


})