/**
 * 1 页面打开时候 onShow
 *      onShow无法在形参上获取参数
 *      获url上的参数type
 *      根据type 去发送请求获取订单数据
 *      渲染页面
 * 2 点击不同标题
 *      重新发送请求获取数据和页面渲染
 * 
 */
 import regeneratorRuntime from '../../lib/runtime/runtime';
 const { request } = require('../../request/index.js')
 var app=getApp();
Page({
  data: {
    tabs:[
      {
        id:0,
        name:"全部",
        isActive:true
      },
      {
        id:1,
        name:"我发布",
        isActive:false
      },
      {
        id:2,
        name:"我卖出",
        isActive:false
      },
      {
        id:3,
        name:"我买到的",
        isActive:false
      }
    ],
    goods:[],
    userInfo:{}
  },
  onShow(options){

    //console.log(options);
    //1获取当前小程序页面栈-数组 长度最大是10页面
    let pages= getCurrentPages();
    //console.log(pages);
    //2数组中最大页面就是当前页面
    let currentPage=pages[pages.length-1]
    //console.log(currentPage.options);
    //3获取页面上的参数
    const {type}=currentPage.options;
    //4激活选中标题 type=1 index=0
    this.changeTitle(type-1);
    this.getGoods(type);

  },
  //获取订单列表的方法
  async getGoods(type){
    
    var userInfo=app.userInfo;
    const res=await request({url:"/goods1",data:{type}});
    
    this.setData({
      goods:res.goods,
      userInfo:userInfo
    })
   },
  onLoad: function (options) {
    this.onShow(options);
  },
  
  changeTitle(index){
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    this.changeTitle(index);
    //2重新发送请求 type=1 index=0
    this.getGoods(index+1);
  }

})