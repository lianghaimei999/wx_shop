// pages/collect/collect.js
Page({
    data: {
        tabs: [{
            id: 0,
            name: '店铺收藏',
            isActive: true
        }, {
            id: 1,
            name: '商品收藏',
            isActive: false
        }, {
            id: 2,
            name: '浏览足迹',
            isActive: false
        }],
        //收藏数据
        collect: [],
        userInfo:{}
    },
      onShow: function(options) {
          const userInfo = wx.getStorageSync('userInfo');
          const collect = wx.getStorageSync('collect');
          if(!userInfo.id){
            const collect = wx.setStorageSync('collect', []);
          }
          this.setData({ collect,userInfo});
          let pages= getCurrentPages();
   //console.log(pages);
   //2数组中最大页面就是当前页面
   let currentPage=pages[pages.length-1]
   //console.log(currentPage.options);
   //3获取页面上的参数
   const {type}=currentPage.options;
   //4激活选中标题 type=1 index=0
   this.changeTitle(type-1);
      },
      //Tabs切换
      changeTitle(index){
        //2 修改原数组
        let {tabs}=this.data;
        tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
        //3 赋值到data中
        this.setData(
          {tabs}
        )
      },
      //标题点击事件，从子组件传递过来
      handleTabsItemChange(e){
        //1 获取被点击事件标题索引
        const {index}=e.detail;
        this.changeTitle(index);
        //2重新发送请求 type=1 index=0
        
      }
     
     })