import regeneratorRuntime from '../../../lib/runtime/runtime';
const { request } = require('../../../request/index.js')
Page({
  data: {
    list:[],
    goodList:[]
  },
  onLoad: function (options) {
    this.getGoodsList()
  },
  onShow: function () {
  },

  //获取商品列表数据
  async getGoodsList() {
      let res = await request({ url: "/goods1" });
      let goodList = res.goods;
      this.setData({
        goodList:goodList
      })
      console.log(goodList);
      let newArr=[];
      goodList.forEach(function(item){
        if(item.catelog.name==="美妆衣物"){
          newArr.push({
            id:item.id,
            catelogId:item.catelogId,
            goodName:item.goodName,
            startTime:item.startTime,
            realPrice:item.realPrice,
            price:item.price,
            imgUrl1:item.imgUrl1,
            describle:item.describle,
            status:item.status
          })
        }
      })
      this.setData({
        list:newArr,
      })
      console.log(newArr);
  },
 
})