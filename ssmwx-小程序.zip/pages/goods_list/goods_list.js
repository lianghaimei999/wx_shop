import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({
  data: {
     //Tabs数据
     tabs: [{
      id: 0,
      name: '全部',
      isActive: true
  },

{
  id: 1,
  name: '推荐',
  isActive: false
}

    ],
     //商品列表数据
     goodList: [],
     list1:[],
     list2:[],
     list3:[],
     list4:[],
     list5:[],
     list6:[],
     
  },
  Goods:[],
  onLoad: function (options) {
    this.getGoodsList()
  },
   //Tabs切换
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },

   //获取商品列表数据
  async getGoodsList() {
    let res = await request({ url: "/goods1" });
    let goodList = res.goods;
    this.Goods=res.goods;
    //console.log(goodList);
    this.setData({
      goodList:goodList
    })
    let newArr1=[];let newArr2=[];let newArr3=[];let newArr4=[];let newArr5=[];let newArr6=[];
    goodList.forEach(function(item){
      if(item.catelog.name==="手机数码"){
        newArr1.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          startTime:item.startTime,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1
        })
      }else if(item.catelog.name==="校园代步"){
        newArr2.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1,
          startTime:item.startTime,
        })
      }else if(item.catelog.name==="电器日用"){
        newArr3.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1,
          startTime:item.startTime,
        })
      }else if(item.catelog.name==="图书教材"){
        newArr4.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1,
          startTime:item.startTime,
        })
      }else if(item.catelog.name==="美妆衣物"){
        newArr5.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1,
          startTime:item.startTime,
        })
      }else if(item.catelog.name==="球琴棋牌"){
        newArr6.push({
          catelogId:item.catelogId,
          goodName:item.goodName,
          realPrice:item.realPrice,
          imgUrl1:item.imgUrl1,
          startTime:item.startTime
        })
      }
    })
    this.setData({
      list1:newArr1,
      list2:newArr2,
      list3:newArr3,
      list4:newArr4,
      list5:newArr5,
      list6:newArr6,
    })
    console.log(newArr2);
    // newArr=this.goodList.find((item) => {
    //   if(item.catelogId===1){
    //     return item
    //   }
    // })
    // console.log("newArr"+newArr);
    
},

})
