// pages/user/updateInfo/updateInfo.js
Page({

  data: {
    userInfo:{},
    pwd:'',
    msg:''
  },


  onLoad: function (options) {
    
  },

  pwdInput(e){
    var pwd = e.detail.value;
    console.log(pwd);
      this.setData({
        pwd:e.detail.value
      })
  },
 
  onShow: function () {
    var userInfo = wx.getStorageSync('userInfo');
    console.log(userInfo);
    this.setData({
      userInfo:userInfo
    })
  },
  updatePwd(){
    var that=this
    console.log("修改密码");
    var pwd=that.data.pwd;
    var pwd1=that.data.userInfo.password;
    var id= that.data.userInfo.id
    if(pwd!=pwd1 && pwd.length!=0){
      wx.request({
        url: "http://localhost:8888/ssmShop/emp/"+id,
        data: {
          password:pwd
        },
        method: 'PUT', 
        header:{
          'content-type':'application/x-www-form-urlencoded'
        },
        success: function(res){
          if(res.data.code==100){
            console.log("修改密码成功");
            wx.showToast({
              title: '修改成功请重新登录!',
            })
            that.setData({msg:''})
            wx.setStorageSync('userInfo',''); 
          }
        }
      })
    }else if(pwd.length==0){
      console.log("新密码不能为空");
      this.setData({msg:'新密码不能为空'})
    }else{
      console.log("新密码不能与原密码相同");
      this.setData({msg:'新密码不能与原密码相同'})
    }
  }

})