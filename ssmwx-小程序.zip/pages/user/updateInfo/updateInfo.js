// pages/user/updateInfo/updateInfo.js
Page({

  data: {
    userInfo:{},
    phone:'',
    qq:'',
    msg:''
  },


  onLoad: function (options) {
   
    
  },

  phoneInput(e){
    var phone = e.detail.value;
    console.log(phone);
      this.setData({
        phone:e.detail.value
      })
  },
  qqInput(e){
    var qq = e.detail.value;
    console.log(qq);
      this.setData({
        qq:e.detail.value
      })
  },
  onShow: function () {
    var userInfo = wx.getStorageSync('userInfo');
    console.log(userInfo);
    this.setData({
      userInfo:userInfo
    })
  },
  savePwd(){
    console.log("修改密码");
  }

})