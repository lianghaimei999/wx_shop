// pages/login/login.js
Page({
  data: {
  },
  //登陆
  handleGetUserInfo(e) {
    wx.getSetting({
      withSubscriptions: true,
      success(res){
        if(res.authSetting['scope.userInfo']){
          console.log("已经授权");
          const { userInfo } = e.detail;
          console.log(userInfo);
          wx.setStorageSync('userinfo', userInfo);
          wx.navigateBack({
              delta: 1
          });
        }
        
      },
      fail(res){
        console.log("授权失败");
      }
    })
     
  }
})