import { request } from "../../../request/index2.js";
 Page({
  data: {
    phone:"",
    password:"",
    repassword:"",
    message:"",
    logininfo:[],
    phoneinfo:""
  },
  Info:[],
  userInfo:[],
 
  onLoad: function (options) {
   
  },
  // 获取输入手机号
  phoneInput(e){
    var phone = e.detail.value;
      this.setData({
        phone:e.detail.value
      })
  },
  // 获取输入密码
  passwordInput(e){
    var password=e.detail.value;
      this.setData({
        password:e.detail.value
      }) 
  },
  // 获取确认密码
  repasswordInput(e){
    var repassword=e.detail.value;
    console.log(repassword);
      this.setData({
        repassword:e.detail.value
      }) 
  },
  //点击注册
  res(){
    var that=this;
    var p=this.data.phone;
    var pwd=this.data.password;
    var repwd=this.data.repassword;
    var regPhone = /^1\d{10}$/;
    
      if(p.length==0&&pwd.length == 0&&repwd.length == 0){
        wx.showToast({
          title: '未输入信息',
          duration: 1000
        })
      }else if(p.length == 0 && p.length==""){
        wx.showToast({
          title: '用户名不能为空',
          duration: 1000
        })
      }else if(pwd.length == 0 && pwd.length == ""){
        wx.showToast({
          title: '密码不能为空',
          duration: 1000
        })
      }else if(!regPhone.test(p)){
        wx.showToast({
          title: '手机号输入错误',
          duration: 1000
        })
      }else if(pwd != repwd){
        wx.showToast({
          title: '两次密码不一致',
          duration: 1000
        })
      }else{
        //校验通过，发送请求 查询有无相同手机号，不同则注册
       console.log("p:"+p);
        wx.request({
          url: "http://localhost:8888/ssmShop/checkphone",
          data: {
            phone: p,
          },
          method: 'GET', 
          success: function(res){
            console.log(res);
            if(res.data.code==200){
              console.log("手机号已存在");
              that.setData({phoneinfo:"手机号已注册过！"})
   
            }else{
              
              wx.request({
                url: "http://localhost:8888/ssmShop/emp",
                data: {
                  phone: p,
                  password:pwd
                },
                method: 'POST', 
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: function(res){
                  console.log(res);
                  that.setData({phoneinfo:"注册成功！"})
                  wx.showToast({
                    title: '注册成功',
                    icon: 'success',
                    mask: true,
                  });
                  wx.navigateTo({
                    url: '/pages/user/login/login',
                  })
                }
              })
            }
          }
        })
      }
    
   
  }
})