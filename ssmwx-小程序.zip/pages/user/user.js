// pages/user/user.js
var app=getApp();
Page({
  data: {
    userInfo: {},
    userinfo:{},
    goodList:[],
    userList:[],
    //收藏数量
    collectNumber: 0
  },
  onShow:function(){
    var userInfo = wx.getStorageSync('userInfo');
    const collect = wx.getStorageSync('collect') || [];
    const userinfo = wx.getStorageSync('userinfo');
    app.userInfo;
    this.setData({
      userInfo:userInfo,
      collectNumber: collect.length,
      userinfo:userinfo
    })
  },
  //商品列表
  getGoodsList(){
    request({
      url:"http://localhost:8888/ssmShop/goods1"
    })
    .then(res=>{
      let goodList=res.data.extend.goods;
      this.Info=res.data.extend.goods;
      this.setData({
        goodList:goodList
      })
    })
  },
  //获取用户数据
  getUsersList(){
    request({
      url:"http://localhost:8888/ssmShop/emps1"
    })
    .then(res=>{
      //this.Goods=res.data.extend.goods;
      //console.log(res.data);
      let userList=res.data.extend.users;
      this.userInfo=res.data.extend.users;
      
      this.setData({
        userList:userList
      })
    })
  },
  bindClear: function (e) {
     let userInfo= wx.setStorageSync('userInfo', '')
    
    this.setData({
      userInfo:userInfo
    })
    wx.showModal({
      title: '提示',
      content: '退出账号成功',
      success: function(){
        wx.switchTab({
          url: '/pages/index/index',
        })
      }
    })
  },
  updatepwd(){
    console.log("修改密码");
    let userInfo=this.data.userInfo;
    if(userInfo.id){
      wx.navigateTo({
        url: '/pages/user/updatePwd/updatePwd',
      })
    }else{
      wx.showToast({
        title: '请先登录',
        icon:'none'
      })
    }
  }

})