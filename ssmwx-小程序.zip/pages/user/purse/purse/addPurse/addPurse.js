// pages/user/purse/purse/addPurse/addPurse.js
Page({
  data: {
    amount:''
  },
  onLoad: function (options) {
  },
  onShow: function () {
  },
  // 获取输入密码
  amount(e){
    var amount=e.detail.value;
    console.log(amount);
      this.setData({
        amount:e.detail.value
      }) 
  },
  bindSave: function (e) {
    var that = this;
    var amount = that.data.amount;
    if (amount == "" || amount*1 <= 0) {
    wx.showModal({
    title: '错误',
    content: '请填写正确的充值金额',
    showCancel: false
    })
    
    return
    }
   // wxpay.wxpay(app, amount, 0, "/pages/my/index");
    
    }
})