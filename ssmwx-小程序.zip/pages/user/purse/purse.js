import regeneratorRuntime from '../../../lib/runtime/runtime';
const { request } = require('../../../request/index.js')
Page({

  data: {
    userInfo:{},
    purse:{}
  },

  onLoad: function (options) {
    this.getPurse()
  },

  onShow: function () {
    var userInfo = wx.getStorageSync('userInfo');
    this.setData({userInfo})
  },
  async getPurse(){
    const res=await request({url:"/purse"});
    let userInfo=this.data.userInfo
    let purse=res.purse;
    let newArr1=[];
    purse.forEach(function(item){
      if(userInfo.id==item.userId){
        newArr1.push({
          id:item.id,
          userId:item.userId,
          balance:item.balance,
          recharge:item.recharge,
          withdrawals:item.withdrawals,
          state:item.state,
          user:item.user
        })
      }
    })
    this.setData({
      purse:newArr1
    })
    var p=this.data.purse
    wx.setStorageSync('purse', p)
    console.log(p);
  }

})