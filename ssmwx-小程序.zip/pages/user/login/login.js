import { request } from "../../../request/index2.js";
 Page({
  data: {
    tabs:[
      {
        id:0,
        name:"注册",
        isActive:true
      },
      {
        id:1,
        name:"登录",
        isActive:false
      },
    ],
    phone:"",
    password:"",
    message:"",
    logininfo:[]
  },
  Info:[],
  userInfo:[],
  phone:"",
  password:"",
  repassword:"",
  name:"",
  phoneinfo:"",
  msg1:"",
  msg2:"",
  msg3:"",
  msg4:"",
 
  onLoad: function (options) {
   
  },
  // 获取输入手机号
  phoneInput(e){
    var phone = e.detail.value;
    console.log(phone);
      this.setData({
        phone:e.detail.value
      })
  },
  nameInput(e){
    var name = e.detail.value;
    console.log(name);
      this.setData({
        name:e.detail.value
      })
  },
  // 获取输入密码
  passwordInput(e){
    var password=e.detail.value;
    console.log(password);
      this.setData({
        password:e.detail.value
      }) 
  },
  // 获取确认密码
  repasswordInput(e){
    var repassword=e.detail.value;
    console.log(repassword);
      this.setData({
        repassword:e.detail.value
      }) 
  },
  //点击登录
  login(){
    if(this.data.phone.length==0&&this.data.password.length == 0){
      wx.showToast({
        title: '未输入信息',
        duration: 1000
      })
    }else if(this.data.phone.length == 0 && this.data.phone.length==""){
      wx.showToast({
        title: '用户名不能为空',
        duration: 1000
      })
    }else if(this.data.password.length == 0 && this.data.password.length == ""){
      wx.showToast({
        title: '密码不能为空',
        duration: 1000
      })
    }else{
      //校验通过，发送登录请求
      wx.request({
        url: "http://localhost:8888/ssmShop/login",
        data: {
          phone: this.data.phone,
          password: this.data.password,
        },
        method: 'GET', 
        success: function(res){
          
          console.log(res);
          if(res.data.code==100){
            console.log("调用成功");
            console.log(res.data.extend.userInfo);
            // wx.showToast({
            //   title: '登陆成功',
            // })
            //登录成功返回主页信息
             var userInfo = res.data.extend.userInfo;
             wx.setStorageSync('userInfo', userInfo);

             wx.switchTab({
               url: '/pages/user/user',
             })
          }else{
            wx.showModal({
              title: '提示',
              content:'用户名或者密码错误',
              showCancel:false
            })
          }
        }
      })
      
    

    }
  },
   //点击注册
   res(){
    var that=this;
    var p=that.data.phone;
    var pwd=that.data.password;
    var name=that.data.name;
    var repwd=that.data.repassword;
    var regPhone = /^1\d{10}$/;
    
      if(p.length==" "&& pwd.length == " "&&repwd.length == ""&&name.length==""){
        wx.showToast({
          title: '未输入信息',
          icon:'none',
          duration: 1000
        })
      }else if(p.length == 0 && p.length==""){
        that.setData({msg1:"账号不能为空"})
        
      }else if(!regPhone.test(p)){
        that.setData({msg:"手机号格式输入错误"})
       
      }else if(name.length == 0 && p.length==""){
        that.setData({msg2:"用户名不能为空"})
      
      }else if(pwd.length == 0 && pwd.length == ""){
        that.setData({msg3:"密码不能为空"})
       
      }else if(pwd != repwd){
        that.setData({msg4:"与原密码不一致"})
      
      }else{
        //校验通过，发送请求 查询有无相同手机号，不同则注册
       console.log("p:"+p);
        wx.request({
          url: "http://localhost:8888/ssmShop/checkphone",
          data: {
            phone: p,
          },
          method: 'GET', 
          success: function(res){
            console.log(res);
            if(res.data.code==200){
              console.log("手机号已存在");
              that.setData({msg1:"手机号已注册过！"})
            }else{
              wx.request({
                url: "http://localhost:8888/ssmShop/emp",
                data: {
                  phone: p,
                  password:pwd,
                  username:name
                },
                method: 'POST', 
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: function(res){
                  console.log(res);
                  that.setData({phoneinfo:"注册成功！"})
                  
                  wx.navigateTo({
                    url: '/pages/user/login/login?type=0',
                  })
                }
              })
            }
          }
        })
      }
    
   
  },
  changeTitle(index){
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    this.changeTitle(index);
    //2重新发送请求 type=1 index=0
    
  }
})