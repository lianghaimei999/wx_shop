import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index2.js')
Page({

    data: {
        //商品列表
        goods: [],
        //按钮的显示
        btnShow: false,
        //输入值
        inputValue: ''
    },
    timeId: -1,
   
    onLoad: function () {
        
      },
   //输入框变化
   inputChange(e) {
     console.log(e);
     let value = e.detail.value;
    if (!value.trim()) {
        this.setData({
            btnShow: false,
            goods: [],
            inputValue: value
        })
        return
    };
    clearInterval(this.timeId);
    this.timeId = setTimeout(() => {
        this.getGoods(value);
    }, 1000);
    this.setData({
        btnShow: true
    })
},
    //发送查询商品请求a
     getGoods(query) {
        var that =this;
       console.log("名称："+query);
      wx.request({
        url: "http://localhost:8888/ssmShop/selectquery",
        data: {
          goodName:(query) ,
        },
        type:'POST',
        success: function(res){
          console.log(res);
           if (that.data.btnShow === false) return
            that.setData({
                goods:res.data.extend.goods
        })
        }
      })
    },
  
    //点击取消按钮
    handleCancel() {
        this.setData({
            inputValue: '',
            btnShow: false,
            goods: []
        })
    }
})