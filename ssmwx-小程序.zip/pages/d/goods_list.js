import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({
  data: {
     //Tabs数据
     tabs: [{
      id: 0,
      name: '全部',
      isActive: true
  }, {
      id: 1,
      name: '手机数码',
      isActive: false
  },
  {
    id: 2,
    name: '校园代步',
    isActive: false
},
{
  id: 3,
  name: '电器日用',
  isActive: false
},
{
  id: 4,
  name: '图书教材',
  isActive: false
},
{
  id: 5,
  name: '美妆衣物',
  isActive: false
},
{
  id: 6,
  name: '球琴棋牌',
  isActive: false
}

],
     //商品列表数据
     goodList: [],
     list1:[],
     
  },
  onLoad: function (options) {
    this.getGoodsList()
  },
   //Tabs切换
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },

   //获取商品列表数据
  async getGoodsList() {
    let res = await request({ url: "/goods1" });
    let goodList = res.goods;
    //console.log(goodList);
    this.setData({
      goodList:goodList
    })
    // let arr=[];
    // for(var i=0;i<=goodList.length;i++){
    //   if(this.data.goodList[i].catelogId==1){
    //     console.log(this.data.goodList[i].catelogId);
    //     goodList.push(arr[i]);
    //   }
    // }
},

})
