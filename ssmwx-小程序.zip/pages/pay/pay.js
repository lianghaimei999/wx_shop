import { getSetting, chooseAddress, openSetting, showModal, showToast } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
//支付-购物车
Page({
  data: {
    userInfo:{},
    address:{},
    cart:[],
     //总价
     totalPrice: 0,
     //总数量
     totalNum: 0,
     dh:" ",//单号
     purse:[]

  },
  onShow(){
    var purse = wx.getStorageSync('purse');
     var userInfo = wx.getStorageSync('userInfo');
     const address = wx.getStorageSync('address');
     let cart = wx.getStorageSync('cart') || [];
     cart=cart.filter(v=>v.checked);
     this.setData({address,purse})
     let totalPrice = 0;
     let totalNum = 0;
     cart.forEach(v => {
          totalPrice += v.realPrice;
          totalNum += v.num
      });
         
      this.setData({
          cart,
          address,
          totalPrice,
          totalNum,
          userInfo,
          purse
         })
  },
  async pay(){
    //订单参数
     var that=this;
     var user_id = that.data.userInfo.id;//当前用户id
     var order_price = that.data.totalPrice;//订单总价格
     console.log("order_price:"+order_price);
     var purse = that.data.purse;
     var money =that.data.purse[0].balance;
     console.log("money:"+money);
     var pid = that.data.purse[0].id;
     var address = that.data.address;//地址
     var ad = address.province+address.city+address.adrs;
     ;
      //发送请求获取订单号参数
      let res = await request({ url: "/ordersDH" });
      //console.log(res);
      var dh = res.DH;
      
      if(order_price < money){
        var mm=money-order_price;
        console.log("钱包余额："+money);
        console.log("商品价格："+order_price);
        console.log("钱包余额mm："+mm);
        console.log("钱包ID："+pid);

        if(dh != ''){
          //console.log("dh:"+dh);
          const cart = that.data.cart;
          let goods = [];
          cart.forEach(v => goods.push({
            id: v.id,
            realPrice: v.realPrice
            }))
            //多条插入数据库
          if(goods.length != 0){
            for(var i=0;i<=goods.length;i++){
              let goods_id = goods[i].id;
              let real_price = goods[i].realPrice;
              //console.log(goods);
              wx.request({
                url: "http://localhost:8888/ssmShop/orders",
                data: {
                  userId:user_id,
                  goodsId:goods_id,
                  orderNum:dh,
                  orderPrice: real_price,
                  orderAddress:ad
                },
                method:'POST',
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: function(res){
                    let msg=res.data.msg;
                    if(res.data.code==100){
                      //成功下单，将商品status改成0 下架
                      wx.request({
                        url: "http://localhost:8888/ssmShop/good/"+goods_id,
                        method:'PUT',
                        data:{status:0},
                        header:{
                          'content-type':'application/x-www-form-urlencoded'
                        },
                        success: function(res2){
                          if(res2.data.code==100){
                            console.log("status succcess");
                          }
                        }
                        });
                      wx.navigateTo({
                        url: '/pages/pay2/pay2Success/pay2Success?msg='+msg,
                      })
                      }
                }
              })
              
              wx.request({
                url: "http://localhost:8888/ssmShop/purse/"+pid,
                method:'PUT',
                data:{balance:mm},
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: function(r2){
                  if(r2.data.code==100){
                    console.log("purse 成功");
                  }
                }
                });
              //删除支付后购物车商品
              let newCart = wx.getStorageSync("cart");
              newCart = newCart.filter(v => !v.checked);
              wx.setStorageSync("cart", newCart);
            }
          }else{
            console.log("goods为空");
          }
        }else{
          console.log("无法获取单号");
        }

      }else{
         //钱包余额不足
         wx.showToast({
          title: '钱包余额不足',
          icon:'none'
        })
      }

     
  }
})