import { request } from "../../request/index.js";
const app = getApp()
Page({
  data: {
    leftList:[],
    rightList:[],
    currentIndex:0//被点击左侧菜单
  },
  Goods:[],
  onLoad: function (options) {
    
    this.getGoodsList()
  },
  //分类数据和列表
  async getGoodsList(){
    let res = await request({ url: "/goods1" });
    this.Goods=res.goods;
    //wx.setStorageSync('cates', { time: Date.now(), data: this.Cate })
    let leftList = this.Goods.map(v => v.catelog.name);
    //对查出的分类栏目去重处理
      let arr=[];
      for(var i=0;i<leftList.length;i++){
         if(arr.indexOf(leftList[i])==-1 &&leftList[i]!=null){
           arr.push(leftList[i]);
        }
      }
    let rightList = this.Goods;
    this.setData({
        leftList:arr,
        rightList
    })
},

  //分类页面左侧菜单点击事件
  handleItem(e){
    console.log("左侧菜单点击事件"+e.currentTarget.dataset.index);
    //获取点击标题 给currentIndex赋值 
    const {index}=e.currentTarget.dataset;
    
    this.setData({
      currentIndex:index,
    })
  }

})