import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
var app = getApp()
Page({
  data: {
    //物品发布的数据
    good_name: '',
    price: '',
    real_price:'',
    describe: '',
    thingCampus: [],
    thingCampusIndex: 0,
    buttonLoadingThing: false,
    userInfo:{},
    chooseImgs:[],//选择图片数组
    imgs:[],
  },
  onLoad: function (options) {
    wx.cloud.init();
    this.getOption();
  },
  onShow: function() {
    var userInfo = wx.getStorageSync('userInfo');
    this.setData({
      userInfo:userInfo
    })
  },
  //商品名字
  bindThingNameInput: function(e) { 
    console.log("商品名字"+e.detail.value);
    this.setData({
      good_name: e.detail.value
    })
  },
  //商品原价格
  bindThingPriceInput: function(e) { 
    console.log("商品原价格"+e.detail.value);
    this.setData({
      price: e.detail.value
    })
  },
  //商品价格
  bindThingRPriceInput: function(e) { 
    console.log("商品现价格"+e.detail.value);
    this.setData({
      real_price: e.detail.value
    })
  },
  //商品描述
  bindThingDescribeInput: function(e) { 
    console.log("商品描述"+ e.detail.value);
    this.setData({
      describe: e.detail.value
    })
  },
  //类型
  bindThingCampusInput: function(e) { 
    console.log("商品类型"+e.detail.value);
    this.setData({
      thingCampusIndex: e.detail.value
    })
  },
  bindCampusChange: function(e) {
    console.log("商品类型下标"+e.detail.value);
    this.setData({
      campusIndex: e.detail.value
    })
  },
   //点击＋ 选择图片
   handleChoImg(){
    //小程序内部api chooseImage
    wx.chooseImage({
      count: 9,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success: (result)=>{
        this.setData({
          //图片数组进行拼接
          chooseImgs:[...this.data.chooseImgs,...result.tempFilePaths]
        })
        var img_url=this.data.chooseImgs;
        var imgs=this.data.imgs;
        for (var i = 0; i < img_url.length; i++){
          var b=result.tempFilePaths[0].substring(result.tempFilePaths[0].lastIndexOf('.'));
          wx.cloud.uploadFile({
            cloudPath:'test/' + Math.floor(Math.random()*1000000)+b,
            filePath:result.tempFilePaths[i],
            success: (res)=>{
              console.log("成功1",res);
              wx.cloud.getTempFileURL({
                fileList:[res.fileID],
                success:(res2)=>{
                  console.log(img_url.length);
                  for (var j = 0; j < img_url.length; j++){
                    imgs.push(res2.fileList[j].tempFileURL);
                    console.log(res2.fileList[i].tempFileURL);
                  }
                  this.setData({
                    imgs:imgs
                  })
                  console.log(this.data.imgs);
              }
              })
            }
          })
        }
      }
    });
  },
 //点击删除图片
  handleDel(e){
    const{index}=e.currentTarget.dataset;
    //console.log(index);
    let {chooseImgs}=this.data;
    chooseImgs.splice(index,1);//删除
    this.setData({
      chooseImgs//删除完回填数组
    });
    
  },
  //点击发布
  handleSumit(){
    var that=this
    let userInfo=that.data .userInfo;
    if(userInfo.id){
      const {text,chooseImgs,imgs,userInfo}=that.data;
      let user_id=userInfo.id
      console.log(imgs);
      for(var i=0;i<imgs.length;i++){
        var image=imgs[i]
      }
      var thing = that.data.thingCampus;
      var thingindex=that.data.thingCampusIndex;
      var index=parseInt(thingindex)+1;
      var u = that.data.userInfo.id;
      var name=that.data.good_name;
      var p=that.data.price;
      var rp=that.data.real_price;
      var d=that.data.describe;
      if(name==""||p==""||d==""||rp==""){
        wx.showToast({
          title: '输入不能为空',
          icon:'none',
          mask: true
        });
        return;
      }else if(imgs.length==0){
        wx.showToast({
          title: '未选择图片',
          icon:'none',
          mask: true
        });
        return;
      }
      wx.request({
        url: "http://localhost:8888/ssmShop/good",
        data: {
          userId:u,
          catelogId:index,
          goodName: name,
          realPrice:rp,
          price:p,
          describle:d,
          imgUrl1:imgs[0],
          imgUrl2:imgs[1],
          imgUrl3:imgs[2],
          imgUrl4:imgs[3],
          imgUrl5:imgs[4],
          imgUrl6:imgs[5],
          imgUrl7:imgs[6],
          imgUrl8:imgs[7],
          imgUrl9:imgs[8],
        },
        method:'POST',
        header:{
          'content-type':'application/x-www-form-urlencoded'
        },
        success: function(res){
            if(res.data.code==100){
              console.log("二手商品发布成功");
              that.setData({
                good_name: '',
                price: '',
                describe:'',
                real_price:'',
                chooseImgs:[],
                imgs:[]
              })
              }
        }
      })
     
    }else{
      wx.showToast({
        title: '登陆后才能发布哦~',
        icon:'none'
      })
    }
   
  },
  //获取分类列表
  async getOption(){
    let res = await request({ url: "/catelogOption" });
    var r=res.option;
    console.log(r);
   
    let arr2 = r.map(v => v.name);
    this.setData({thingCampus:arr2})
  }
})