import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({
  data: {
     //Tabs数据
     tabs: [{
      id: 0,
      name: '综合',
      isActive: true
  }, {
      id: 1,
      name: '最新',
      isActive: false
  }],
     //商品列表数据
     goodList: [],
     notice:[]
     
  },
  onLoad: function (options) {
    this.getGoodsList(); 
    this.getNotice()
  },
   //Tabs切换
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },

   //获取商品列表数据
  async getGoodsList() {
    let res = await request({ url: "/goods1" });
    let goodList = res.goods;
    //console.log(goodList);
    this.setData({
      goodList:goodList
    })
  },

  async getNotice(){
    let res = await request({ url: "/notice" });
    //let notice = res.notice;
    console.log(res);
    this.setData({
      notice: res.notice
    })
}

})
