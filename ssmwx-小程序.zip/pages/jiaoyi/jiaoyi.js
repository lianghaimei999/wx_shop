import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({
  data: {
    tabs:[
      {
        id:0,
        name:"我发布",
        isActive:true
      },
      {
        id:1,
        name:"我卖出",
        isActive:false
      },
     
    ],
    goodList: [],
    userInfo:{},
    list1:[]
  },
  onShow(options) {
    var userInfo = wx.getStorageSync('userInfo');
    this.setData({
      userInfo:userInfo
    })
    let pages= getCurrentPages();
    let currentPage=pages[pages.length-1]
    const {type}=currentPage.options;
    //4激活选中标题 type=1 index=0
    this.changeTitle(type-1);
    this.getGoodsList(type);
  },
  //获取列表数据
  getGoodsList(type){
    var that =this;
    wx.request({
      url: "http://localhost:8888/ssmShop/goods1",
      success: function(res){
        console.log(res.data.extend.goods);
        let goods = res.data.extend.goods;
        let newArr1=[];
        let uid=that.data.userInfo.id;
        console.log("uid:"+uid);
        goods.forEach(function(item){
          if(item.userId == uid){
            newArr1.push({
              catelogId:item.catelogId,
              goodName:item.goodName,
              realPrice:item.realPrice,
              imgUrl1:item.imgUrl1
            })
          }
        })
        that.setData({
           goodList:res.data.extend.goods,
           list1:newArr1
         })
      }
    })

   
  },
   changeTitle(index){
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    this.changeTitle(index);
    //2重新发送请求 type=1 index=0
    this.getGoodsList(index+1);
  }
})