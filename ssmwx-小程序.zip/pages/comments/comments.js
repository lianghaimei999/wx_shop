// pages/comments/comments.js
Page({
    data: {
    
      /*定义一些数据*/
      url2:'../../image/yh.png',
      focus: false, //输入框是否聚焦
      placeholder: '说点什么...', //底部输入框占字符
      placeholder2: '说点什么，让ta也认识看笔记的你', //顶部输入框占字符
      value: null, //顶部输入框内容
      comment_text: null, //底部评论框内容
  
      /*
       *以下初始化数据是用户点击任意一条评论或回复时需要设置的数据
       *然后将设置好的数据传递给评论时新创建的评论数据对象
      */
      now_reply_type: 0, //当前回复类型 默认为0 1为回复评论 2为回复回复
      now_parent_id: 0, //当前点击的评论或回复评论的所属评论id
      now_reply: 0, //当前点击的评论或回复评论的id
      goodId:0,//当前商品id

      
      //评论/回复真实数据
      conmments:[],
      conmments1:[],
      replys:[],
      replys1:[],
      userInfo:{},
      com_list:0,
      re_list:0 ,
      rl:''
    },
    onLoad: function (options) {
      //console.log("页面传递参数goodId:"+options.goodId);
      this.setData({
        goodId:options.goodId
      })
      this.getReplys(),
      this.getComments()
    },
    onShow:function(options){
      var userInfo = wx.getStorageSync('userInfo');
      console.log(userInfo);
      this.setData({userInfo:userInfo})
    },
      //请求获取评论数据
      getComments(){
        var that=this;
        
        wx.request({
          url: "http://localhost:8888/ssmShop/comments1",
          success: function(res){
           console.log(res);
           const conmments=res.data.extend.comments;
           
           let list=res.data.extend.comments;
           var newArr1=[];
           var gid=that.data.goodId;
           console.log("商品名称："+gid);
           list.forEach(function(item){
             //var nowId=item.goodsId;
             if(item.goodsId==gid){
              console.log("留言id："+res.data.extend.comments[10].goodsId);
                newArr1.push({
                  id:item.id,
                  userId:item.userId,
                  goodsId:item.goodsId,
                  content:item.content,
                  createAt:item.createAt,
                  user:item.user,
                  goods:item.goods
                })
               }
            })
            
           console.log("留言新数组:"+newArr1);
           that.setData({
              conmments:conmments,
              conmments1:newArr1
           })
          }
        })
     },
     //请求获取回复数据
     getReplys(){
      var that=this;
      wx.request({ 
        url: "http://localhost:8888/ssmShop/reply1",
        success: function(res){
         console.log(res);
         const replys=res.data.extend.replys;
         let list=res.data.extend.replys;
         var newArr2=[];var newa=[]
         list.forEach(function(item){
          if(item.commetId==that.data.conmments1.id){
            newa.push({
              id:item.id,
              userId:item.userId,
              atuserId:item.atuserId,
              commetId:item.commetId,
              createAt:item.createAt,
              content:item.content,
              user:item.user,
              comments:item.comments
            })
          }
            
            
         }) 
         list.forEach(function(item){
          console.log("正在回复留言的id：46");
            newArr2.push({
              id:item.id,
              userId:item.userId,
              atuserId:item.atuserId,
              commetId:item.commetId,
              createAt:item.createAt,
              content:item.content,
              user:item.user,
              comments:item.comments
            })
           
        }) 
        console.log("回复新数组:"+newArr2[0]);
        console.log(replys);
        console.log(newArr2);
        that.setData({
          replys:replys,
          replys1:newArr2,
          rl:newa.length
        })
       }
     })
     },
    //点击用户评论或回复时触发
    replyComment(e) {
      var cid = e.currentTarget.dataset.cid; //当前点击的评论----comments表中的id
      var name = e.currentTarget.dataset.name; //当前点击的评论的---用户名
      var cuid = e.currentTarget.dataset.cuid; //当前点击的评论所属评论id--即reply atuserId或者comments userId
      var type = e.currentTarget.dataset.type; //当前回复类型
      console.log("被点击点击评论id:"+cid);
      console.log("被点击评论用户名:"+name);
      console.log("被点击评论的评论者的用户id:"+cuid);
      console.log("评论类型:1回复 2回复的回复"+type);
      this.setData({
          focus: true, //输入框获取焦点
          placeholder: '回复' + name + '：', //更改底部输入框占字符
          now_reply: cid, 
          now_reply_name: name,
          now_parent_id: cuid, 
          now_reply_type: type, //获取类型(1回复评论/2回复-回复评论) 
      }) 
    },
   
    //顶部输入框提交触发
    inputbindconfirm(e) {  
      var userInfo=this.data.userInfo;
      if(userInfo.id){
        var comment_text = e.detail.value    //判断用户是否输入内容为空 
      console.log("顶部用户输入内容："+comment_text);   
      if (comment_text == '') {      //用户评论输入内容为空时弹出      
        wx.showToast({        
          title: '请输入内容', //提示内容        
          icon: 'none'      
        })    
      } else {      
        //当前时间
        var date = new Date();       
        var year = date.getFullYear();     
        var month = date.getMonth() + 1;       
        var day = date.getDate();   
        var hour = date.getHours();      
        var minute = date.getMinutes();     
        var second = date.getSeconds();      
        var time = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
        //获取评论 回复数据   
        var conmments1 = this.data.conmments1;   
        var replys1 = this.data.replys1;
        var com_list = conmments1.length;
        var re_list = replys1.length;
        //当前用户数据 当前商品
          
        var userid = userInfo.id;//    
        var gid = this.data.goodId;
        //回复评论数据
        var now_reply_type = this.data.now_reply_type;
        var now_parent_id = this.data.now_parent_id;
        var now_reply = this.data.now_reply;
        
        //评论
        wx.request({
            url: "http://localhost:8888/ssmShop/comments",
            data: {
              userId:userid,
              goodsId:gid,
              content:comment_text,
              createAt:time
            },
            method:'POST',
            header:{
              'content-type':'application/x-www-form-urlencoded'
            },
            success: (res)=>{ 
              if(res.data.code==100){
                this.getComments();
                console.log("评论成功");
                console.log(res.data);
              }
            } 
            
          })
        
        this.setData({        
          value: null, //评论内容        
          now_reply: 0, //当前点击的评论id        
          now_reply_name: null, //当前点击的评论的用户昵称        
          now_reply_type: 0, //评论类型        
          now_parent_id: 0, //当前点击的评论所属哪个评论id        
          placeholder2: "说点什么，让ta也认识看笔记的你", //输入框占字符        
          conmments1, //评论列表 
          com_list,
          re_list   
        })    
      }  
      }else{
        wx.showToast({
          title: '请先登录',
          icon:'none'
        })
      }
    },
    //底部输入框提交内容时触发
    confirm(e){
      //获取输入框输入的内容
      var userInfo=this.data.userInfo;
      if(userInfo.id){
        var comment_text = e.detail.value;
      console.log("底部用户输入内容："+comment_text); 
      //判断用户是否输入内容为空
      if (comment_text == '') {
        //用户评论输入内容为空时弹出
        wx.showToast({
         title: '请输入内容', //提示内容
         icon: 'none' //提示图标
       })
      } else {
          var date = new Date();
          var year = date.getFullYear();       
          var month = date.getMonth() + 1;      
          var day = date.getDate();      
          var hour = date.getHours();       
          var minute = date.getMinutes();      
          var second = date.getSeconds();       
          var time = `${year}-${month}-${day} ${hour}：${minute}：${second}`; //当前时间
          //获取评论 回复数据   
          var conmments1 = this.data.conmments1;    
          var replys1 = this.data.replys1;
          //当前用户数据 当前商品
            
          var userid = userInfo.id;//    
          var gid = this.data.goodId;
          var reply_id = this.data.now_reply; 
          var now_parent_id = this.data.now_parent_id;
          var now_reply2 = this.data.now_reply;
          var parent_id = this.data.now_reply; 
          var reply_name = this.data.now_reply_name; 
          var reply_type = this.data.now_reply_type; //回复类型
          //通过回复类型判断是回复评论还是回复回复
          if (reply_type == 1) {
            //回复-评论
            wx.request({
              url: "http://localhost:8888/ssmShop/reply",
              data: {
                userId:userid,
                atuserId:now_parent_id,
                commetId:now_reply2,
                content:comment_text,
                createAt:time
              },
              method:'POST',
              header:{
                'content-type':'application/x-www-form-urlencoded'
              },
              success: (res)=>{ 
                if(res.data.code==100){
                  this.getComments();
                  this.getReplys();
                  console.log("回复-评论成功now_reply2:"+now_reply2);
                  console.log("回复-评论成功");
                  this.setData({
                    comment_text: null, //评论内容        
                    now_reply: 0, //当前点击的评论id               
                    now_reply_type: 0, //评论类型        
                    now_parent_id: 0, //当前点击的评论所属哪个评论id        
                    placeholder: "说点什么...", //输入框占字符
                    conmments1,
                    replys1,
                  })
                }
              } 
            })
          } else {
              //回复-回复
              conmments1 = this.data.conmments1;    
              replys1 = this.data.replys1;
              now_parent_id = this.data.now_parent_id;
              
              wx.request({
                url: "http://localhost:8888/ssmShop/reply",
                data: {
                  userId:userid,
                  atuserId:now_parent_id,
                  commetId:now_reply2,
                  content:comment_text,
                  createAt:time
                },
                method:'POST',
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: (res)=>{ 
                  if(res.data.code==100){
                    this.getComments();
                    this.getReplys();
                    console.log("回复-回复成功now_reply2:"+now_reply2);
                    console.log("回复-回复成功");
                  }
                } 
              })
              
          }
       
    }
     this.setData({
      //发表评论后将以下数据初始化 为下次发表评论做准备
      comment_text: null, //评论内容        
      now_reply: 0, //当前点击的评论id               
      now_reply_type: 0, //评论类型        
      now_parent_id: 0, //当前点击的评论所属哪个评论id        
      placeholder: "说点什么...", //输入框占字符
      conmments1,
      replys1,
    })
      }else{
        wx.showToast({
          title: '请先登录',
          icon:'none'
        })
      }
      
    },
    //下面的方法可以绑定在输入框的bindblur属性上	
    blur(e) {
    const text = e.detail.value.trim();
    if( text == ''){
      this.setData({
        now_reply: 0, //当前点击的评论或回复评论的id        
        now_reply_name:null, //当前点击的评论或回复评论的用户昵称        
        now_reply_type:0, //当前回复类型        
        now_parent_id:0, //当前点击的评论或回复评论的所属评论id        
        placeholder: "说点什么呢，万一火了呢", //占字符        
        focus:false //输入框获取焦点
      })
      } 
      },
     
})