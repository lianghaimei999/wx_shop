/**
 *  * 1 点击＋号按钮
      *  调用小程序内置选择图片
      *  获取图片路径数组
      *  图片路径存到data中
      *  页面根据图片数组进行循环显示
 *  * 2 点击自定义组件
    *  获取被点击图片的索引
    *  获取data数组
    *  根据索引删除对应数组元素
    * 3 点击提交按钮
    *   获取文本域内容
    *   校验文本域内容
    *   验证通过 图片上传专门服务器 返回图片外网链接
    *       微信api不支持多个文件上传
    *       遍历图片数组 挨个上传 自己维护图片数组
    *   清空当前页面
    *   返回上一页
    * 
 * 
 */
Page({
  data: {
    tabs:[
      {
        id:0,
        name:"体验问题",
        isActive:true
      },
      {
        id:1,
        name:"商品/商家投诉",
        isActive:false
      }
    ],
    //被选中图片路径数组
    chooseImgs:[],
    text:""
  },
  //外网图片路径数组
  uploadImgs:[],
  onLoad: function (options) {

  },
  //标题点击事件，从子组件传递过来
  handleTabsItemChange(e){
    //1 获取被点击事件标题索引
    const {index}=e.detail;
    //2 修改原数组
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    //3 赋值到data中
    this.setData(
      {tabs}
    )
  },
 
 //点击＋ 选择图片
  handleChoImg(){
    //小程序内部api chooseImage
    wx.chooseImage({
      count: 9,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success: (result)=>{
        this.setData({
          //图片数组进行拼接
          chooseImgs:[...this.data.chooseImgs,...result.tempFilePaths]
        })
      }
    });
  },
 //点击删除图片
  handleDel(e){
    const{index}=e.currentTarget.dataset;
    //console.log(index);
    let {chooseImgs}=this.data;
    chooseImgs.splice(index,1);//删除
    this.setData({
      chooseImgs//删除完回填数组
    })
  },
  //文本域校验
  handleText(e){
    this.setData({
      text:e.detail.value
    })
  },
  handleSumit(){
    const {text,chooseImgs}=this.data;
    if(!text.trim()){
      wx.showToast({
        title: '输入不合法',
        mask: true
      });
      return;
    }
    //显示图片上传等待窗口
    wx.showLoading({
      title: "正在上传中...",
      mask: true
    })
    //判断有无图片上传
    if(chooseImgs.length!=0){
      chooseImgs.forEach((v,i)=>{
        wx.uploadFile({
          url: 'https://images.ac.cn/Home/Index/UploadAction/',
          filePath: v,
          name:"file",
          formData: {},
          success: (result)=>{
            let url=JSON.parse(result.data);
            this.uploadImgs.push(url);
            console.log(this.uploadImgs);
            //所有图片上传完之后才触发
            if(i===chooseImgs.length-1){
              wx.hideLoading();
              console.log("把文本和图片数组上传到后台");
              //数据重置
              this.setData({
                text:"",
                chooseImgs:[]
              })
              //返回上一个页面
              wx.wx.navigateBack({
                delta: 1
              });
            }
          }
        });
      })

    }else{
      wx.hideLoading();
      wx.navigateBack({
        delta:1
      })
    }
  }
})