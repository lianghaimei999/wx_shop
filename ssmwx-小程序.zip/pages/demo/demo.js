import { getSetting, chooseAddress, openSetting, showModal, showToast } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
Page({
    data: {
        //收货地址
        address: {},
        //购物车
        cart: [],
        // 全选状态
        allChecked: true,
        //总价
        totalPrice: 0,
        //总数量
        totalNum: 0
    },
    onShow() {
        {
            let a=1;
        const b=2;
        var c=3;
        {
            console.log(b);
            {
                console.log(b);
                {
                    console.log(c);
                }
            }
        }
        }
        {
            console.log("ccccccccc::"+c);
        }
    },
  
   
})