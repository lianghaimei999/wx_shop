import regeneratorRuntime from '../../../lib/runtime/runtime';
const { request } = require('../../../request/index.js');

const app = getApp();
var inputVal = '';
var windowWidth = wx.getSystemInfoSync().windowWidth;
var windowHeight = wx.getSystemInfoSync().windowHeight;
var keyHeight = 0;
function initData(that) {
 inputVal = '';
 that.setData({
  inputVal
 })
}
Page({
 data: {
  scrollHeight: '100vh',
  inputBottom: 0,
  chat:[],
  userInfo:{},
  jsfId:0,//jsfId
 },
 onLoad: function(options) {
    console.log("页面传递参数goodDetail-userId:"+options.jsfId);
    this.setData({
      jsfId:options.jsfId,
    })
  initData(this);
  this.getChat();
 },
 onShow: function() {
  var userInfo = wx.getStorageSync('userInfo');
  this.setData({
    userInfo:userInfo
  });
  
 },
 async getChat(){
  const res=await request({url:"/chat1"});
  console.log(res);
  let chat = res.chat;
  var newArr1=[];
  var newArr2=[];
  var a=this.data.jsfId;
  chat.forEach(function(item){
    if(item.idFsf==a ||item.idJsf==a){
      newArr1.push({
        id:item.id,
        idFsf:item.idFsf,
        idJsf:item.idJsf,
        content:item.content,
        isLook:item.isLook,
        lTime:item.lTime,
        user:item.user,
        goodId:item.goodId
      })
    }
  })
  console.log(newArr1);
  wx.setStorageSync('chat', newArr1)
  this.setData({
    chat:newArr1
  })
 },
 /**
  * 获取聚焦
  */
 focus: function(e) {
  keyHeight = e.detail.height;
  this.setData({
   scrollHeight: (windowHeight - keyHeight) + 'px'
  });
  this.setData({
   toView: 'msg-' + (this.data.chat.length - 1),
   inputBottom: keyHeight + 'px'
  })
 },

 //失去聚焦(软键盘消失)
 blur: function(e) {
  this.setData({
   scrollHeight: '100vh',
   inputBottom: 0
  })
  this.setData({
   toView: 'msg-' + (this.data.chat.length - 1)
  })

 },
//发送消息
 sendClick: function(e) {
   var chat = this.data.chat;
   var text = e.detail.value;
  console.log("发送的消息："+e.detail.value);
  if(text == ''){
    wx.showToast({        
      title: '请输入内容', //提示内容        
      icon: 'none'      
    })
  }else{
        let date = new Date();       
        let year = date.getFullYear();     
        let month = date.getMonth() + 1;       
        let day = date.getDate();   
        let hour = date.getHours();      
        let minute = date.getMinutes();     
        let second = date.getSeconds();      
        let time = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
        let chat = this.data.chat;   
        let userInfo = this.data.userInfo;    
        let userid = userInfo.id;
        let userId = this.data.userId;
        let good_id = this.data.goodId;

        wx.request({
          url: "http://localhost:8888/ssmShop/chat",
          data: {
            idFsf:userid,
            idJsf:userId,
            content:text,
            lTime:time,
            goodId:good_id
          },
          method:'POST',
          header:{
            'content-type':'application/x-www-form-urlencoded'
          },
          success: (res)=>{ 
            if(res.data.code==100){
              this.getChat();
              console.log("聊天成功");
              inputVal = '';
              this.setData({
              chat:chat,
              inputVal
              });
            }
          } 
          
        })

  }
  


 },
 toBackClick: function() {
  wx.navigateBack({})
 },


})