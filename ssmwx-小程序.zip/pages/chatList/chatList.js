import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({
  data: {
     chatList: [],//所以聊天消息
     userInfo:{},
     chatListJ:[],  //当前用户消息列表
     after:[],//过滤重复后消息列表
     newChat:[],
     index:0,
     chat:[]
  },
  Chat:[],
  onLoad: function (options) {
    var userInfo = wx.getStorageSync('userInfo');
    var chat = wx.getStorageSync('chat')
    this.setData({userInfo:userInfo})
    console.log(userInfo,chat);
    this.getchatList()
  },

  async getchatList() {
    let res = await request({ url: "/chat1" });
    let chatList = res.chat;
    let arr1=[];
    var userInfo=this.data.userInfo;
    console.log("当前登录的userInfo=id："+userInfo.id);
    chatList.forEach(function(item){
      if(item.idFsf ==userInfo.id){
        arr1.push({
          id:item.id,
          idFsf:item.idFsf,
          idJsf:item.idJsf,
          content:item.content,
          isLook:item.isLook,
          lTime:item.lTime,
          user:item.user
        })
      }
    })
   // console.log(chatList);
   console.log("当前用户与聊天表对应消息：");
    console.log(arr1);
    this.Chat=arr1
    this.setData({
      chatList:chatList,
      chatListJ:arr1
    });
console.log(arr1);
    var chatListJ=this.data.chatListJ;
    var newChat=[];
    for(let i in chatListJ){
      let idJsf=chatListJ[i].idJsf
      if(newChat[idJsf]==undefined){
        newChat[idJsf]=[chatListJ[i]]
      }else{
        newChat[idJsf].push(chatListJ[i])
      }
    }
    console.log(newChat);
    let List = this.Chat.map(v => v.idJsf);
    let arr=[];
    var after=[];
      for(var i=0;i<this.Chat.length;i++){
         if(arr.indexOf(this.Chat[i].idJsf)==-1){
           after.push({
            idJsf:this.Chat[i].idJsf,
            origin:[this.Chat[i]]
           });
           arr.push(this.Chat[i].idJsf)
          
        }else{
          for(var j=0;j<after.length;j++){
            if(after[j].idJsf==this.Chat[i].idJsf){
              after[j].origin.push(this.Chat[i]);
              
            }
          }
        }
      }
      
       
      this.setData({
        after:after,
        newChat:newChat,
        index:after.length
      })
  },

  openChat(e){
    var jsfid =  e.currentTarget.dataset.id;
    console.log(jsfid);
    wx.navigateTo({
      url: '/pages/chatList/chat2/chat2?jsfId='+jsfid,
    })
  }

})
