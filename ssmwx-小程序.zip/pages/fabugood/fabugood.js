
var app = getApp()
Page({
  data: {
    //物品发布的数据
    image_url: '',
    good_name: '',
    price: '',
    thingCampus: ["手机数码", "校园代步","电器日用","图书教材","美妆衣物","球琴棋牌"],
    thingCampusIndex: 0,
    describe: '',
    buttonLoadingThing: false,
    userInfo:{},
   
  },
  onLoad: function (options) {
    wx.cloud.init();
  },

  onShow: function() {
    var userInfo = wx.getStorageSync('userInfo');
    this.setData({
      userInfo:userInfo
    })
    
  },
  //商品图片选择
  bindThingImageInput(){
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success(res){
        console.log(res.tempFilePaths[0]);
        var b=res.tempFilePaths[0].substring(res.tempFilePaths[0].lastIndexOf('.'));
      
        console.log("b:"+b);
       // var a=res.tempFilePaths[0].match(/\.[^.]+?$/)
        wx.cloud.uploadFile({
          cloudPath:'test/' + Math.floor(Math.random()*1000000)+b,
          filePath:res.tempFilePaths[0],
          success(res){
            console.log("成功",res);
            wx.cloud.getTempFileURL({
              fileList:[res.fileID],
              success(res){
                console.log(res.fileList[0].tempFileURL);
                that.setData({
                  image_url:res.fileList[0].tempFileURL
                })
              }
            })
          }
        })
      }
    })
  },
  //商品名字
  bindThingNameInput: function(e) { 
    console.log("商品名字"+e.detail.value);
    this.setData({
      good_name: e.detail.value
    })
  },
  //商品价格
  bindThingPriceInput: function(e) { 
    console.log("商品价格"+e.detail.value);
    this.setData({
      price: e.detail.value
    })
  },
  //商品描述
  bindThingDescribeInput: function(e) { 
    console.log("商品描述"+ e.detail.value);
    this.setData({
      describe: e.detail.value
    })
  },
  //类型
  bindThingCampusInput: function(e) { 
    console.log("商品类型"+e.detail.value);
    this.setData({
      thingCampusIndex: e.detail.value
    })
  },
  bindCampusChange: function(e) {
    console.log("商品类型下标"+e.detail.value);
    this.setData({
      campusIndex: e.detail.value
    })
  },
  handleSumit(){
    console.log("fabu");
    let userInfo=this.data.userInfo;
    if(userInfo.id){
      const {image_url,good_name,price,thingCampus, thingCampusIndex,describe}=this.data;
      if(good_name==""||price==""||describe==""){
        wx.showToast({
          title: '输入不合法',
          mask: true
        });
        return;
      }
      var thing = this.data.thingCampus;
      var thingindex=this.data.thingCampusIndex;
      var index=parseInt(thingindex)+1;
      console.log(index);
      var user_id = this.data.userInfo.id;
      var name=this.data.good_name;
      var p=this.data.price;
      var d=this.data.describe;
      var img=this.data.image_url;
      console.log("图片"+img);
      wx.request({
        url: "http://localhost:8888/ssmShop/good",
        data: {
          userId:user_id,
          catelogId:index,
          goodName: name,
          realPrice:p,
          describle:d,
          imgUrl1:img
        },
        method:'POST',
        header:{
          'content-type':'application/x-www-form-urlencoded'
        },
        success: (res)=>{
          console.log(res);
          if(res.data.code==100){
            wx.showToast({
              title: '发布成功',
              icon: 'success',
              mask: true,
            });
            this.setData({
              image_url: '',
              good_name: '',
              price: '',
              describe:''
            })
          }
        } 
      })
    
      
    }else{
      wx.showToast({
        title: '请先登录',
        icon:'none'
      })
    }
   
   
  }
  
})