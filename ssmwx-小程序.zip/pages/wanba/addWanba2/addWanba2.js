/**
 *  * 1 点击＋号按钮
      *  调用小程序内置选择图片
      *  获取图片路径数组
      *  图片路径存到data中
      *  页面根据图片数组进行循环显示
 *  * 2 点击自定义组件
    *  获取被点击图片的索引
    *  获取data数组
    *  根据索引删除对应数组元素
    * 3 点击提交按钮
    *   获取文本域内容
    *   校验文本域内容
    *   验证通过 图片上传专门服务器 返回图片外网链接
    *       微信api不支持多个文件上传
    *       遍历图片数组 挨个上传 自己维护图片数组
    *   清空当前页面
    *   返回上一页
    * 
 * 
 */
Page({
  data: {
    //被选中图片路径数组
    chooseImgs:[],
    text:"",
    imgs:[],
    userInfo:{}
  },
  //外网图片路径数组
  uploadImgs:[],
  onLoad: function (options) {
    wx.cloud.init();
  },
  onShow: function (options) {
    var userInfo=wx.getStorageSync('userInfo');
    this.setData({userInfo})
  },
 //点击＋ 选择图片
  handleChoImg(){
   
    //小程序内部api chooseImage
    wx.chooseImage({
      count: 9,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success: (result)=>{
        this.setData({
          //图片数组进行拼接
          chooseImgs:[...this.data.chooseImgs,...result.tempFilePaths]
        })
        var img_url=this.data.chooseImgs;
        var imgs=this.data.imgs;
        for (var i = 0; i < img_url.length; i++){
          var b=result.tempFilePaths[0].substring(result.tempFilePaths[0].lastIndexOf('.'));
          wx.cloud.uploadFile({
            cloudPath:'test/' + Math.floor(Math.random()*1000000)+b,
            filePath:result.tempFilePaths[i],
            success: (res)=>{
              console.log("成功1",res);
              wx.cloud.getTempFileURL({
                fileList:[res.fileID],
                success:(res2)=>{
                  console.log(img_url.length);
                 
                  for (var j = 0; j < img_url.length; j++){
                    imgs.push(res2.fileList[j].tempFileURL);
                    console.log(res2.fileList[i].tempFileURL);
                  }
                  this.setData({
                    imgs:imgs
                  })
                  console.log(this.data.imgs);
              }
              })
            }
          })
        }

      }
    });
  },
  imgupload(){
    var img_url=this.data.chooseImgs;
    var uploadImgs=this.data.uploadImgs;
    for (var i = 0; i < img_url.length; i++){
      var b=result.tempFilePaths[0].substring(result.tempFilePaths[0].lastIndexOf('.'));
      wx.cloud.uploadFile({
        cloudPath:'test/' + Math.floor(Math.random()*1000000)+b,
        filePath:result.tempFilePaths[i],
        success: (res)=>{
          console.log("成功1",res);
          wx.cloud.getTempFileURL({
            fileList:[res.fileID],
            success:(res2)=>{
              console.log(img_url.length);
              console.log(res2.fileList[0].tempFileURL);
              console.log(res2.fileList[1].tempFileURL);
              console.log(res2.fileList[2].tempFileURL);
              for (var j = 0; j < img_url.length; j++){
                uploadImgs.push(res2.fileList[j].tempFileURL)
              }
              this.setData({
                uploadImgs:uploadImgs
              })
              console.log(uploadImgs);
          }
          })
        }
      })
    }
  },
 //点击删除图片
  handleDel(e){
    const{index}=e.currentTarget.dataset;
    //console.log(index);
    let {chooseImgs}=this.data;
    chooseImgs.splice(index,1);//删除
    this.setData({
      chooseImgs//删除完回填数组
    });
    
  },
  //文本域校验
  handleText(e){
    this.setData({
      text:e.detail.value
    })
  },
  handleSumit(){
    var that=this;
    let userInfo=that.data.userInfo;
    if(userInfo.id){
      const {text,chooseImgs,imgs,userInfo}=that.data;
      let user_id=userInfo.id;
      console.log(imgs);
      for(var i=0;i<imgs.length;i++){
        var image=imgs[i];
      }
      wx.request({
        url: "http://localhost:8888/ssmShop/tzb",
        data: {
          userId:user_id,
          content:text,
          img1:imgs[0],
          img2:imgs[1],
          img3:imgs[2],
          img4:imgs[3],
          img5:imgs[4],
          img6:imgs[5],
          img7:imgs[6],
          img8:imgs[7],
          img9:imgs[8],
         
        },
        method:'POST',
        header:{
          'content-type':'application/x-www-form-urlencoded'
        },
        success: function(res){
            if(res.data.code==100){
              console.log("发表动态成功");
              that.setData({
                text:'',
                chooseImgs:[],
                imgs:[]
              })
              wx.navigateBack({
                delta: 0,
              })
              }
        }
      })
     
    }else{
      wx.showToast({
        title: '登陆后才能发布哦~',
        icon:'none'
      })
    }
   
  }
})