// pages/circle/list.js
var that;
Page({
  data: {
    list:[],
    // 当前点击操作面板的索引，每条朋友圈一个面板
    showOperationPannelIndex:-1,
    tz:[],
    tzimgs:[],
    loveList:[], // 点赞列表
    replyList:[], // 评论列表
    replyList2:[],
    userInfo:{},
    text: '',
    isCollect: false,
    like:0,
    hasChange:false,
    show:false
    
  },
  onShow:function(option){
    this.getWanba();
    this.getReply();
  },
  onLoad: function (options) {
    that = this;
    var userInfo = wx.getStorageSync('userInfo');
    that.setData({userInfo})
    this.getWanba();
    this.getReply();
    for (var i = 1; i < 10; i++) {
      // 定义一个对象存储数据
      var circleData = {};
      circleData.nickName = "朋友-" + i;
      circleData.content = "朋友发布内容-" + i;
      circleData.time = "2020-05-0" + i;

      //图片列表
      var imageList = [];
      // 点赞列表
      var loveList = [];
      // 评论列表
      var commentList = [];


      // 这三个数组赋值给circleData
      circleData.imageList = imageList;
      circleData.loveList = loveList;
      circleData.commentList = commentList;

      // 给3个数组赋值
      for (var j = 1; j < i; j++) {
        // 图片路径，占位
        imageList.push(j);
        // loveList，定义loveData对象
        var loveData = {};
        loveData.nickName = '点赞-' + j;
        // 点赞数组加入loveList
        loveList.push(loveData);

        // 评论数据
        var commentData = {};
        commentData.nickName = "兰陵王-" + j + "：";
        commentData.content = "评论内容-" + j;
        // 加入数据
        commentList.push(commentData);
      }

      that.data.list.push(circleData);
    }
    // 重新渲染
    that.setData({
      list: that.data.list
    })
  },
  //控制操作面板展示
  showOperationPannel(e){
    console.log("showOperationPannel",e);
    // 获取点击的索引
    var index = e.currentTarget.dataset.index;
    // 如果正在展示，则关闭
    if(that.data.showOperationPannelIndex == index){
      that.setData({
        // 索引从0开始
        showOperationPannelIndex:-1
      })
    }
    else{
      that.setData({
        // 设置成当前点击的索引
        showOperationPannelIndex:index
      })
    }
    
  },

  getWanba(){
    var that=this;
    wx.request({
      url: "http://localhost:8888/ssmShop/tz1",
      success: function(res){
          if(res.data.code==100){
            console.log("查询动态成功");
            var tz1=res.data.extend.tz
            that.setData({
              tz:tz1,
            })
            }
      }
    })
  },
  getReply(){
    var that=this;
    var tzb=that.data.tz;
    wx.request({
      url: "http://localhost:8888/ssmShop/tzreply1",
      success: function(res){
          if(res.data.code==100){
            console.log("回复动态成功");
            //var tz1=res.data.extend.tz
            console.log(res.data.extend.tzreply);
            let replyList=res.data.extend.tzreply;
            let newarr=[]; let newarr2=[]
            replyList.forEach(function(i){
              if(i.isLike==1){
                newarr.push({
                  id:i.id,
                  tzId:i.tzId,
                  userId:i.userId,
                  rContent:i.rContent,
                  isLike:i.isLike,
                  tzb:i.tzb,
                  user:i.user,
                })
              }
              if(i.tzId==tzb.id){
                newarr2.push({
                  id:i.id,
                  tzId:i.tzId,
                  userId:i.userId,
                  rContent:i.rContent,
                  isLike:i.isLike,
                  tzb:i.tzb,
                  user:i.user,
                })
              }
            });
            console.log(replyList);
            that.setData({
              replyList:replyList,
              loveList:newarr,
              replyList2:newarr2
            });
           
            }
      }
    })
  },

  inputbindconfirm(e) {  
    var tz_id = e.currentTarget.dataset.id
    var userid=this.data.userInfo.id;
    var text = e.detail.value;
    console.log("id:"+tz_id);
    console.log("评论输入内容："+text); 
    console.log("当前用户："+userid); 
    if(userid){  
    if (text == '') {      //用户评论输入内容为空时弹出      
      wx.showToast({        
        title: '请输入内容', //提示内容        
        icon: 'none'      
      })    
    } else {      
       //帖子评论
       wx.request({
          url: "http://localhost:8888/ssmShop/tzreply",
           data: {
             tzId:tz_id,
             userId:userid,
             rContent:text
           },
           method:'POST',
           header:{
             'content-type':'application/x-www-form-urlencoded'
           },
           success: (res)=>{ 
            if(res.data.code==100){
               this.getReply();
               console.log("帖子评论成功");
               console.log(res.data);
           }
           } 
         })
         this.setData({
             text:''
        })
     
    }  
    }else{
      wx.showToast({
        title: '请先登录',
        icon:'none'
      })
    }
  },

  collectHandle: function (e) {

    var that = this;
    var hasChange = that.data.hasChange;

    if (hasChange !== undefined) {
      var onum = parseInt(that.data.like);
      console.log(hasChange);
      if (hasChange == 'true') {
        that.data.like = (onum - 1);
        that.data.hasChange = 'false';
        that.data.show = false;
      } else {
        that.data.like = (onum + 1);
        that.data.hasChange = 'true';
        that.data.show = true;
      }
      this.setData({
        like: that.data.like,
        hasChange: that.data.hasChange,
        show:that.data.show
      })
    };
    wx.request({
      url: 'https://********',//这里写后台点赞接口的url
      //定义传到后台的数据
      data: {
        userID: app.globalData.openid,//我的ID
        paperID: this.data.id//文章ID
      },
      method: 'get',//定义传到后台接受的是post方法还是get方法
      success: function (res) {
        console.log("成功");
      },
      fail: function (res) {
        console.log("失败");
      }

    });
    var pages = getCurrentPages();//当前页面栈
    if (pages.length > 1) {
      var beforePage = pages[pages.length - 2];//获取上一个页面实例对象
      beforePage.changeData();//触发父页面中的方法
    }
  },
  collectHandle1(e){
    var that = this;
    var hasChange = that.data.hasChange;
    var tz = that.data.replyList;
    console.log(tz);
    var index=e.currentTarget.dataset.index;
    console.log(index);
   tz.forEach(function(item){
    if(item.tzId==index){
      if (this.list[index]) {
        var hasChange = this.list[index].hasChange;
        if (hasChange !== undefined) {
          var onum = this.list[index].praise;
          if (hasChange) {
            this.list[index].praise = (onum - 1);
            this.list[index].hasChange = false;
          } else {
            this.list[index].praise = (onum + 1);
            this.list[index].hasChange = true;
          }
          this.setData({
            list: this.list
          })
        }
      }

    }
   })
  },
})
