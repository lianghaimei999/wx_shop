// pages/pay/pay.js
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    msg: "",
    resultContent: "",
    url:""
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options){
    var msg=options.msg;
    console.log("options.msg"+options.msg);
    if (msg == "处理成功") {
      this.setData({
        msg: "success",
        resultContent: "支付成功",
        url: '/pages/orders/orders?type=1'
      });
    } else {
      this.setData({
        msg: "warn",
        resultContent: "支付失败",
        url: '/pages/goods_list'
      });
    }
  }
})