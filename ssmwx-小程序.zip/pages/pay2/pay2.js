import { getSetting, chooseAddress, openSetting, showModal, showToast } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
//支付=立即购买
Page({
  data: {
    userInfo:{},
    address:{},
    cartNow:[],
     totalNum: 0,
     code:0,
     purse:[]
  },
  onShow(){
     var userInfo = wx.getStorageSync('userInfo');
     var purse = wx.getStorageSync('purse');
     var address = wx.getStorageSync('address');
     let cartNow = wx.getStorageSync('cartNow');
     //var p=this.data.cartNow.price
     this.setData({
       address:address,
       cartNow:cartNow,
      // totalPrice:p,
       totalNum: 1,
       userInfo: userInfo,
       purse:purse
      })
  },
  pay(){
      var user_id = this.data.userInfo.id;
      var money = this.data.purse.balance;
      var order_price = this.data.cartNow[0].realPrice;
      var goods_id = this.data.cartNow[0].id;
      var b = this.data.purse.id;
      var ad = this.data.address.all;
      //钱包余额充足，发送请求获取订单号参数
      console.log("钱包余额："+money);
      console.log("商品价格："+order_price);
      if(order_price < money){
        var mm=parseInt(money-order_price);
        console.log("钱包余额："+money);
        console.log("商品价格："+order_price);
        console.log("钱包余额mm："+mm);
        wx.request({
          url: "http://localhost:8888/ssmShop/orders",
          data: {
            userId:user_id,
            orderPrice: order_price,
            goodsId:goods_id,
            orderAddress:ad
          },
          method:'POST',
          header:{
            'content-type':'application/x-www-form-urlencoded'
          },
          success: function(res){
            //console.log("res.data.code:"+res.data.msg);
            let msg=res.data.msg;
            if(res.data.code==100){
              wx.request({
                url: "http://localhost:8888/ssmShop/good/"+goods_id,
                method:'PUT',
                data:{status:0},
                header:{
                  'content-type':'application/x-www-form-urlencoded'
                },
                success: function(res2){
                  if(res2.data.code==100){
                    console.log("下单支付成功 succcess");
                  }
                }
                });
               
              wx.navigateTo({
                url: '/pages/pay2/pay2Success/pay2Success?msg='+msg,
              })
              }
          }
        })
        
        wx.request({
          url: "http://localhost:8888/ssmShop/purse/"+b,
          method:'PUT',
          data:{balance:mm},
          header:{
            'content-type':'application/x-www-form-urlencoded'
          },
          success: function(r2){
            if(r2.data.code==100){
              console.log("purse 成功");
            }
          }
          });
      }else{
        //钱包余额不足
        wx.showToast({
          title: '钱包余额不足',
          icon:'none'
        })
      }
        
  },
  //地址选择
chooseAdrs(){
  console.log("地址选择");
  let userInfo=this.data.userInfo;
  if(userInfo.id){
    wx.navigateTo({
      url: '/pages/address/addressList/addressList',
    })
  }else{
    wx.showToast({
      title: '请先登录',
      icon:'none'
    })
  }
},
})