
import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
var app=getApp();
Page({
 data: {
   tabs:[
     {
       id:0,
       name:"全部",
       isActive:true
     },
     {
       id:1,
       name:"待付款",
       isActive:false
     },
     {
       id:2,
       name:"待发货",
       isActive:false
     },
     {
       id:3,
       name:"已完成",
       isActive:false
     }
   ],
   orders:[],//全部订单
   orders1:[],//全部订单=代付款
   orders2:[],//全部订单=待收货
   orders3:[],//全部订单-已完成
   userInfo:{}
 },
 Orders:[],
 onShow(options){
    //  //判断是否登陆
    //  const token = wx.getStorageSync('token')
    //  if (!token) {
    //      wx.navigateTo({
    //          url: '/pages/auth/auth',
    //      });
    //      return;
    //  }
   var userInfo = wx.getStorageSync('userInfo');
   this.setData({
     userInfo:userInfo
   });
   let pages= getCurrentPages();
   let currentPage=pages[pages.length-1]
   const {type}=currentPage.options;
   this.changeTitle(type-1);
   this.getOrders(type);

 },
 onLoad(options){
 
 },
 //获取订单列表的方法
 async getOrders(type){
   const res=await request({url:"/orders1",data:{type}});
   //console.log(res.ordaers);
   this.Orders=res.orders;
   let goods = res.orders;
   console.log(goods);
   var newArr1=[]; var newArr2=[]; var newArr3=[];
   let uid=this.data.userInfo.id;
   console.log("uid:"+uid);
   goods.forEach(function(item){
     if(item.userId===uid){
       newArr1.push({
         id:item.id,
         orderNum:item.orderNum,
         orderPrice:item.orderPrice,
         orderDate:item.orderDate,
         userId:item.userId,
         goodsId:item.goodsId,
         user:item.user,
         goods:item.goods,
         orderState:item.orderState
       })
       if(item.orderState===2){
         newArr2.push({
           orderNum:item.orderNum,
           orderPrice:item.orderPrice,
           orderDate:item.orderDate,
           userId:item.userId,
           goodsId:item.goodsId,
           user:item.user,
           goods:item.goods,
           orderState:item.orderState
         })
       }else if(item.orderState===3){
         newArr3.push({
           orderNum:item.orderNum,
           orderPrice:item.orderPrice,
           orderDate:item.orderDate,
           userId:item.userId,
           goodsId:item.goodsId,
           user:item.user,
           goods:item.goods,
           orderState:item.orderState
         })
       }
     }
   })
   console.log("newArr1"+newArr1[0].goods.imgUrl1);
   //console.log("newArr2"+newArr2);
   this.setData({
     orders:newArr1,
     orders2:newArr2,
     orders3:newArr3,
   })
  
   if(!this.data.userInfo.id){
     wx.navigateTo({
       url: '/pages/login/login',
     })
   }
  },
 onLoad: function (options) {

 },
 //删除订单
  delOrder:function(e){
   console.log("删除订单");
   var id=e.currentTarget.dataset.id;
   console.log("删除订单id:"+id);
   wx.showModal({
    title: '提示',
    content: '你确认删除此订单吗',
    success: function(res) {
      if(res.confirm){
       wx.request({
        url:'http://localhost:8888/ssmShop/ordersDelId/'+id,
        method:'DELETE',
        success: function (res) {
          if(res.data.code==100){
            console.log("删除订单成功");
            wx.showToast({
              title: '删除订单成功',
              icon:'success',
              duration:1000
            })
          }else{
            wx.showToast({
              title: '',
              icon:'success',
              duration:1000
            })
          }
        },
        fail:function(res){
          wx.showToast({
            title: '服务器或者网络错误',
            icon:'loading',
            duration:1000
          })
        }
  });
      }
  }})
 },
 //确认收货
 sureOrder(e){
  console.log("确认收货");
   var id=e.currentTarget.dataset.id;
   wx.request({
    url:'http://localhost:8888/ssmShop/ordersSure/'+id,
    method:'PUT',
    success: function (res) {
      if(res.data.code==100){
        console.log("确认收货成功");
        this.getOrders();
        wx.showToast({
          title: '确认收货成功',
          icon:'success',
          duration:1000
        })
      }else{
        wx.showToast({
          title: '',
          icon:'success',
          duration:1000
        })
      }
    },
    fail:function(res){
      wx.showToast({
        title: '服务器或者网络错误',
        icon:'loading',
        duration:1000
      })
    }
});
},
 //根据标题索引激活选中 标题数组
 changeTitle(index){
   //2 修改原数组
   let {tabs}=this.data;
   tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
   //3 赋值到data中
   this.setData(
     {tabs}
   )
 },
 //标题点击事件，从子组件传递过来
 handleTabsItemChange(e){
   //1 获取被点击事件标题索引
   const {index}=e.detail;
   this.changeTitle(index);
   //2重新发送请求 type=1 index=0
   this.getOrders(index+1);
 }

})