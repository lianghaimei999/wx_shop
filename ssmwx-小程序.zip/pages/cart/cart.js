import { getSetting, chooseAddress, openSetting, showModal, showToast } from "../../utils/asyncWx.js";
import regeneratorRuntime from '../../lib/runtime/runtime';
const { request } = require('../../request/index.js')
Page({

  data: {
    
    address:{},
    address2:[],
    cart:[],
     // 全选状态
     allChecked: true,
     //总价
     totalPrice: 0,
     //总数量
     totalNum: 0,
     userInfo:{}
  },
  onShow(){
     const userInfo = wx.getStorageSync('userInfo');
     //收货地址接收
     const address = wx.getStorageSync('address');
     this.setData({
             address,
             userInfo
         })
     //购物车接收
     const cart = wx.getStorageSync('cart') || [];
     this.setCart(cart)
     //console.log("cart："+cart.goodName);
     
  },
  //添加收货地址事件
   handleChooseAdrs() {
      //  wx.navigateTo({
      //    url:'/pages/address/addressList/addressList'
      //  })
        // const scope = await getSetting()
        // if (scope === false) {
        //     await openSetting();
        // }
       // let address = this.data.address;
        // address.all = address.provinceName + address.cityName + address.countyName + address.detailInfo;
        //wx.setStorageSync('address', address)
      // console.log(address);
      },

  //商品选择状态改变
  handleItemChange(e) {
    const { id } = e.currentTarget.dataset;
    const { cart } = this.data;
    const index = cart.findIndex(v => v.id === id);
    cart[index].checked = !cart[index].checked;
    this.setCart(cart)
},
// 全选按钮改变
handleItemAllChange() {
    const { allChecked, cart } = this.data;
    cart.forEach(v => v.checked = !allChecked);
    this.setCart(cart)
},
 //移除
 del(e){
  const { id, opration } = e.currentTarget.dataset;
  const { cart } = this.data;
  const index = cart.findIndex(v => v.id === id);
  
    wx.showModal({
      title: '提示',
      content: '将此产品移除购物车？',
      success: res=> {
        if (res.confirm) {
            cart.splice(index, 1);
            this.setCart(cart)
            return
        }
      }
    })
  
  //cart[index].num += opration
  this.setCart(cart)
 },
//结算
async allPlay() {
  const { totalNum, address } = this.data;
  if (!address.addressName) {
      await showToast('未填联系方式')
  } else if (totalNum === 0) {
      await showToast('未选择商品')
  } else {
      wx.navigateTo({
          url: '/pages/pay/pay',
      })
  }

},
//更新购物车数据
setCart(cart) {
  let totalPrice = 0;
  let totalNum = 0;
  let allChecked = true
  cart.forEach(v => {
      if (v.checked) {
          totalPrice += v.realPrice;
          totalNum += v.num
      } else {
          allChecked = false
      }
  });
  allChecked = cart.length ? allChecked : false
  this.setData({
      cart,
      allChecked,
      totalPrice,
      totalNum
  })
  wx.setStorageSync('cart', cart)
  if(this.data.userInfo.id == null || this.data.userInfo.id == ''){
  wx.setStorageSync('cart', '')
  }
},
//地址选择
chooseAdrs(){
  console.log("地址选择");
  let userInfo=this.data.userInfo;
  if(userInfo.id){
    wx.navigateTo({
      url: '/pages/address/addressList/addressList',
    })
  }else{
    wx.showToast({
      title: '请先登录',
      icon:'none'
    })
  }
}
})