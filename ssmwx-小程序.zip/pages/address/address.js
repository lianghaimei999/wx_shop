
var app = getApp()
Page({
  data: {
    thingCampus: ["0校区", "1校区","2校区","3校区"],
    thingCampusIndex: 0,
    thingSushe: ["1号组团", "2号组团"],
    thingSusheIndex: 0,
    name:'',
    phone:'',
    adrs:'',
    userInfo:{}
  },
  onShow: function () {
    var userInfo = wx.getStorageSync('userInfo');
    this.setData({userInfo:userInfo})
  },
    nameInput(e){
      var name=e.detail.value;
      console.log(name);
        this.setData({
          name:e.detail.value
        }) 
    },
    phoneInput(e){
      var phone=e.detail.value;
      console.log(phone);
        this.setData({
          phone:e.detail.value
        }) 
    },
    adrsInput(e){
      var adrs=e.detail.value;
      console.log(adrs);
        this.setData({
          adrs:e.detail.value
        }) 
    },
    bindThingCampusInput: function(e) { 
      console.log("校区："+e.detail.value);
      console.log(this.data.thingCampus[e.detail.value]); 
      this.setData({
        thingCampusIndex: e.detail.value
      })
    },
    bindCampusChange: function(e) {
      console.log("校区下标"+e.detail.value);
      
      this.setData({
        campusIndex: e.detail.value
      })
    },
    bindSusheInput: function(e) { 
      console.log("组团"+e.detail.value);
     console.log(this.data.thingSushe[e.detail.value]); 
      this.setData({
        thingSusheIndex: e.detail.value
      })
    },
    bindSusheInputChange: function(e) {
      console.log("组团下标"+e.detail.value);
      this.setData({
        susheIndex: e.detail.value
      })
    },
    handleSumit(){
      const {name,phone,adrs,thingCampus, thingCampusIndex,thingSushe,thingSusheIndex,userInfo}=this.data;
      var regPhone = /^1\d{10}$/;
      if(name=='' && phone==''&& adrs==''){
        wx.showToast({
          title: '未输入信息',
          icon:'none',
          duration: 1000
        })
      }else if(name==''){
        wx.showToast({
          title: '未输入收货人姓名',
          icon:'none',
          duration: 1000
        })
      }else if(phone==''||!regPhone.test(phone)){
        wx.showToast({
          title: '收货人电话输入有误',
          icon:'none',
          duration: 1000
        })
      }else if(adrs==''){
        wx.showToast({
          title: '未输入详细地址信息',
          icon:'none',
          duration: 1000
        })
      }else{
        console.log("地址校验正确");
        wx.request({
          url: "http://localhost:8888/ssmShop/address",
          data: {
            userId:userInfo.id,
            adrs:adrs,
            province:thingCampus[thingCampusIndex],
            city:thingSushe[thingSusheIndex],
            addressName:name,
            addressPhone:phone
          },
          method:'POST',
          header:{
            'content-type':'application/x-www-form-urlencoded'
          },
          success: (res)=>{
            console.log(res);
            if(res.data.code==100){
              wx.showToast({
                title: '地址添加成功',
                icon: 'success',
                mask: true,
              });
              this.setData({
                name:'',
                phone:'',
                adrs:''
              })
              wx.navigateBack({
                delta: 1,
              })
            }
          } 
        })
      }
    }
})
