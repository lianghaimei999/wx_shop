var app = getApp()
Page({
  data: {
    address: [],
    address1:[],
    radioindex: '',
    userid:0,
    userInfo:{}
  },
  onShow: function (options) {
    this.getAddress();
  },
  onLoad: function (options) {
    var radioindex = wx.getStorageSync('radioindex')
    var userInfo = wx.getStorageSync('userInfo')
    //console.log("个人中心userid:"+options.userid);
    
    this.setData({
      //userid:options.userid,
      radioindex:radioindex,
      userInfo:userInfo
    })
   },
   getAddress(){
     var that = this;
     let userid=that.data.userInfo.id;
     console.log(userid);
      wx.request({
        url:'http://localhost:8888/ssmShop/address2',
        success: function (res) {
         // console.log(res.data.extend.address)
            let address = res.data.extend.address;
            let newArr1=[];
            address.forEach(function(item){
              if(userid ==item.userId){
                console.log(userid);
                newArr1.push({
                  adId:item.adId,
                  userId:item.userId,
                  adrs:item.adrs,
                  province:item.province,
                  city:item.city,
                  country:item.country,
                  addressName:item.addressName,
                  addressPhone:item.addressPhone,
                  xx:item.xx
                });
               
              }
            })
            
            that.setData({
                address1:newArr1,
                address:address
              }); 
              console.log(that.data.address1);
      }})
   },

  radioChange (e) {
    var index = e.detail.value;
    var userInfo=this.data.userInfo;
    console.log("radioChange:"+e.detail.value);
    if(userInfo.id){
      wx.setStorageSync('radioindex', e.detail.value)
      wx.setStorageSync('address', this.data.address1[index])
    console.log(this.data.address1[index]);
    }else if(!userInfo.id){
      wx.setStorageSync('address', [])
    }
    
    this.onLoad()
  },

  delAddress:function (event) {
    var address = this.data.address1
    var id=event.currentTarget.dataset.id;
    var name=event.currentTarget.dataset.name;
    console.log("删除"+id);
    wx.showModal({
      title: '提示',
      content: '你确认移除'+[name]+'吗',
      success: function(res) {
        if(res.confirm){
         wx.request({
          url:'http://localhost:8888/ssmShop/address1/'+id,
          method:'DELETE',
          success: function (res) {
            if(res.data.code==100){
              wx.showToast({
                title: '',
                icon:'loading',
                duration:1000
              })
            }else{
              wx.showToast({
                title: '',
                icon:'success',
                duration:1000
              })
            }
            //todo
            // if(data.result == 'ok'){
            //   //that.data.productData.length =0;
            //   that.loadProductData();
            // }
          },
          fail:function(res){
            wx.showToast({
              title: '服务器或者网络错误',
              icon:'loading',
              duration:1000
            })
          }
    });
        }
    }})
  },
  addAddress:function(event){
    let userInfo=this.data.userInfo;
    if(userInfo.id){
      wx.navigateTo({
        url: '/pages/address/address',
      })
    }else{
      wx.showToast({
        title: '请先登录',
        icon:'none'
      })
    }
  }



})
