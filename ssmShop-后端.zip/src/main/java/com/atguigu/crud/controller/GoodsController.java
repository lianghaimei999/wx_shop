package com.atguigu.crud.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Comments;
import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.service.GoodsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * 处理CRUD请求
 * 
 * @author lhm
 * 
 */
@Controller
public class GoodsController {

	@Autowired
	GoodsService goodsService;
	
	
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/good/{ids}",method=RequestMethod.DELETE)
	public Msg delete(@PathVariable("ids")String ids){
		if(ids.contains("-")){
			List<Integer> del_ids = new ArrayList<>();
			String[] str_ids = ids.split("-");
			//组装id的集合
			for (String string : str_ids) {
				del_ids.add(Integer.parseInt(string));
			}
			goodsService.deleteBatch(del_ids);
		}else{
			Integer id = Integer.parseInt(ids);
			goodsService.delete(id);
		}
		return Msg.success();
	}
	/**
	 * 更新方法
	 * @param goods
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/good/{id}",method=RequestMethod.PUT)
	public Msg save(Goods goods,HttpServletRequest request){
		goodsService.update(goods);
		return Msg.success();
	}
	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/good/{id}",method=RequestMethod.GET)
	@ResponseBody
	public Msg get(@PathVariable("id")Integer id){
		Goods good = goodsService.get(id);
		return Msg.success().add("good", good);
	}
	/**
	 * 保存
	 * 
	 * @return
	 */
	@RequestMapping(value="/good",method=RequestMethod.POST)
	@ResponseBody
	public Msg save(@Valid Goods goods,BindingResult result){
		if(result.hasErrors()){
			Map<String, Object> map = new HashMap<>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				System.out.println("错误的字段名："+fieldError.getField());
				System.out.println("错误信息："+fieldError.getDefaultMessage());
				map.put(fieldError.getField(), fieldError.getDefaultMessage());
			}
			return Msg.fail().add("errorFields", map);
		}else{
			goodsService.save(goods);
			System.out.println("新增good的信息"+goods);
			return Msg.success();
		}
	}
	
	/**
	 * 查询数据，不分页
	 * @return
	 */
	@RequestMapping("/goods1")
	@ResponseBody
	public Msg getAll() {
		List<Goods> goods = goodsService.getAll();
		return Msg.success().add("goods", goods);
	}
	/**
	 * 查询，分页
	 * @param pn
	 * @return
	 */
	@RequestMapping("/goods2")
	@ResponseBody
	public Msg getEmpsWithJson(@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
		PageHelper.startPage(pn, 10);
		List<Goods> goods = goodsService.getAll();
		PageInfo page = new PageInfo(goods, 5);
		return Msg.success().add("pageInfo", page);
	}
	
	/**
	 * 条件查询
	 * @param goods
	 * @param pn
	 * @return
	 */
	@RequestMapping("/listByObjGoods")
	@ResponseBody
	public Msg listByObj(Goods goods,@RequestParam(value = "pn", defaultValue = "1") Integer pn){
		System.out.println("getGoodName:"+goods.getGoodName());
		PageHelper.startPage(pn, 10);
		List<Goods> list = goodsService.listByObj(goods);
		System.out.println(list);
		PageInfo page = new PageInfo(list, 5);
		return Msg.success().add("pageInfo", page);
	}
	
	/**
	 * 模糊查询
	 * @param goodName
	 * @return
	 */
	@RequestMapping("selectquery")
	@ResponseBody
	public Msg query(@RequestParam(value="goodName")String goodName){
		//String goodName=reques.getParameter("goodName");
		System.out.println("goodName==>"+goodName);
		List<Goods> goods = goodsService.selectquery(goodName);
		System.out.println("good:"+goods);
	    return Msg.success().add("goods", goods);
		 
	}
}
