package com.atguigu.crud.controller;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.atguigu.crud.bean.Msg;

@Controller
public class CeshiController {
	@RequestMapping("/fileUpload")
	public Msg upload(HttpServletRequest request, HttpServletResponse response) {
			//判断请求内容是否是 multipart/from-data 类型
				if(ServletFileUpload.isMultipartContent(request)) {
					DiskFileItemFactory fif = new DiskFileItemFactory();
					
					//设置文件缓冲区大小为2M
					fif.setSizeThreshold(1024*1024*2);
					
					//当上传文件超过缓冲区大小时，启用临时文件夹进行缓存（暂存）
					fif.setRepository(new File("c:/upload/temp"));	
					
					ServletFileUpload upload = new ServletFileUpload(fif);
					//设置上传的单个文件的最大值是4M
					upload.setSizeMax(1024*1024*5);		
					try {
						List<FileItem> items = upload.parseRequest(request);
						Iterator<FileItem> it = items.iterator();
						while(it.hasNext()) {
							FileItem item = it.next();
							//1. 文本域
							if(item.isFormField()) {
								//TODO:
								String name = item.getFieldName();
								String value = item.getString();
							}
							//2. 文件域
							else {
								String fileName = item.getName();
								if(null != fileName && !fileName.equals("")) {
									// 设置文件上传路径
									File file = new File("c:/upload", fileName);
									item.write(file);
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
		
	}
				return null;
	}
}
