package com.atguigu.crud.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Admin;
import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.Orders;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.dao.AdminMapper;
import com.atguigu.crud.service.AdminService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class AdminController {
	@Autowired
	AdminService adminService; 
	
	@RequestMapping("/adminLogin")
	@ResponseBody
	public Msg loginController(@RequestParam("phone")String phone,@RequestParam("password")String password){
		System.out.println(phone);
		System.out.println(password);
		Map<String,String> map = new HashMap<>();
		Admin registerUser = adminService.getUserByAccountAndPassword(phone, password);//数据库匹配查询
		System.out.println(registerUser);
		return Msg.success().add("adminInfo", registerUser);
	}

}
