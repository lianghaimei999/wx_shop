package com.atguigu.crud.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.Notice;
import com.atguigu.crud.bean.Purse;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.service.NoticeService;
import com.atguigu.crud.service.PurseService;
import com.atguigu.crud.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * 处理CRUD请求
 * 
 * @author lhm
 * 
 */
@Controller
public class NoticeController {

	@Autowired
	NoticeService noticeService;
	
	
	@RequestMapping(value="/notice",method=RequestMethod.POST)
	@ResponseBody
	public Msg save(@Valid Notice goods,BindingResult result){
		if(result.hasErrors()){
			Map<String, Object> map = new HashMap<>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				System.out.println("错误的字段名："+fieldError.getField());
				System.out.println("错误信息："+fieldError.getDefaultMessage());
				map.put(fieldError.getField(), fieldError.getDefaultMessage());
			}
			return Msg.fail().add("errorFields", map);
		}else{
			noticeService.save(goods);
			return Msg.success();
		}
	}
	
	@ResponseBody
	@RequestMapping(value="/notice/{ids}",method=RequestMethod.DELETE)
	public Msg delete(@PathVariable("ids")String ids){
		if(ids.contains("-")){
			List<Integer> del_ids = new ArrayList<>();
			String[] str_ids = ids.split("-");
			//组装id的集合
			for (String string : str_ids) {
				del_ids.add(Integer.parseInt(string));
			}
			noticeService.deleteBatch(del_ids);
		}else{
			Integer id = Integer.parseInt(ids);
			noticeService.delete(id);
		}
		return Msg.success();
	}

	/**
	 * 导入jackson包。
	 * @param pn
	 * @return
	 */
	@RequestMapping("/notice")
	@ResponseBody
	public Msg getEmpsWithJson(){
		List<Notice> emps = noticeService.getAll();
		return Msg.success().add("notice", emps);
		
	}
	@RequestMapping("/notice2")
	@ResponseBody
	public Msg getEmpsWithJson1(@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
		PageHelper.startPage(pn, 10);
		List<Notice> emps = noticeService.getAll();
		PageInfo page = new PageInfo(emps, 5);
		return Msg.success().add("pageInfo", page);
	}
	
}
