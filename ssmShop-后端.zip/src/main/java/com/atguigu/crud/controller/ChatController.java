package com.atguigu.crud.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Chat;
import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.service.ChatService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class ChatController {
	
	@Autowired
	ChatService chatService;
	
	@RequestMapping(value="/chat",method=RequestMethod.POST)
	@ResponseBody
	public Msg save(@Valid Chat chat,BindingResult result){
		if(result.hasErrors()){
			Map<String, Object> map = new HashMap<>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				System.out.println("错误的字段名："+fieldError.getField());
				System.out.println("错误信息："+fieldError.getDefaultMessage());
				map.put(fieldError.getField(), fieldError.getDefaultMessage());
			}
			return Msg.fail().add("errorFields", map);
		}else{
			chatService.save(chat);
			System.out.println("新增chat的信息"+chat);
			return Msg.success();
		}
	}
	
	/**
	 * 查询数据，不分页
	 * @return
	 */
	@RequestMapping("/chat1")
	@ResponseBody
	public Msg getAll() {
		List<Chat> chat = chatService.getAll();
		return Msg.success().add("chat", chat);
	}
	/**
	 * 导入jackson包。
	 * @param pn
	 * @return
	 */
	@RequestMapping("/chat2")
	@ResponseBody
	public Msg getEmpsWithJson(@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
		PageHelper.startPage(pn, 10);
		List<Chat> chat = chatService.getAll();
		PageInfo page = new PageInfo(chat, 5);
		return Msg.success().add("pageInfo", page);
	}
}
