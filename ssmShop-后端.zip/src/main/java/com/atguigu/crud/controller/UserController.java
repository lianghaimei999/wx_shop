package com.atguigu.crud.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.service.UserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
/**
 * 处理CRUD请求
 * 
 * @author lhm
 * 
 */
@Controller
public class UserController {

	@Autowired
	UserService userService;
	
	
	/**
	 * 单个批量二合一
	 * 批量删除：1-2-3
	 * 单个删除：1
	 * 
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/emp/{ids}",method=RequestMethod.DELETE)
	public Msg deleteEmp(@PathVariable("ids")String ids){
		//批量删除
		if(ids.contains("-")){
			List<Integer> del_ids = new ArrayList<>();
			String[] str_ids = ids.split("-");
			//组装id的集合
			for (String string : str_ids) {
				del_ids.add(Integer.parseInt(string));
			}
			userService.deleteBatch(del_ids);
		}else{
			Integer id = Integer.parseInt(ids);
			userService.deleteEmp(id);
		}
		return Msg.success();
	}
	
	/**
	 * 更新
	 * @param user
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/emp/{id}",method=RequestMethod.PUT)
	public Msg saveEmp(User user,HttpServletRequest request){
		//System.out.println("请求体中的值："+request.getParameter("gender"));
		//System.out.println("将要更新的员工数据："+user);
		userService.updateEmp(user);
		return Msg.success()	;
	}
	
	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/emp/{id}",method=RequestMethod.GET)
	@ResponseBody
	public Msg getEmp(@PathVariable("id")Integer id){
		
		User user = userService.getEmp(id);
		System.out.println("查询"+user);
		return Msg.success().add("emp", user);
	}
	
	/**
	 * 检查用户名是否可用
	 * @param userName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/checkuser")
	public Msg checkuser(@RequestParam("userName")String userName){
		System.out.println("1"+userName);
		//先判断用户名是否是合法的表达式;
		String regx = "(^[a-zA-Z0-9_-]{6,16}$)|(^[\u2E80-\u9FFF]{2,5})";
		if(!userName.matches(regx)){
			return Msg.fail().add("va_msg", "用户名必须是6-16位数字和字母的组合或者2-5位中文");
		}
		
		//数据库用户名重复校验
		boolean b = userService.checkUser(userName);
		System.out.println("2"+userName);
		if(b){
			return Msg.success();
		}else{
			return Msg.fail().add("va_msg", "用户名不可用");
		}
	}

	
	/**
	 * 员工保存
	 * 1、支持JSR303校验
	 * 2、导入Hibernate-Validator
	 * 
	 * 
	 * @return
	 */
	@RequestMapping(value="/emp",method=RequestMethod.POST)
	@ResponseBody
	public Msg saveEmp(@Valid User user,BindingResult result){
		System.out.println("phone:"+user.getPhone());
		if(result.hasErrors()){
			//校验失败，应该返回失败，在模态框中显示校验失败的错误信息
			Map<String, Object> map = new HashMap<>();
			List<FieldError> errors = result.getFieldErrors();
			for (FieldError fieldError : errors) {
				System.out.println("错误的字段名："+fieldError.getField());
				System.out.println("错误信息："+fieldError.getDefaultMessage());
				map.put(fieldError.getField(), fieldError.getDefaultMessage());
			}
			return Msg.fail().add("errorFields", map);
		}else{
			userService.saveEmp(user);
			System.out.println("新增的userphone信息"+user);
			return Msg.success();
		}
		
	}
	
	/**
	 * 查询
	 * @return
	 */
	@RequestMapping("/emps1")
	@ResponseBody
	public Msg getAll() {
		List<User> user = userService.getAll();
		return Msg.success().add("users", user);
	}
	
	@RequestMapping("/listByObj")
	@ResponseBody
	public Msg listByObj(User user,@RequestParam(value = "pn", defaultValue = "1") Integer pn){
		PageHelper.startPage(pn, 10);
		List<User> list = userService.listByObj(user);
		System.out.println(list);
		PageInfo page = new PageInfo(list, 5);
		return Msg.success().add("pageInfo", page);
	}
	
	/**
	 * 导入jackson包。
	 * @param pn
	 * @return
	 */
	@RequestMapping("/emps")
	@ResponseBody
	public Msg getEmpsWithJson(
			@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
		PageHelper.startPage(pn, 10);
		// startPage后面紧跟的这个查询就是一个分页查询
		List<User> emps = userService.getAll();
		// 使用pageInfo包装查询后的结果，只需要将pageInfo交给页面就行了。
		// 封装了详细的分页信息,包括有我们查询出来的数据，传入连续显示的页数
		PageInfo page = new PageInfo(emps, 5);
		return Msg.success().add("pageInfo", page);
	}
	
	/**
	 * 登录
	 * @param phone
	 * @param password
	 * @return
	 */
	@RequestMapping("/login")
	@ResponseBody
	public Msg loginController(@RequestParam("phone")String phone,@RequestParam("password")String password){
		
		Map<String,String> map = new HashMap<>();
		User registerUser = userService.getUserByAccountAndPassword(phone, password);//数据库匹配查询
		User loginUser = new User(null, phone, null, password, null, null, null, null, null, null);
		System.out.println("phone"+phone);
		System.out.println("password"+password);
		System.out.println("registerUser:"+registerUser);
		if (loginUser.getPhone().equals(registerUser.getPhone()) && loginUser.getPassword().equals(registerUser.getPassword())) {
			System.out.println("loginUser"+loginUser);
			//map.put("message", "ok");
			//map.put("phone", registerUser.getPhone());
		} else {
			System.out.println("loginUser"+loginUser);
			//map.put("message", "err");
		}
		return Msg.success().add("userInfo", registerUser);
	}
	
	/**
	 * 验证手机号唯一
	 * @param phone
	 * @return
	 */
	@RequestMapping("/checkphone")
	@ResponseBody
	public Msg checkPhoneController(@RequestParam("phone")String phone){
		
		Map<String,String> map = new HashMap<>();
		User registerUser = userService.getPhone(phone);
		User loginUser = new User(null, phone, null, null, null, null, null, null, null, null);
		//System.out.println("phone"+phone);
		//System.out.println("registerUser:"+registerUser);
		if(registerUser.getPhone()!=null) {
			if (loginUser.getPhone().equals(registerUser.getPhone())) {
				System.out.println("loginUser"+loginUser);
				//map.put("message", "ok");
				//map.put("phone", registerUser.getPhone());
			} else {
				System.out.println("loginUser"+loginUser);
				//map.put("message", "err");
			}
		}
		return Msg.fail().add("userInfoPhone", registerUser);
	}
	
	@RequestMapping("search")
	@ResponseBody
	public Msg query(@RequestParam(value="username")String username){
		//String goodName=reques.getParameter("goodName");
		System.out.println("username==>"+username);
		List<User> goods = userService.selectquery(username);
		System.out.println("user:"+goods);
	   return Msg.success().add("user", goods);
	    
	   
		 
	}
	
	
}
