package com.atguigu.crud.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Comments;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.Orders;
import com.atguigu.crud.bean.Reply;
import com.atguigu.crud.service.ReplyService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Controller
public class ReplyController {
	@Autowired
	ReplyService replyService;
	
	@ResponseBody
	@RequestMapping(value="/reply/{ids}",method=RequestMethod.DELETE)
	public Msg delete(@PathVariable("ids")String ids){
		//批量删除
		if(ids.contains("-")){
			List<Integer> del_ids = new ArrayList<>();
			String[] str_ids = ids.split("-");
			//组装id的集合
			for (String string : str_ids) {
				del_ids.add(Integer.parseInt(string));
			}
			replyService.deleteBatch(del_ids);
		}else{
			Integer id = Integer.parseInt(ids);
			replyService.delete(id);
		}
		return Msg.success();
	}
	
	/**
	 * 增加
	 * @return
	 */
	@RequestMapping(value="/reply",method=RequestMethod.POST)
	@ResponseBody
	public Msg save(@Valid Reply reply,BindingResult result){
		replyService.save(reply);
		return Msg.success();
		
	}
	
	/**
	 * 查询数据，不分页
	 * @param pn
	 * @return
	 */
	@RequestMapping("/reply1")
	@ResponseBody
	public Msg getAll() {
		List<Reply> reply = replyService.getAll();
		return Msg.success().add("replys", reply);
	}
	
	/**
	 * 查询数据，分页
	 * @param pn
	 * @return
	 */
	@RequestMapping("/reply2")
	@ResponseBody
	public Msg getEmpsWithJson(
			@RequestParam(value = "pn", defaultValue = "1") Integer pn) {

		PageHelper.startPage(pn, 10);
		// startPage后面紧跟的这个查询就是一个分页查询
		List<Reply> orders = replyService.getAll();
		// 使用pageInfo包装查询后的结果，只需要将pageInfo交给页面就行了。
		// 封装了详细的分页信息,包括有我们查询出来的数据，传入连续显示的页数
		PageInfo page = new PageInfo(orders, 5);
		return Msg.success().add("pageInfo", page);
	}
	
}
