package com.atguigu.crud.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atguigu.crud.bean.Catelog;
import com.atguigu.crud.bean.Department;
import com.atguigu.crud.bean.Msg;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.service.CateService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * 处理CRUD请求
 * 
 * @author lhm
 * 
 */
@Controller
public class CateController {

	@Autowired
	CateService cateService;
	
	
	/**
	 * 单个批量二合一
	 * 批量删除：1-2-3
	 * 单个删除：1
	 * 
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/cate/{ids}",method=RequestMethod.DELETE)
	public Msg deleteEmp(@PathVariable("ids")String ids){
		//批量删除
		if(ids.contains("-")){
			List<Integer> del_ids = new ArrayList<>();
			String[] str_ids = ids.split("-");
			//组装id的集合
			for (String string : str_ids) {
				del_ids.add(Integer.parseInt(string));
			}
			cateService.deleteBatch(del_ids);
		}else{
			Integer id = Integer.parseInt(ids);
			System.out.println(ids);
			cateService.deleteEmp(id);
		}
		return Msg.success();
	}
	
	
	/**
	 * 更新
	 * @param cate
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/cate/{id}",method=RequestMethod.PUT)
	public Msg saveEmp(Catelog cate,HttpServletRequest request){
		cateService.updateEmp(cate);
		return Msg.success();
	}
	
	/**
	 * 保存 
	 * @return
	 */
	@RequestMapping(value="/cate",method=RequestMethod.POST)
	@ResponseBody
	public Msg saveEmp(@Valid Catelog cate){
		System.out.println("用户名"+cate.getName());
			cateService.saveEmp(cate);
			System.out.println("新增的信息"+cate);
			return Msg.success();
		
	}
	/**
	 * 根据id查询
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/cate/{id}",method=RequestMethod.GET)
	@ResponseBody
	public Msg getEmp(@PathVariable("id")Integer id){
		
		Catelog cate = cateService.getEmp(id);
		System.out.println("查询"+cate);
		return Msg.success().add("cate", cate);
	}


	/**
	 * 导入jackson包。
	 * @param pn
	 * @return
	 */
	@RequestMapping("/cate")
	@ResponseBody
	public Msg getEmpsWithJson(
			@RequestParam(value = "pn", defaultValue = "1") Integer pn) {
		// 这不是一个分页查询
		// 引入PageHelper分页插件
		// 在查询之前只需要调用，传入页码，以及每页的大小
		PageHelper.startPage(pn, 10);
		// startPage后面紧跟的这个查询就是一个分页查询
		List<Catelog> emps = cateService.getAll();
		// 使用pageInfo包装查询后的结果，只需要将pageInfo交给页面就行了。
		// 封装了详细的分页信息,包括有我们查询出来的数据，传入连续显示的页数
		PageInfo page = new PageInfo(emps, 5);
		return Msg.success().add("pageInfo", page);
	}
	
	/**
	 * 查询员工数据（分页查询）
	 * 
	 * @return
	 */
	// @RequestMapping("/emps")
	public String getEmps(
			/**
			 * Integer pn 分页查询传入页码数pn
			 * defaultValue = "1" 默认1
			 * Model model
			 */
			@RequestParam(value = "pn", defaultValue = "1") Integer pn,
			Model model) {
		// 这不是一个分页查询；
		// 引入PageHelper分页插件
		// 在查询之前只需要调用，传入页码，以及每页的大小
		PageHelper.startPage(pn, 5);
		// startPage后面紧跟的这个查询就是一个分页查询
		List<Catelog> emps = cateService.getAll();
		// 使用pageInfo包装查询后的结果，只需要将pageInfo交给页面就行了。
		// 封装了详细的分页信息,包括有我们查询出来的数据，传入连续显示的页数
		PageInfo page = new PageInfo(emps, 5);
		model.addAttribute("pageInfo", page);

		return "list";
	}
	
	/**
	 * 返回所有的下拉信息
	 */
	@RequestMapping("/catelogOption")
	@ResponseBody
	public Msg getDepts(){
		//查出的所有部门信息
		List<Catelog> list = cateService.get();
		return Msg.success().add("option", list);
	}
	
	@RequestMapping("cates")
	@ResponseBody
	public Msg getXX() {
		 List<Catelog> list = cateService.getXX();
		return Msg.success().add("cates",list);
	}

}
