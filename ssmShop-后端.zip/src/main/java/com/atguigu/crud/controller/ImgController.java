package com.atguigu.crud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.atguigu.crud.service.ImgService;

@Controller
public class ImgController {
	@Autowired
	ImgService imgService;
}
