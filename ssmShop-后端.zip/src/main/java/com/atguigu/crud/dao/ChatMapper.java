package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Chat;
import com.atguigu.crud.bean.ChatExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface ChatMapper {
    long countByExample(ChatExample example);

    int deleteByExample(ChatExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Chat record);

    int insertSelective(Chat record);

    List<Chat> selectByExample(ChatExample example);

    Chat selectByPrimaryKeyWithXX(Integer id);
    
    List<Chat> selectByExampleWithXX(ChatExample example);

    Chat selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Chat record, @Param("example") ChatExample example);

    int updateByExample(@Param("record") Chat record, @Param("example") ChatExample example);

    int updateByPrimaryKeySelective(Chat record);

    int updateByPrimaryKey(Chat record);
    
//    @Select("select * from chat where id = #{id}")
//    @Results({
//            @Result(property = "id",  column = "id"),
//            @Result(property = "idFsf",  column = "id_fsf"),
//            @Result(property = "idJsf",  column = "id_jsf"),
//            @Result(property = "content",  column = "content"),
//            @Result(property = "image",  column = "image"),
//            @Result(property = "lTime",  column = "l_time"),
//            @Result(property = "isLook",  column = "is_look"),
//            @Result(property = "isRemoveFa",  column = "is_remove_fa"),
//            @Result(property = "isRemoveJie",  column = "is_remove_jie"),
//            @Result(property = "chatSignal",  column = "chat_signal"),
//            @Result(property="user1",column="id1",one=@One(select="com.atguigu.crud.dao.UserMapper.getChatById")),
//            @Result(property="user2",column="id2",one=@One(select="com.atguigu.crud.dao.UserMapper.getChatById"))
//           
//    })
//    		Chat ChatById(Integer id);

    
}