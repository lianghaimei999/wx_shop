package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Tzb;
import com.atguigu.crud.bean.TzbExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TzbMapper {
    long countByExample(TzbExample example);

    int deleteByExample(TzbExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Tzb record);

    int insertSelective(Tzb record);

    List<Tzb> selectByExample(TzbExample example);

    Tzb selectByPrimaryKeyWithXX(Integer id);
    
    List<Tzb> selectByExampleWithXX(TzbExample example);

    Tzb selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Tzb record, @Param("example") TzbExample example);

    int updateByExample(@Param("record") Tzb record, @Param("example") TzbExample example);

    int updateByPrimaryKeySelective(Tzb record);

    int updateByPrimaryKey(Tzb record);
}