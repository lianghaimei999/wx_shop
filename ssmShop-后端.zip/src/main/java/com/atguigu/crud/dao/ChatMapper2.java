package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Chat;
import com.atguigu.crud.bean.ChatExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;


import java.util.List;
import org.apache.ibatis.annotations.Param;


public interface ChatMapper2 {
	
	public List<Chat> getChatList(@Param("chat")Chat chat, @Param("page")Integer page, @Param("limit")Integer limit);
	public Integer getChatListCount(@Param("chat")Chat chat);
	public void addChat(@Param("chat")Chat chat);
	public void updateChat(@Param("chat")Chat chat);
	public Chat getChatById(@Param("id")Integer id);
	public void deleteChatById(@Param("id")Integer id);
	//聊天消息
	public List<Chat> findChatList(@Param("chat")Chat chat, @Param("page")Integer page, @Param("limit")Integer limit);
	public Integer findChatListCount(@Param("chat")Chat chat);
	//我的消息
	public List<Chat> myChatList(@Param("chat")Chat chat);
	
	
}
