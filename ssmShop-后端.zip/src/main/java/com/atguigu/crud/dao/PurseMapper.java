package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.EmployeeExample;
import com.atguigu.crud.bean.Purse;
import com.atguigu.crud.bean.PurseExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PurseMapper {
    long countByExample(PurseExample example);

    int deleteByExample(PurseExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Purse record);

    int insertSelective(Purse record);
    
    List<Purse> selectByExampleWithXX(PurseExample example);

    Purse selectByPrimaryKeyWithXX(Integer id);
    
    List<Purse> selectByExample(PurseExample example);

    Purse selectByPrimaryKey(Integer id);
    
    int updateByExampleSelective(@Param("record") Purse record, @Param("example") PurseExample example);

    int updateByExample(@Param("record") Purse record, @Param("example") PurseExample example);

    int updateByPrimaryKeySelective(Purse record);

    int updateByPrimaryKey(Purse record);
}