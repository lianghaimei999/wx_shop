package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Catelog;
import com.atguigu.crud.bean.CatelogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CatelogMapper {
    long countByExample(CatelogExample example);

    int deleteByExample(CatelogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Catelog record);

    int insertSelective(Catelog record);

    List<Catelog> selectByExample(CatelogExample example);

    Catelog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Catelog record, @Param("example") CatelogExample example);

    int updateByExample(@Param("record") Catelog record, @Param("example") CatelogExample example);

    int updateByPrimaryKeySelective(Catelog record);

    int updateByPrimaryKey(Catelog record);
}