package com.atguigu.crud.dao;

import com.atguigu.crud.bean.TzReplay;
import com.atguigu.crud.bean.TzReplayExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TzReplayMapper {
    long countByExample(TzReplayExample example);

    int deleteByExample(TzReplayExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TzReplay record);

    int insertSelective(TzReplay record);

    List<TzReplay> selectByExample(TzReplayExample example);

    TzReplay selectByPrimaryKey(Integer id);
    
    List<TzReplay> selectByExampleWithXX(TzReplayExample example);
    
    TzReplay selectByPrimaryKeyWithXX(Integer id);

    int updateByExampleSelective(@Param("record") TzReplay record, @Param("example") TzReplayExample example);

    int updateByExample(@Param("record") TzReplay record, @Param("example") TzReplayExample example);

    int updateByPrimaryKeySelective(TzReplay record);

    int updateByPrimaryKey(TzReplay record);
}