package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Chat;
import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.bean.UserExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;

public interface UserMapper {
    long countByExample(UserExample example);

    int deleteByExample(UserExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    List<User> selectByExample(UserExample example);
    
    
	List<User> listByObj(User obj);

    User selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") User record, @Param("example") UserExample example);

    int updateByExample(@Param("record") User record, @Param("example") UserExample example);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
    
    List<User> selectquery(@Param("username")String username );
    
    @Select("select * from user where phone=#{param1} and password=#{param2}")
    User getPhonePwd(String phone,String password);
    
    @Select("select * from user where phone=#{param1}")
    User getPhone(String phone);
    
    @Select("select * from user where username=#{param1}")
    boolean getName(String name);
    
    @Select("select * from chat where id=#{id}")
    @Results({
    	@Result(property = "id",column="id"),
    	@Result(property = "username",column="username")
    })
    Chat getChatById(Integer id);

	
}