package com.atguigu.crud.bean;

public class Goods {
    private Integer id;

    private Integer catelogId;

    private Integer userId;

    private String goodName;

    private Float price;

    private Float realPrice;

    private String startTime;

    private String polishTime;

    private String endTime;

    private String describle;

    private Integer status;

    private String imgUrl1;

    private String imgUrl2;

    private String imgUrl3;

    private String imgUrl4;

    private String imgUrl5;

    private String imgUrl6;

    private String imgUrl7;

    private String imgUrl9;

    private String imgUrl8;

    private Catelog catelog;
    
    private User user;

	public Goods() {
		super();
	}

	public Goods(Integer id, Integer catelogId, Integer userId, String goodName, Float price, Float realPrice,
			String startTime, String polishTime, String endTime, String describle, Integer status, String imgUrl1,
			String imgUrl2, String imgUrl3, String imgUrl4, String imgUrl5, String imgUrl6, String imgUrl7,
			String imgUrl9, String imgUrl8, Catelog catelog, User user) {
		super();
		this.id = id;
		this.catelogId = catelogId;
		this.userId = userId;
		this.goodName = goodName;
		this.price = price;
		this.realPrice = realPrice;
		this.startTime = startTime;
		this.polishTime = polishTime;
		this.endTime = endTime;
		this.describle = describle;
		this.status = status;
		this.imgUrl1 = imgUrl1;
		this.imgUrl2 = imgUrl2;
		this.imgUrl3 = imgUrl3;
		this.imgUrl4 = imgUrl4;
		this.imgUrl5 = imgUrl5;
		this.imgUrl6 = imgUrl6;
		this.imgUrl7 = imgUrl7;
		this.imgUrl9 = imgUrl9;
		this.imgUrl8 = imgUrl8;
		this.catelog = catelog;
		this.user = user;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCatelogId() {
		return catelogId;
	}

	public void setCatelogId(Integer catelogId) {
		this.catelogId = catelogId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Float getRealPrice() {
		return realPrice;
	}

	public void setRealPrice(Float realPrice) {
		this.realPrice = realPrice;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getPolishTime() {
		return polishTime;
	}

	public void setPolishTime(String polishTime) {
		this.polishTime = polishTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getDescrible() {
		return describle;
	}

	public void setDescrible(String describle) {
		this.describle = describle;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getImgUrl1() {
		return imgUrl1;
	}

	public void setImgUrl1(String imgUrl1) {
		this.imgUrl1 = imgUrl1;
	}

	public String getImgUrl2() {
		return imgUrl2;
	}

	public void setImgUrl2(String imgUrl2) {
		this.imgUrl2 = imgUrl2;
	}

	public String getImgUrl3() {
		return imgUrl3;
	}

	public void setImgUrl3(String imgUrl3) {
		this.imgUrl3 = imgUrl3;
	}

	public String getImgUrl4() {
		return imgUrl4;
	}

	public void setImgUrl4(String imgUrl4) {
		this.imgUrl4 = imgUrl4;
	}

	public String getImgUrl5() {
		return imgUrl5;
	}

	public void setImgUrl5(String imgUrl5) {
		this.imgUrl5 = imgUrl5;
	}

	public String getImgUrl6() {
		return imgUrl6;
	}

	public void setImgUrl6(String imgUrl6) {
		this.imgUrl6 = imgUrl6;
	}

	public String getImgUrl7() {
		return imgUrl7;
	}

	public void setImgUrl7(String imgUrl7) {
		this.imgUrl7 = imgUrl7;
	}

	public String getImgUrl9() {
		return imgUrl9;
	}

	public void setImgUrl9(String imgUrl9) {
		this.imgUrl9 = imgUrl9;
	}

	public String getImgUrl8() {
		return imgUrl8;
	}

	public void setImgUrl8(String imgUrl8) {
		this.imgUrl8 = imgUrl8;
	}

	public Catelog getCatelog() {
		return catelog;
	}

	public void setCatelog(Catelog catelog) {
		this.catelog = catelog;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Goods [id=" + id + ", catelogId=" + catelogId + ", userId=" + userId + ", goodName=" + goodName
				+ ", price=" + price + ", realPrice=" + realPrice + ", startTime=" + startTime + ", polishTime="
				+ polishTime + ", endTime=" + endTime + ", describle=" + describle + ", status=" + status + ", imgUrl1="
				+ imgUrl1 + ", imgUrl2=" + imgUrl2 + ", imgUrl3=" + imgUrl3 + ", imgUrl4=" + imgUrl4 + ", imgUrl5="
				+ imgUrl5 + ", imgUrl6=" + imgUrl6 + ", imgUrl7=" + imgUrl7 + ", imgUrl9=" + imgUrl9 + ", imgUrl8="
				+ imgUrl8 + ", catelog=" + catelog + ", user=" + user + "]";
	}
}