package com.atguigu.crud.bean;
/**
 * 钱包
 * @author lhm
 *
 */
public class Purse {
    private Integer id;

    private Integer userId;

    private Float balance;

    private Float recharge;

    private Float withdrawals;

    private Integer state;
    
    private User user;

	public Purse() {
		super();
	}

	public Purse(Integer id, Integer userId, Float balance, Float recharge, Float withdrawals, Integer state,
			User user) {
		super();
		this.id = id;
		this.userId = userId;
		this.balance = balance;
		this.recharge = recharge;
		this.withdrawals = withdrawals;
		this.state = state;
		this.user = user;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Float getBalance() {
		return balance;
	}

	public void setBalance(Float balance) {
		this.balance = balance;
	}

	public Float getRecharge() {
		return recharge;
	}

	public void setRecharge(Float recharge) {
		this.recharge = recharge;
	}

	public Float getWithdrawals() {
		return withdrawals;
	}

	public void setWithdrawals(Float withdrawals) {
		this.withdrawals = withdrawals;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

   
}