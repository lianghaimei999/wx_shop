package com.atguigu.crud.bean;
/**
 * 关注/收藏
 * @author lhm
 *
 */
public class Focus {
    private Integer id;

    private Integer goodsId;

    private Integer userId;

    private Goods goods;
    
    private User user;

	public Focus() {
		super();
	}

	public Focus(Integer id, Integer goodsId, Integer userId, Goods goods, User user) {
		super();
		this.id = id;
		this.goodsId = goodsId;
		this.userId = userId;
		this.goods = goods;
		this.user = user;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Focus [id=" + id + ", goodsId=" + goodsId + ", userId=" + userId + ", goods=" + goods + ", user=" + user
				+ "]";
	}
    
    
}