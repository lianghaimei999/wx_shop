package com.atguigu.crud.bean;

import org.apache.ibatis.annotations.One;

public class Chat {
    private Integer id;
    
    private Integer idFsf;

    private Integer idJsf;

    private String content;

    private String image;

    private String lTime;

    private String isLook;

    private String isRemoveFa;

    private String isRemoveJie;

    private String chatSignal;
    private Integer goodId;
    
    private User user;
    

	public Chat() {
		super();
	}


	public Chat(Integer id, Integer idFsf, Integer idJsf, String content, String image, String lTime, String isLook,
			String isRemoveFa, String isRemoveJie, String chatSignal, Integer goodId, User user) {
		super();
		this.id = id;
		this.idFsf = idFsf;
		this.idJsf = idJsf;
		this.content = content;
		this.image = image;
		this.lTime = lTime;
		this.isLook = isLook;
		this.isRemoveFa = isRemoveFa;
		this.isRemoveJie = isRemoveJie;
		this.chatSignal = chatSignal;
		this.goodId = goodId;
		this.user = user;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Integer getIdFsf() {
		return idFsf;
	}


	public void setIdFsf(Integer idFsf) {
		this.idFsf = idFsf;
	}


	public Integer getIdJsf() {
		return idJsf;
	}


	public void setIdJsf(Integer idJsf) {
		this.idJsf = idJsf;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getlTime() {
		return lTime;
	}


	public void setlTime(String lTime) {
		this.lTime = lTime;
	}


	public String getIsLook() {
		return isLook;
	}


	public void setIsLook(String isLook) {
		this.isLook = isLook;
	}


	public String getIsRemoveFa() {
		return isRemoveFa;
	}


	public void setIsRemoveFa(String isRemoveFa) {
		this.isRemoveFa = isRemoveFa;
	}


	public String getIsRemoveJie() {
		return isRemoveJie;
	}


	public void setIsRemoveJie(String isRemoveJie) {
		this.isRemoveJie = isRemoveJie;
	}


	public String getChatSignal() {
		return chatSignal;
	}


	public void setChatSignal(String chatSignal) {
		this.chatSignal = chatSignal;
	}


	public Integer getGoodId() {
		return goodId;
	}


	public void setGoodId(Integer goodId) {
		this.goodId = goodId;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	@Override
	public String toString() {
		return "Chat [id=" + id + ", idFsf=" + idFsf + ", idJsf=" + idJsf + ", content=" + content + ", image=" + image
				+ ", lTime=" + lTime + ", isLook=" + isLook + ", isRemoveFa=" + isRemoveFa + ", isRemoveJie="
				+ isRemoveJie + ", chatSignal=" + chatSignal + ", goodId=" + goodId + ", user=" + user + "]";
	}

	
   
}