package com.atguigu.crud.bean;
/**
 * 评论/留言
 * @author lhm
 *
 */
public class Comments {
    private Integer id;

    private Integer userId;

    private Integer goodsId;

    private String content;

    private String createAt;
    
    private User user;
    
    private Goods goods;

	public Comments() {
		super();
	}

	public Comments(Integer id, Integer userId, Integer goodsId, String content, String createAt, User user,
			Goods goods) {
		super();
		this.id = id;
		this.userId = userId;
		this.goodsId = goodsId;
		this.content = content;
		this.createAt = createAt;
		this.user = user;
		this.goods = goods;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	@Override
	public String toString() {
		return "Comments [id=" + id + ", userId=" + userId + ", goodsId=" + goodsId + ", content=" + content
				+ ", createAt=" + createAt + ", user=" + user + ", goods=" + goods + "]";
	}

   
}