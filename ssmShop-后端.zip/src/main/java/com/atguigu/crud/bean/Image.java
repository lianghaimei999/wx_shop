package com.atguigu.crud.bean;

public class Image {
    private Integer id;

    private Integer goodsId;

    private String imgUrl;

    private String imgUrl1;

    private String imgUrl2;

    private String imgUrl3;

    private String imgUrl4;

    private String imgUrl5;

    private String imgUrl6;

    private String imgUrl7;

    private String imgUrl8;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    public String getImgUrl1() {
        return imgUrl1;
    }

    public void setImgUrl1(String imgUrl1) {
        this.imgUrl1 = imgUrl1 == null ? null : imgUrl1.trim();
    }

    public String getImgUrl2() {
        return imgUrl2;
    }

    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2 == null ? null : imgUrl2.trim();
    }

    public String getImgUrl3() {
        return imgUrl3;
    }

    public void setImgUrl3(String imgUrl3) {
        this.imgUrl3 = imgUrl3 == null ? null : imgUrl3.trim();
    }

    public String getImgUrl4() {
        return imgUrl4;
    }

    public void setImgUrl4(String imgUrl4) {
        this.imgUrl4 = imgUrl4 == null ? null : imgUrl4.trim();
    }

    public String getImgUrl5() {
        return imgUrl5;
    }

    public void setImgUrl5(String imgUrl5) {
        this.imgUrl5 = imgUrl5 == null ? null : imgUrl5.trim();
    }

    public String getImgUrl6() {
        return imgUrl6;
    }

    public void setImgUrl6(String imgUrl6) {
        this.imgUrl6 = imgUrl6 == null ? null : imgUrl6.trim();
    }

    public String getImgUrl7() {
        return imgUrl7;
    }

    public void setImgUrl7(String imgUrl7) {
        this.imgUrl7 = imgUrl7 == null ? null : imgUrl7.trim();
    }

    public String getImgUrl8() {
        return imgUrl8;
    }

    public void setImgUrl8(String imgUrl8) {
        this.imgUrl8 = imgUrl8 == null ? null : imgUrl8.trim();
    }
}