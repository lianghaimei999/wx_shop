package com.atguigu.crud.bean;

public class Reply {
    private Integer id;

    private Integer userId;

    private Integer atuserId;

    private Integer commetId;

    private String content;

    private String createAt;

    private User user;
    
    private Comments comments;

	public Reply() {
		super();
	}

	public Reply(Integer id, Integer userId, Integer atuserId, Integer commetId, String content, String createAt,
			User user, Comments comments) {
		super();
		this.id = id;
		this.userId = userId;
		this.atuserId = atuserId;
		this.commetId = commetId;
		this.content = content;
		this.createAt = createAt;
		this.user = user;
		this.comments = comments;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getAtuserId() {
		return atuserId;
	}

	public void setAtuserId(Integer atuserId) {
		this.atuserId = atuserId;
	}

	public Integer getCommetId() {
		return commetId;
	}

	public void setCommetId(Integer commetId) {
		this.commetId = commetId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCreateAt() {
		return createAt;
	}

	public void setCreateAt(String createAt) {
		this.createAt = createAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Comments getComments() {
		return comments;
	}

	public void setComments(Comments comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Reply [id=" + id + ", userId=" + userId + ", atuserId=" + atuserId + ", commetId=" + commetId
				+ ", content=" + content + ", createAt=" + createAt + ", user=" + user + ", comments=" + comments + "]";
	}
    
    
}