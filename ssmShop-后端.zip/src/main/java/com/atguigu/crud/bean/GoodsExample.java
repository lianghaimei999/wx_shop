package com.atguigu.crud.bean;

import java.util.ArrayList;
import java.util.List;

public class GoodsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public GoodsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andCatelogIdIsNull() {
            addCriterion("catelog_id is null");
            return (Criteria) this;
        }

        public Criteria andCatelogIdIsNotNull() {
            addCriterion("catelog_id is not null");
            return (Criteria) this;
        }

        public Criteria andCatelogIdEqualTo(Integer value) {
            addCriterion("catelog_id =", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdNotEqualTo(Integer value) {
            addCriterion("catelog_id <>", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdGreaterThan(Integer value) {
            addCriterion("catelog_id >", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("catelog_id >=", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdLessThan(Integer value) {
            addCriterion("catelog_id <", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdLessThanOrEqualTo(Integer value) {
            addCriterion("catelog_id <=", value, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdIn(List<Integer> values) {
            addCriterion("catelog_id in", values, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdNotIn(List<Integer> values) {
            addCriterion("catelog_id not in", values, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdBetween(Integer value1, Integer value2) {
            addCriterion("catelog_id between", value1, value2, "catelogId");
            return (Criteria) this;
        }

        public Criteria andCatelogIdNotBetween(Integer value1, Integer value2) {
            addCriterion("catelog_id not between", value1, value2, "catelogId");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andGoodNameIsNull() {
            addCriterion("good_name is null");
            return (Criteria) this;
        }

        public Criteria andGoodNameIsNotNull() {
            addCriterion("good_name is not null");
            return (Criteria) this;
        }

        public Criteria andGoodNameEqualTo(String value) {
            addCriterion("good_name =", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameNotEqualTo(String value) {
            addCriterion("good_name <>", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameGreaterThan(String value) {
            addCriterion("good_name >", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameGreaterThanOrEqualTo(String value) {
            addCriterion("good_name >=", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameLessThan(String value) {
            addCriterion("good_name <", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameLessThanOrEqualTo(String value) {
            addCriterion("good_name <=", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameLike(String value) {
            addCriterion("good_name like", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameNotLike(String value) {
            addCriterion("good_name not like", value, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameIn(List<String> values) {
            addCriterion("good_name in", values, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameNotIn(List<String> values) {
            addCriterion("good_name not in", values, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameBetween(String value1, String value2) {
            addCriterion("good_name between", value1, value2, "goodName");
            return (Criteria) this;
        }

        public Criteria andGoodNameNotBetween(String value1, String value2) {
            addCriterion("good_name not between", value1, value2, "goodName");
            return (Criteria) this;
        }

        public Criteria andPriceIsNull() {
            addCriterion("price is null");
            return (Criteria) this;
        }

        public Criteria andPriceIsNotNull() {
            addCriterion("price is not null");
            return (Criteria) this;
        }

        public Criteria andPriceEqualTo(Float value) {
            addCriterion("price =", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotEqualTo(Float value) {
            addCriterion("price <>", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThan(Float value) {
            addCriterion("price >", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceGreaterThanOrEqualTo(Float value) {
            addCriterion("price >=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThan(Float value) {
            addCriterion("price <", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceLessThanOrEqualTo(Float value) {
            addCriterion("price <=", value, "price");
            return (Criteria) this;
        }

        public Criteria andPriceIn(List<Float> values) {
            addCriterion("price in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotIn(List<Float> values) {
            addCriterion("price not in", values, "price");
            return (Criteria) this;
        }

        public Criteria andPriceBetween(Float value1, Float value2) {
            addCriterion("price between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andPriceNotBetween(Float value1, Float value2) {
            addCriterion("price not between", value1, value2, "price");
            return (Criteria) this;
        }

        public Criteria andRealPriceIsNull() {
            addCriterion("real_price is null");
            return (Criteria) this;
        }

        public Criteria andRealPriceIsNotNull() {
            addCriterion("real_price is not null");
            return (Criteria) this;
        }

        public Criteria andRealPriceEqualTo(Float value) {
            addCriterion("real_price =", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceNotEqualTo(Float value) {
            addCriterion("real_price <>", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceGreaterThan(Float value) {
            addCriterion("real_price >", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceGreaterThanOrEqualTo(Float value) {
            addCriterion("real_price >=", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceLessThan(Float value) {
            addCriterion("real_price <", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceLessThanOrEqualTo(Float value) {
            addCriterion("real_price <=", value, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceIn(List<Float> values) {
            addCriterion("real_price in", values, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceNotIn(List<Float> values) {
            addCriterion("real_price not in", values, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceBetween(Float value1, Float value2) {
            addCriterion("real_price between", value1, value2, "realPrice");
            return (Criteria) this;
        }

        public Criteria andRealPriceNotBetween(Float value1, Float value2) {
            addCriterion("real_price not between", value1, value2, "realPrice");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNull() {
            addCriterion("start_time is null");
            return (Criteria) this;
        }

        public Criteria andStartTimeIsNotNull() {
            addCriterion("start_time is not null");
            return (Criteria) this;
        }

        public Criteria andStartTimeEqualTo(String value) {
            addCriterion("start_time =", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotEqualTo(String value) {
            addCriterion("start_time <>", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThan(String value) {
            addCriterion("start_time >", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeGreaterThanOrEqualTo(String value) {
            addCriterion("start_time >=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThan(String value) {
            addCriterion("start_time <", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLessThanOrEqualTo(String value) {
            addCriterion("start_time <=", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeLike(String value) {
            addCriterion("start_time like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotLike(String value) {
            addCriterion("start_time not like", value, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeIn(List<String> values) {
            addCriterion("start_time in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotIn(List<String> values) {
            addCriterion("start_time not in", values, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeBetween(String value1, String value2) {
            addCriterion("start_time between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andStartTimeNotBetween(String value1, String value2) {
            addCriterion("start_time not between", value1, value2, "startTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeIsNull() {
            addCriterion("polish_time is null");
            return (Criteria) this;
        }

        public Criteria andPolishTimeIsNotNull() {
            addCriterion("polish_time is not null");
            return (Criteria) this;
        }

        public Criteria andPolishTimeEqualTo(String value) {
            addCriterion("polish_time =", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeNotEqualTo(String value) {
            addCriterion("polish_time <>", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeGreaterThan(String value) {
            addCriterion("polish_time >", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeGreaterThanOrEqualTo(String value) {
            addCriterion("polish_time >=", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeLessThan(String value) {
            addCriterion("polish_time <", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeLessThanOrEqualTo(String value) {
            addCriterion("polish_time <=", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeLike(String value) {
            addCriterion("polish_time like", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeNotLike(String value) {
            addCriterion("polish_time not like", value, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeIn(List<String> values) {
            addCriterion("polish_time in", values, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeNotIn(List<String> values) {
            addCriterion("polish_time not in", values, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeBetween(String value1, String value2) {
            addCriterion("polish_time between", value1, value2, "polishTime");
            return (Criteria) this;
        }

        public Criteria andPolishTimeNotBetween(String value1, String value2) {
            addCriterion("polish_time not between", value1, value2, "polishTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNull() {
            addCriterion("end_time is null");
            return (Criteria) this;
        }

        public Criteria andEndTimeIsNotNull() {
            addCriterion("end_time is not null");
            return (Criteria) this;
        }

        public Criteria andEndTimeEqualTo(String value) {
            addCriterion("end_time =", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotEqualTo(String value) {
            addCriterion("end_time <>", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThan(String value) {
            addCriterion("end_time >", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeGreaterThanOrEqualTo(String value) {
            addCriterion("end_time >=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThan(String value) {
            addCriterion("end_time <", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLessThanOrEqualTo(String value) {
            addCriterion("end_time <=", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeLike(String value) {
            addCriterion("end_time like", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotLike(String value) {
            addCriterion("end_time not like", value, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeIn(List<String> values) {
            addCriterion("end_time in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotIn(List<String> values) {
            addCriterion("end_time not in", values, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeBetween(String value1, String value2) {
            addCriterion("end_time between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andEndTimeNotBetween(String value1, String value2) {
            addCriterion("end_time not between", value1, value2, "endTime");
            return (Criteria) this;
        }

        public Criteria andDescribleIsNull() {
            addCriterion("describle is null");
            return (Criteria) this;
        }

        public Criteria andDescribleIsNotNull() {
            addCriterion("describle is not null");
            return (Criteria) this;
        }

        public Criteria andDescribleEqualTo(String value) {
            addCriterion("describle =", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleNotEqualTo(String value) {
            addCriterion("describle <>", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleGreaterThan(String value) {
            addCriterion("describle >", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleGreaterThanOrEqualTo(String value) {
            addCriterion("describle >=", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleLessThan(String value) {
            addCriterion("describle <", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleLessThanOrEqualTo(String value) {
            addCriterion("describle <=", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleLike(String value) {
            addCriterion("describle like", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleNotLike(String value) {
            addCriterion("describle not like", value, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleIn(List<String> values) {
            addCriterion("describle in", values, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleNotIn(List<String> values) {
            addCriterion("describle not in", values, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleBetween(String value1, String value2) {
            addCriterion("describle between", value1, value2, "describle");
            return (Criteria) this;
        }

        public Criteria andDescribleNotBetween(String value1, String value2) {
            addCriterion("describle not between", value1, value2, "describle");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andImgUrl1IsNull() {
            addCriterion("img_url1 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl1IsNotNull() {
            addCriterion("img_url1 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl1EqualTo(String value) {
            addCriterion("img_url1 =", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1NotEqualTo(String value) {
            addCriterion("img_url1 <>", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1GreaterThan(String value) {
            addCriterion("img_url1 >", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1GreaterThanOrEqualTo(String value) {
            addCriterion("img_url1 >=", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1LessThan(String value) {
            addCriterion("img_url1 <", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1LessThanOrEqualTo(String value) {
            addCriterion("img_url1 <=", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1Like(String value) {
            addCriterion("img_url1 like", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1NotLike(String value) {
            addCriterion("img_url1 not like", value, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1In(List<String> values) {
            addCriterion("img_url1 in", values, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1NotIn(List<String> values) {
            addCriterion("img_url1 not in", values, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1Between(String value1, String value2) {
            addCriterion("img_url1 between", value1, value2, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl1NotBetween(String value1, String value2) {
            addCriterion("img_url1 not between", value1, value2, "imgUrl1");
            return (Criteria) this;
        }

        public Criteria andImgUrl2IsNull() {
            addCriterion("img_url2 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl2IsNotNull() {
            addCriterion("img_url2 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl2EqualTo(String value) {
            addCriterion("img_url2 =", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2NotEqualTo(String value) {
            addCriterion("img_url2 <>", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2GreaterThan(String value) {
            addCriterion("img_url2 >", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2GreaterThanOrEqualTo(String value) {
            addCriterion("img_url2 >=", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2LessThan(String value) {
            addCriterion("img_url2 <", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2LessThanOrEqualTo(String value) {
            addCriterion("img_url2 <=", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2Like(String value) {
            addCriterion("img_url2 like", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2NotLike(String value) {
            addCriterion("img_url2 not like", value, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2In(List<String> values) {
            addCriterion("img_url2 in", values, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2NotIn(List<String> values) {
            addCriterion("img_url2 not in", values, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2Between(String value1, String value2) {
            addCriterion("img_url2 between", value1, value2, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl2NotBetween(String value1, String value2) {
            addCriterion("img_url2 not between", value1, value2, "imgUrl2");
            return (Criteria) this;
        }

        public Criteria andImgUrl3IsNull() {
            addCriterion("img_url3 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl3IsNotNull() {
            addCriterion("img_url3 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl3EqualTo(String value) {
            addCriterion("img_url3 =", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3NotEqualTo(String value) {
            addCriterion("img_url3 <>", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3GreaterThan(String value) {
            addCriterion("img_url3 >", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3GreaterThanOrEqualTo(String value) {
            addCriterion("img_url3 >=", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3LessThan(String value) {
            addCriterion("img_url3 <", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3LessThanOrEqualTo(String value) {
            addCriterion("img_url3 <=", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3Like(String value) {
            addCriterion("img_url3 like", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3NotLike(String value) {
            addCriterion("img_url3 not like", value, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3In(List<String> values) {
            addCriterion("img_url3 in", values, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3NotIn(List<String> values) {
            addCriterion("img_url3 not in", values, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3Between(String value1, String value2) {
            addCriterion("img_url3 between", value1, value2, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl3NotBetween(String value1, String value2) {
            addCriterion("img_url3 not between", value1, value2, "imgUrl3");
            return (Criteria) this;
        }

        public Criteria andImgUrl4IsNull() {
            addCriterion("img_url4 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl4IsNotNull() {
            addCriterion("img_url4 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl4EqualTo(String value) {
            addCriterion("img_url4 =", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4NotEqualTo(String value) {
            addCriterion("img_url4 <>", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4GreaterThan(String value) {
            addCriterion("img_url4 >", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4GreaterThanOrEqualTo(String value) {
            addCriterion("img_url4 >=", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4LessThan(String value) {
            addCriterion("img_url4 <", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4LessThanOrEqualTo(String value) {
            addCriterion("img_url4 <=", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4Like(String value) {
            addCriterion("img_url4 like", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4NotLike(String value) {
            addCriterion("img_url4 not like", value, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4In(List<String> values) {
            addCriterion("img_url4 in", values, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4NotIn(List<String> values) {
            addCriterion("img_url4 not in", values, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4Between(String value1, String value2) {
            addCriterion("img_url4 between", value1, value2, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl4NotBetween(String value1, String value2) {
            addCriterion("img_url4 not between", value1, value2, "imgUrl4");
            return (Criteria) this;
        }

        public Criteria andImgUrl5IsNull() {
            addCriterion("img_url5 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl5IsNotNull() {
            addCriterion("img_url5 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl5EqualTo(String value) {
            addCriterion("img_url5 =", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5NotEqualTo(String value) {
            addCriterion("img_url5 <>", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5GreaterThan(String value) {
            addCriterion("img_url5 >", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5GreaterThanOrEqualTo(String value) {
            addCriterion("img_url5 >=", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5LessThan(String value) {
            addCriterion("img_url5 <", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5LessThanOrEqualTo(String value) {
            addCriterion("img_url5 <=", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5Like(String value) {
            addCriterion("img_url5 like", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5NotLike(String value) {
            addCriterion("img_url5 not like", value, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5In(List<String> values) {
            addCriterion("img_url5 in", values, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5NotIn(List<String> values) {
            addCriterion("img_url5 not in", values, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5Between(String value1, String value2) {
            addCriterion("img_url5 between", value1, value2, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl5NotBetween(String value1, String value2) {
            addCriterion("img_url5 not between", value1, value2, "imgUrl5");
            return (Criteria) this;
        }

        public Criteria andImgUrl6IsNull() {
            addCriterion("img_url6 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl6IsNotNull() {
            addCriterion("img_url6 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl6EqualTo(String value) {
            addCriterion("img_url6 =", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6NotEqualTo(String value) {
            addCriterion("img_url6 <>", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6GreaterThan(String value) {
            addCriterion("img_url6 >", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6GreaterThanOrEqualTo(String value) {
            addCriterion("img_url6 >=", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6LessThan(String value) {
            addCriterion("img_url6 <", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6LessThanOrEqualTo(String value) {
            addCriterion("img_url6 <=", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6Like(String value) {
            addCriterion("img_url6 like", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6NotLike(String value) {
            addCriterion("img_url6 not like", value, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6In(List<String> values) {
            addCriterion("img_url6 in", values, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6NotIn(List<String> values) {
            addCriterion("img_url6 not in", values, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6Between(String value1, String value2) {
            addCriterion("img_url6 between", value1, value2, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl6NotBetween(String value1, String value2) {
            addCriterion("img_url6 not between", value1, value2, "imgUrl6");
            return (Criteria) this;
        }

        public Criteria andImgUrl7IsNull() {
            addCriterion("img_url7 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl7IsNotNull() {
            addCriterion("img_url7 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl7EqualTo(String value) {
            addCriterion("img_url7 =", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7NotEqualTo(String value) {
            addCriterion("img_url7 <>", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7GreaterThan(String value) {
            addCriterion("img_url7 >", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7GreaterThanOrEqualTo(String value) {
            addCriterion("img_url7 >=", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7LessThan(String value) {
            addCriterion("img_url7 <", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7LessThanOrEqualTo(String value) {
            addCriterion("img_url7 <=", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7Like(String value) {
            addCriterion("img_url7 like", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7NotLike(String value) {
            addCriterion("img_url7 not like", value, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7In(List<String> values) {
            addCriterion("img_url7 in", values, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7NotIn(List<String> values) {
            addCriterion("img_url7 not in", values, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7Between(String value1, String value2) {
            addCriterion("img_url7 between", value1, value2, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl7NotBetween(String value1, String value2) {
            addCriterion("img_url7 not between", value1, value2, "imgUrl7");
            return (Criteria) this;
        }

        public Criteria andImgUrl9IsNull() {
            addCriterion("img_url9 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl9IsNotNull() {
            addCriterion("img_url9 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl9EqualTo(String value) {
            addCriterion("img_url9 =", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9NotEqualTo(String value) {
            addCriterion("img_url9 <>", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9GreaterThan(String value) {
            addCriterion("img_url9 >", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9GreaterThanOrEqualTo(String value) {
            addCriterion("img_url9 >=", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9LessThan(String value) {
            addCriterion("img_url9 <", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9LessThanOrEqualTo(String value) {
            addCriterion("img_url9 <=", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9Like(String value) {
            addCriterion("img_url9 like", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9NotLike(String value) {
            addCriterion("img_url9 not like", value, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9In(List<String> values) {
            addCriterion("img_url9 in", values, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9NotIn(List<String> values) {
            addCriterion("img_url9 not in", values, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9Between(String value1, String value2) {
            addCriterion("img_url9 between", value1, value2, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl9NotBetween(String value1, String value2) {
            addCriterion("img_url9 not between", value1, value2, "imgUrl9");
            return (Criteria) this;
        }

        public Criteria andImgUrl8IsNull() {
            addCriterion("img_url8 is null");
            return (Criteria) this;
        }

        public Criteria andImgUrl8IsNotNull() {
            addCriterion("img_url8 is not null");
            return (Criteria) this;
        }

        public Criteria andImgUrl8EqualTo(String value) {
            addCriterion("img_url8 =", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8NotEqualTo(String value) {
            addCriterion("img_url8 <>", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8GreaterThan(String value) {
            addCriterion("img_url8 >", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8GreaterThanOrEqualTo(String value) {
            addCriterion("img_url8 >=", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8LessThan(String value) {
            addCriterion("img_url8 <", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8LessThanOrEqualTo(String value) {
            addCriterion("img_url8 <=", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8Like(String value) {
            addCriterion("img_url8 like", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8NotLike(String value) {
            addCriterion("img_url8 not like", value, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8In(List<String> values) {
            addCriterion("img_url8 in", values, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8NotIn(List<String> values) {
            addCriterion("img_url8 not in", values, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8Between(String value1, String value2) {
            addCriterion("img_url8 between", value1, value2, "imgUrl8");
            return (Criteria) this;
        }

        public Criteria andImgUrl8NotBetween(String value1, String value2) {
            addCriterion("img_url8 not between", value1, value2, "imgUrl8");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}