package com.atguigu.crud.bean;

import javax.validation.constraints.Pattern;
/**
 * 用户
 * @author lhm
 *
 */
public class User {
    private Integer id;
    
    @Pattern(regexp="(^1\\d{10}$)"
    		,message="手机号必须是11位,而且以1开头")
    private String phone;
    
    @Pattern(regexp="(^[a-zA-Z0-9_-]{6,16}$)|(^[\\u2E80-\\u9FFF]{2,5})"
	,message="用户名必须是2-5位中文或者6-16位英文和数字的组合")
    private String username;

    private String password;

    private String qq;

    private String createAt;

    private Integer goodsNum;

    private Integer power;

    private String lastLogin;

    private Integer status;

    
    public User() {
		super();
	}

	public User(Integer id, String phone, String username, String password, String qq, String createAt,
			Integer goodsNum, Integer power, String lastLogin, Integer status) {
		super();
		this.id = id;
		this.phone = phone;
		this.username = username;
		this.password = password;
		this.qq = qq;
		this.createAt = createAt;
		this.goodsNum = goodsNum;
		this.power = power;
		this.lastLogin = lastLogin;
		this.status = status;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq == null ? null : qq.trim();
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt == null ? null : createAt.trim();
    }

    public Integer getGoodsNum() {
        return goodsNum;
    }

    public void setGoodsNum(Integer goodsNum) {
        this.goodsNum = goodsNum;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    public String getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(String lastLogin) {
        this.lastLogin = lastLogin == null ? null : lastLogin.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

	@Override
	public String toString() {
		return "User [id=" + id + ", phone=" + phone + ", username=" + username + ", password=" + password + ", qq="
				+ qq + ", createAt=" + createAt + ", goodsNum=" + goodsNum + ", power=" + power + ", lastLogin="
				+ lastLogin + ", status=" + status + "]";
	}
    
    
}