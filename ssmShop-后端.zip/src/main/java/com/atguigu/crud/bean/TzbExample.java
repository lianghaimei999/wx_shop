package com.atguigu.crud.bean;

import java.util.ArrayList;
import java.util.List;

public class TzbExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TzbExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andTitleIsNull() {
            addCriterion("title is null");
            return (Criteria) this;
        }

        public Criteria andTitleIsNotNull() {
            addCriterion("title is not null");
            return (Criteria) this;
        }

        public Criteria andTitleEqualTo(String value) {
            addCriterion("title =", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotEqualTo(String value) {
            addCriterion("title <>", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThan(String value) {
            addCriterion("title >", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleGreaterThanOrEqualTo(String value) {
            addCriterion("title >=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThan(String value) {
            addCriterion("title <", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLessThanOrEqualTo(String value) {
            addCriterion("title <=", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleLike(String value) {
            addCriterion("title like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotLike(String value) {
            addCriterion("title not like", value, "title");
            return (Criteria) this;
        }

        public Criteria andTitleIn(List<String> values) {
            addCriterion("title in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotIn(List<String> values) {
            addCriterion("title not in", values, "title");
            return (Criteria) this;
        }

        public Criteria andTitleBetween(String value1, String value2) {
            addCriterion("title between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andTitleNotBetween(String value1, String value2) {
            addCriterion("title not between", value1, value2, "title");
            return (Criteria) this;
        }

        public Criteria andContentIsNull() {
            addCriterion("content is null");
            return (Criteria) this;
        }

        public Criteria andContentIsNotNull() {
            addCriterion("content is not null");
            return (Criteria) this;
        }

        public Criteria andContentEqualTo(String value) {
            addCriterion("content =", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotEqualTo(String value) {
            addCriterion("content <>", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentGreaterThan(String value) {
            addCriterion("content >", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentGreaterThanOrEqualTo(String value) {
            addCriterion("content >=", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLessThan(String value) {
            addCriterion("content <", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLessThanOrEqualTo(String value) {
            addCriterion("content <=", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLike(String value) {
            addCriterion("content like", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotLike(String value) {
            addCriterion("content not like", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentIn(List<String> values) {
            addCriterion("content in", values, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotIn(List<String> values) {
            addCriterion("content not in", values, "content");
            return (Criteria) this;
        }

        public Criteria andContentBetween(String value1, String value2) {
            addCriterion("content between", value1, value2, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotBetween(String value1, String value2) {
            addCriterion("content not between", value1, value2, "content");
            return (Criteria) this;
        }

        public Criteria andImg1IsNull() {
            addCriterion("img1 is null");
            return (Criteria) this;
        }

        public Criteria andImg1IsNotNull() {
            addCriterion("img1 is not null");
            return (Criteria) this;
        }

        public Criteria andImg1EqualTo(String value) {
            addCriterion("img1 =", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1NotEqualTo(String value) {
            addCriterion("img1 <>", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1GreaterThan(String value) {
            addCriterion("img1 >", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1GreaterThanOrEqualTo(String value) {
            addCriterion("img1 >=", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1LessThan(String value) {
            addCriterion("img1 <", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1LessThanOrEqualTo(String value) {
            addCriterion("img1 <=", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1Like(String value) {
            addCriterion("img1 like", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1NotLike(String value) {
            addCriterion("img1 not like", value, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1In(List<String> values) {
            addCriterion("img1 in", values, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1NotIn(List<String> values) {
            addCriterion("img1 not in", values, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1Between(String value1, String value2) {
            addCriterion("img1 between", value1, value2, "img1");
            return (Criteria) this;
        }

        public Criteria andImg1NotBetween(String value1, String value2) {
            addCriterion("img1 not between", value1, value2, "img1");
            return (Criteria) this;
        }

        public Criteria andImg2IsNull() {
            addCriterion("img2 is null");
            return (Criteria) this;
        }

        public Criteria andImg2IsNotNull() {
            addCriterion("img2 is not null");
            return (Criteria) this;
        }

        public Criteria andImg2EqualTo(String value) {
            addCriterion("img2 =", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2NotEqualTo(String value) {
            addCriterion("img2 <>", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2GreaterThan(String value) {
            addCriterion("img2 >", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2GreaterThanOrEqualTo(String value) {
            addCriterion("img2 >=", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2LessThan(String value) {
            addCriterion("img2 <", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2LessThanOrEqualTo(String value) {
            addCriterion("img2 <=", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2Like(String value) {
            addCriterion("img2 like", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2NotLike(String value) {
            addCriterion("img2 not like", value, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2In(List<String> values) {
            addCriterion("img2 in", values, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2NotIn(List<String> values) {
            addCriterion("img2 not in", values, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2Between(String value1, String value2) {
            addCriterion("img2 between", value1, value2, "img2");
            return (Criteria) this;
        }

        public Criteria andImg2NotBetween(String value1, String value2) {
            addCriterion("img2 not between", value1, value2, "img2");
            return (Criteria) this;
        }

        public Criteria andImg3IsNull() {
            addCriterion("img3 is null");
            return (Criteria) this;
        }

        public Criteria andImg3IsNotNull() {
            addCriterion("img3 is not null");
            return (Criteria) this;
        }

        public Criteria andImg3EqualTo(String value) {
            addCriterion("img3 =", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3NotEqualTo(String value) {
            addCriterion("img3 <>", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3GreaterThan(String value) {
            addCriterion("img3 >", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3GreaterThanOrEqualTo(String value) {
            addCriterion("img3 >=", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3LessThan(String value) {
            addCriterion("img3 <", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3LessThanOrEqualTo(String value) {
            addCriterion("img3 <=", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3Like(String value) {
            addCriterion("img3 like", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3NotLike(String value) {
            addCriterion("img3 not like", value, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3In(List<String> values) {
            addCriterion("img3 in", values, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3NotIn(List<String> values) {
            addCriterion("img3 not in", values, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3Between(String value1, String value2) {
            addCriterion("img3 between", value1, value2, "img3");
            return (Criteria) this;
        }

        public Criteria andImg3NotBetween(String value1, String value2) {
            addCriterion("img3 not between", value1, value2, "img3");
            return (Criteria) this;
        }

        public Criteria andImg4IsNull() {
            addCriterion("img4 is null");
            return (Criteria) this;
        }

        public Criteria andImg4IsNotNull() {
            addCriterion("img4 is not null");
            return (Criteria) this;
        }

        public Criteria andImg4EqualTo(String value) {
            addCriterion("img4 =", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4NotEqualTo(String value) {
            addCriterion("img4 <>", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4GreaterThan(String value) {
            addCriterion("img4 >", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4GreaterThanOrEqualTo(String value) {
            addCriterion("img4 >=", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4LessThan(String value) {
            addCriterion("img4 <", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4LessThanOrEqualTo(String value) {
            addCriterion("img4 <=", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4Like(String value) {
            addCriterion("img4 like", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4NotLike(String value) {
            addCriterion("img4 not like", value, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4In(List<String> values) {
            addCriterion("img4 in", values, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4NotIn(List<String> values) {
            addCriterion("img4 not in", values, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4Between(String value1, String value2) {
            addCriterion("img4 between", value1, value2, "img4");
            return (Criteria) this;
        }

        public Criteria andImg4NotBetween(String value1, String value2) {
            addCriterion("img4 not between", value1, value2, "img4");
            return (Criteria) this;
        }

        public Criteria andImg5IsNull() {
            addCriterion("img5 is null");
            return (Criteria) this;
        }

        public Criteria andImg5IsNotNull() {
            addCriterion("img5 is not null");
            return (Criteria) this;
        }

        public Criteria andImg5EqualTo(String value) {
            addCriterion("img5 =", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5NotEqualTo(String value) {
            addCriterion("img5 <>", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5GreaterThan(String value) {
            addCriterion("img5 >", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5GreaterThanOrEqualTo(String value) {
            addCriterion("img5 >=", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5LessThan(String value) {
            addCriterion("img5 <", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5LessThanOrEqualTo(String value) {
            addCriterion("img5 <=", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5Like(String value) {
            addCriterion("img5 like", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5NotLike(String value) {
            addCriterion("img5 not like", value, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5In(List<String> values) {
            addCriterion("img5 in", values, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5NotIn(List<String> values) {
            addCriterion("img5 not in", values, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5Between(String value1, String value2) {
            addCriterion("img5 between", value1, value2, "img5");
            return (Criteria) this;
        }

        public Criteria andImg5NotBetween(String value1, String value2) {
            addCriterion("img5 not between", value1, value2, "img5");
            return (Criteria) this;
        }

        public Criteria andImg6IsNull() {
            addCriterion("img6 is null");
            return (Criteria) this;
        }

        public Criteria andImg6IsNotNull() {
            addCriterion("img6 is not null");
            return (Criteria) this;
        }

        public Criteria andImg6EqualTo(String value) {
            addCriterion("img6 =", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6NotEqualTo(String value) {
            addCriterion("img6 <>", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6GreaterThan(String value) {
            addCriterion("img6 >", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6GreaterThanOrEqualTo(String value) {
            addCriterion("img6 >=", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6LessThan(String value) {
            addCriterion("img6 <", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6LessThanOrEqualTo(String value) {
            addCriterion("img6 <=", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6Like(String value) {
            addCriterion("img6 like", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6NotLike(String value) {
            addCriterion("img6 not like", value, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6In(List<String> values) {
            addCriterion("img6 in", values, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6NotIn(List<String> values) {
            addCriterion("img6 not in", values, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6Between(String value1, String value2) {
            addCriterion("img6 between", value1, value2, "img6");
            return (Criteria) this;
        }

        public Criteria andImg6NotBetween(String value1, String value2) {
            addCriterion("img6 not between", value1, value2, "img6");
            return (Criteria) this;
        }

        public Criteria andImg7IsNull() {
            addCriterion("img7 is null");
            return (Criteria) this;
        }

        public Criteria andImg7IsNotNull() {
            addCriterion("img7 is not null");
            return (Criteria) this;
        }

        public Criteria andImg7EqualTo(String value) {
            addCriterion("img7 =", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7NotEqualTo(String value) {
            addCriterion("img7 <>", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7GreaterThan(String value) {
            addCriterion("img7 >", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7GreaterThanOrEqualTo(String value) {
            addCriterion("img7 >=", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7LessThan(String value) {
            addCriterion("img7 <", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7LessThanOrEqualTo(String value) {
            addCriterion("img7 <=", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7Like(String value) {
            addCriterion("img7 like", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7NotLike(String value) {
            addCriterion("img7 not like", value, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7In(List<String> values) {
            addCriterion("img7 in", values, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7NotIn(List<String> values) {
            addCriterion("img7 not in", values, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7Between(String value1, String value2) {
            addCriterion("img7 between", value1, value2, "img7");
            return (Criteria) this;
        }

        public Criteria andImg7NotBetween(String value1, String value2) {
            addCriterion("img7 not between", value1, value2, "img7");
            return (Criteria) this;
        }

        public Criteria andImg8IsNull() {
            addCriterion("img8 is null");
            return (Criteria) this;
        }

        public Criteria andImg8IsNotNull() {
            addCriterion("img8 is not null");
            return (Criteria) this;
        }

        public Criteria andImg8EqualTo(String value) {
            addCriterion("img8 =", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8NotEqualTo(String value) {
            addCriterion("img8 <>", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8GreaterThan(String value) {
            addCriterion("img8 >", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8GreaterThanOrEqualTo(String value) {
            addCriterion("img8 >=", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8LessThan(String value) {
            addCriterion("img8 <", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8LessThanOrEqualTo(String value) {
            addCriterion("img8 <=", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8Like(String value) {
            addCriterion("img8 like", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8NotLike(String value) {
            addCriterion("img8 not like", value, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8In(List<String> values) {
            addCriterion("img8 in", values, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8NotIn(List<String> values) {
            addCriterion("img8 not in", values, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8Between(String value1, String value2) {
            addCriterion("img8 between", value1, value2, "img8");
            return (Criteria) this;
        }

        public Criteria andImg8NotBetween(String value1, String value2) {
            addCriterion("img8 not between", value1, value2, "img8");
            return (Criteria) this;
        }

        public Criteria andImg9IsNull() {
            addCriterion("img9 is null");
            return (Criteria) this;
        }

        public Criteria andImg9IsNotNull() {
            addCriterion("img9 is not null");
            return (Criteria) this;
        }

        public Criteria andImg9EqualTo(String value) {
            addCriterion("img9 =", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9NotEqualTo(String value) {
            addCriterion("img9 <>", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9GreaterThan(String value) {
            addCriterion("img9 >", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9GreaterThanOrEqualTo(String value) {
            addCriterion("img9 >=", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9LessThan(String value) {
            addCriterion("img9 <", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9LessThanOrEqualTo(String value) {
            addCriterion("img9 <=", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9Like(String value) {
            addCriterion("img9 like", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9NotLike(String value) {
            addCriterion("img9 not like", value, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9In(List<String> values) {
            addCriterion("img9 in", values, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9NotIn(List<String> values) {
            addCriterion("img9 not in", values, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9Between(String value1, String value2) {
            addCriterion("img9 between", value1, value2, "img9");
            return (Criteria) this;
        }

        public Criteria andImg9NotBetween(String value1, String value2) {
            addCriterion("img9 not between", value1, value2, "img9");
            return (Criteria) this;
        }

        public Criteria andIsEffectIsNull() {
            addCriterion("is_effect is null");
            return (Criteria) this;
        }

        public Criteria andIsEffectIsNotNull() {
            addCriterion("is_effect is not null");
            return (Criteria) this;
        }

        public Criteria andIsEffectEqualTo(Integer value) {
            addCriterion("is_effect =", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectNotEqualTo(Integer value) {
            addCriterion("is_effect <>", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectGreaterThan(Integer value) {
            addCriterion("is_effect >", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_effect >=", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectLessThan(Integer value) {
            addCriterion("is_effect <", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectLessThanOrEqualTo(Integer value) {
            addCriterion("is_effect <=", value, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectIn(List<Integer> values) {
            addCriterion("is_effect in", values, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectNotIn(List<Integer> values) {
            addCriterion("is_effect not in", values, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectBetween(Integer value1, Integer value2) {
            addCriterion("is_effect between", value1, value2, "isEffect");
            return (Criteria) this;
        }

        public Criteria andIsEffectNotBetween(Integer value1, Integer value2) {
            addCriterion("is_effect not between", value1, value2, "isEffect");
            return (Criteria) this;
        }

        public Criteria andTTimeIsNull() {
            addCriterion("t_time is null");
            return (Criteria) this;
        }

        public Criteria andTTimeIsNotNull() {
            addCriterion("t_time is not null");
            return (Criteria) this;
        }

        public Criteria andTTimeEqualTo(String value) {
            addCriterion("t_time =", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeNotEqualTo(String value) {
            addCriterion("t_time <>", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeGreaterThan(String value) {
            addCriterion("t_time >", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeGreaterThanOrEqualTo(String value) {
            addCriterion("t_time >=", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeLessThan(String value) {
            addCriterion("t_time <", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeLessThanOrEqualTo(String value) {
            addCriterion("t_time <=", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeLike(String value) {
            addCriterion("t_time like", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeNotLike(String value) {
            addCriterion("t_time not like", value, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeIn(List<String> values) {
            addCriterion("t_time in", values, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeNotIn(List<String> values) {
            addCriterion("t_time not in", values, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeBetween(String value1, String value2) {
            addCriterion("t_time between", value1, value2, "tTime");
            return (Criteria) this;
        }

        public Criteria andTTimeNotBetween(String value1, String value2) {
            addCriterion("t_time not between", value1, value2, "tTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}