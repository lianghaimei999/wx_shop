package com.atguigu.crud.bean;

import java.io.Serializable;
/**
 * 管理员
 * @author lhm
 *
 */
public class Admin implements Serializable{
    private Integer id;

    private String username;

    private Integer phone;

    private String password;

    private String userrole;

	public Admin() {
		super();
	}

	public Admin(Integer id, String username, Integer phone, String password, String userrole) {
		super();
		this.id = id;
		this.username = username;
		this.phone = phone;
		this.password = password;
		this.userrole = userrole;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getPhone() {
		return phone;
	}

	public void setPhone(Integer phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserrole() {
		return userrole;
	}

	public void setUserrole(String userrole) {
		this.userrole = userrole;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", username=" + username + ", phone=" + phone + ", password=" + password
				+ ", userrole=" + userrole + "]";
	}

   
}