package com.atguigu.crud.bean;

import java.util.ArrayList;
import java.util.List;

public class ChatExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ChatExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdFsfIsNull() {
            addCriterion("id_fsf is null");
            return (Criteria) this;
        }

        public Criteria andIdFsfIsNotNull() {
            addCriterion("id_fsf is not null");
            return (Criteria) this;
        }

        public Criteria andIdFsfEqualTo(Integer value) {
            addCriterion("id_fsf =", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfNotEqualTo(Integer value) {
            addCriterion("id_fsf <>", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfGreaterThan(Integer value) {
            addCriterion("id_fsf >", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfGreaterThanOrEqualTo(Integer value) {
            addCriterion("id_fsf >=", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfLessThan(Integer value) {
            addCriterion("id_fsf <", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfLessThanOrEqualTo(Integer value) {
            addCriterion("id_fsf <=", value, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfIn(List<Integer> values) {
            addCriterion("id_fsf in", values, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfNotIn(List<Integer> values) {
            addCriterion("id_fsf not in", values, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfBetween(Integer value1, Integer value2) {
            addCriterion("id_fsf between", value1, value2, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdFsfNotBetween(Integer value1, Integer value2) {
            addCriterion("id_fsf not between", value1, value2, "idFsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfIsNull() {
            addCriterion("id_jsf is null");
            return (Criteria) this;
        }

        public Criteria andIdJsfIsNotNull() {
            addCriterion("id_jsf is not null");
            return (Criteria) this;
        }

        public Criteria andIdJsfEqualTo(Integer value) {
            addCriterion("id_jsf =", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfNotEqualTo(Integer value) {
            addCriterion("id_jsf <>", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfGreaterThan(Integer value) {
            addCriterion("id_jsf >", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfGreaterThanOrEqualTo(Integer value) {
            addCriterion("id_jsf >=", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfLessThan(Integer value) {
            addCriterion("id_jsf <", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfLessThanOrEqualTo(Integer value) {
            addCriterion("id_jsf <=", value, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfIn(List<Integer> values) {
            addCriterion("id_jsf in", values, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfNotIn(List<Integer> values) {
            addCriterion("id_jsf not in", values, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfBetween(Integer value1, Integer value2) {
            addCriterion("id_jsf between", value1, value2, "idJsf");
            return (Criteria) this;
        }

        public Criteria andIdJsfNotBetween(Integer value1, Integer value2) {
            addCriterion("id_jsf not between", value1, value2, "idJsf");
            return (Criteria) this;
        }

        public Criteria andContentIsNull() {
            addCriterion("content is null");
            return (Criteria) this;
        }

        public Criteria andContentIsNotNull() {
            addCriterion("content is not null");
            return (Criteria) this;
        }

        public Criteria andContentEqualTo(String value) {
            addCriterion("content =", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotEqualTo(String value) {
            addCriterion("content <>", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentGreaterThan(String value) {
            addCriterion("content >", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentGreaterThanOrEqualTo(String value) {
            addCriterion("content >=", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLessThan(String value) {
            addCriterion("content <", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLessThanOrEqualTo(String value) {
            addCriterion("content <=", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentLike(String value) {
            addCriterion("content like", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotLike(String value) {
            addCriterion("content not like", value, "content");
            return (Criteria) this;
        }

        public Criteria andContentIn(List<String> values) {
            addCriterion("content in", values, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotIn(List<String> values) {
            addCriterion("content not in", values, "content");
            return (Criteria) this;
        }

        public Criteria andContentBetween(String value1, String value2) {
            addCriterion("content between", value1, value2, "content");
            return (Criteria) this;
        }

        public Criteria andContentNotBetween(String value1, String value2) {
            addCriterion("content not between", value1, value2, "content");
            return (Criteria) this;
        }

        public Criteria andImageIsNull() {
            addCriterion("image is null");
            return (Criteria) this;
        }

        public Criteria andImageIsNotNull() {
            addCriterion("image is not null");
            return (Criteria) this;
        }

        public Criteria andImageEqualTo(String value) {
            addCriterion("image =", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageNotEqualTo(String value) {
            addCriterion("image <>", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageGreaterThan(String value) {
            addCriterion("image >", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageGreaterThanOrEqualTo(String value) {
            addCriterion("image >=", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageLessThan(String value) {
            addCriterion("image <", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageLessThanOrEqualTo(String value) {
            addCriterion("image <=", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageLike(String value) {
            addCriterion("image like", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageNotLike(String value) {
            addCriterion("image not like", value, "image");
            return (Criteria) this;
        }

        public Criteria andImageIn(List<String> values) {
            addCriterion("image in", values, "image");
            return (Criteria) this;
        }

        public Criteria andImageNotIn(List<String> values) {
            addCriterion("image not in", values, "image");
            return (Criteria) this;
        }

        public Criteria andImageBetween(String value1, String value2) {
            addCriterion("image between", value1, value2, "image");
            return (Criteria) this;
        }

        public Criteria andImageNotBetween(String value1, String value2) {
            addCriterion("image not between", value1, value2, "image");
            return (Criteria) this;
        }

        public Criteria andLTimeIsNull() {
            addCriterion("l_time is null");
            return (Criteria) this;
        }

        public Criteria andLTimeIsNotNull() {
            addCriterion("l_time is not null");
            return (Criteria) this;
        }

        public Criteria andLTimeEqualTo(String value) {
            addCriterion("l_time =", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeNotEqualTo(String value) {
            addCriterion("l_time <>", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeGreaterThan(String value) {
            addCriterion("l_time >", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeGreaterThanOrEqualTo(String value) {
            addCriterion("l_time >=", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeLessThan(String value) {
            addCriterion("l_time <", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeLessThanOrEqualTo(String value) {
            addCriterion("l_time <=", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeLike(String value) {
            addCriterion("l_time like", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeNotLike(String value) {
            addCriterion("l_time not like", value, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeIn(List<String> values) {
            addCriterion("l_time in", values, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeNotIn(List<String> values) {
            addCriterion("l_time not in", values, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeBetween(String value1, String value2) {
            addCriterion("l_time between", value1, value2, "lTime");
            return (Criteria) this;
        }

        public Criteria andLTimeNotBetween(String value1, String value2) {
            addCriterion("l_time not between", value1, value2, "lTime");
            return (Criteria) this;
        }

        public Criteria andIsLookIsNull() {
            addCriterion("is_look is null");
            return (Criteria) this;
        }

        public Criteria andIsLookIsNotNull() {
            addCriterion("is_look is not null");
            return (Criteria) this;
        }

        public Criteria andIsLookEqualTo(String value) {
            addCriterion("is_look =", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookNotEqualTo(String value) {
            addCriterion("is_look <>", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookGreaterThan(String value) {
            addCriterion("is_look >", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookGreaterThanOrEqualTo(String value) {
            addCriterion("is_look >=", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookLessThan(String value) {
            addCriterion("is_look <", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookLessThanOrEqualTo(String value) {
            addCriterion("is_look <=", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookLike(String value) {
            addCriterion("is_look like", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookNotLike(String value) {
            addCriterion("is_look not like", value, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookIn(List<String> values) {
            addCriterion("is_look in", values, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookNotIn(List<String> values) {
            addCriterion("is_look not in", values, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookBetween(String value1, String value2) {
            addCriterion("is_look between", value1, value2, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsLookNotBetween(String value1, String value2) {
            addCriterion("is_look not between", value1, value2, "isLook");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaIsNull() {
            addCriterion("is_remove_fa is null");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaIsNotNull() {
            addCriterion("is_remove_fa is not null");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaEqualTo(String value) {
            addCriterion("is_remove_fa =", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaNotEqualTo(String value) {
            addCriterion("is_remove_fa <>", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaGreaterThan(String value) {
            addCriterion("is_remove_fa >", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaGreaterThanOrEqualTo(String value) {
            addCriterion("is_remove_fa >=", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaLessThan(String value) {
            addCriterion("is_remove_fa <", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaLessThanOrEqualTo(String value) {
            addCriterion("is_remove_fa <=", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaLike(String value) {
            addCriterion("is_remove_fa like", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaNotLike(String value) {
            addCriterion("is_remove_fa not like", value, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaIn(List<String> values) {
            addCriterion("is_remove_fa in", values, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaNotIn(List<String> values) {
            addCriterion("is_remove_fa not in", values, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaBetween(String value1, String value2) {
            addCriterion("is_remove_fa between", value1, value2, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveFaNotBetween(String value1, String value2) {
            addCriterion("is_remove_fa not between", value1, value2, "isRemoveFa");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieIsNull() {
            addCriterion("is_remove_jie is null");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieIsNotNull() {
            addCriterion("is_remove_jie is not null");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieEqualTo(String value) {
            addCriterion("is_remove_jie =", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieNotEqualTo(String value) {
            addCriterion("is_remove_jie <>", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieGreaterThan(String value) {
            addCriterion("is_remove_jie >", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieGreaterThanOrEqualTo(String value) {
            addCriterion("is_remove_jie >=", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieLessThan(String value) {
            addCriterion("is_remove_jie <", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieLessThanOrEqualTo(String value) {
            addCriterion("is_remove_jie <=", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieLike(String value) {
            addCriterion("is_remove_jie like", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieNotLike(String value) {
            addCriterion("is_remove_jie not like", value, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieIn(List<String> values) {
            addCriterion("is_remove_jie in", values, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieNotIn(List<String> values) {
            addCriterion("is_remove_jie not in", values, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieBetween(String value1, String value2) {
            addCriterion("is_remove_jie between", value1, value2, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andIsRemoveJieNotBetween(String value1, String value2) {
            addCriterion("is_remove_jie not between", value1, value2, "isRemoveJie");
            return (Criteria) this;
        }

        public Criteria andChatSignalIsNull() {
            addCriterion("chat_signal is null");
            return (Criteria) this;
        }

        public Criteria andChatSignalIsNotNull() {
            addCriterion("chat_signal is not null");
            return (Criteria) this;
        }

        public Criteria andChatSignalEqualTo(String value) {
            addCriterion("chat_signal =", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalNotEqualTo(String value) {
            addCriterion("chat_signal <>", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalGreaterThan(String value) {
            addCriterion("chat_signal >", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalGreaterThanOrEqualTo(String value) {
            addCriterion("chat_signal >=", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalLessThan(String value) {
            addCriterion("chat_signal <", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalLessThanOrEqualTo(String value) {
            addCriterion("chat_signal <=", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalLike(String value) {
            addCriterion("chat_signal like", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalNotLike(String value) {
            addCriterion("chat_signal not like", value, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalIn(List<String> values) {
            addCriterion("chat_signal in", values, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalNotIn(List<String> values) {
            addCriterion("chat_signal not in", values, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalBetween(String value1, String value2) {
            addCriterion("chat_signal between", value1, value2, "chatSignal");
            return (Criteria) this;
        }

        public Criteria andChatSignalNotBetween(String value1, String value2) {
            addCriterion("chat_signal not between", value1, value2, "chatSignal");
            return (Criteria) this;
        }
        
        public Criteria andGoodIdIsNull() {
            addCriterion("good_id is null");
            return (Criteria) this;
        }

        public Criteria andGoodIdIsNotNull() {
            addCriterion("good_id is not null");
            return (Criteria) this;
        }

        public Criteria andGoodIdEqualTo(Integer value) {
            addCriterion("good_id =", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdNotEqualTo(Integer value) {
            addCriterion("good_id <>", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdGreaterThan(Integer value) {
            addCriterion("good_id >", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("good_id >=", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdLessThan(Integer value) {
            addCriterion("good_id <", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdLessThanOrEqualTo(Integer value) {
            addCriterion("good_id <=", value, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdIn(List<Integer> values) {
            addCriterion("good_id in", values, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdNotIn(List<Integer> values) {
            addCriterion("good_id not in", values, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdBetween(Integer value1, Integer value2) {
            addCriterion("good_id between", value1, value2, "good_id");
            return (Criteria) this;
        }

        public Criteria andGoodIdNotBetween(Integer value1, Integer value2) {
            addCriterion("good_id not between", value1, value2, "good_id");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}