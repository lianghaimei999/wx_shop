package com.atguigu.crud.bean;

public class Orders {
    private Integer id;

    private Integer userId;

    private Integer goodsId;

    private String orderNum;

    private Float orderPrice;

    private Integer orderState;

    private String orderInformation;

    private String orderDate;

    private String orderAddress;

    private User user;
    
    private Goods goods;

	public Orders() {
		super();
	}

	public Orders(Integer id, Integer userId, Integer goodsId, String orderNum, Float orderPrice, Integer orderState,
			String orderInformation, String orderDate, String orderAddress, User user, Goods goods) {
		super();
		this.id = id;
		this.userId = userId;
		this.goodsId = goodsId;
		this.orderNum = orderNum;
		this.orderPrice = orderPrice;
		this.orderState = orderState;
		this.orderInformation = orderInformation;
		this.orderDate = orderDate;
		this.orderAddress = orderAddress;
		this.user = user;
		this.goods = goods;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(Integer goodsId) {
		this.goodsId = goodsId;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public Float getOrderPrice() {
		return orderPrice;
	}

	public void setOrderPrice(Float orderPrice) {
		this.orderPrice = orderPrice;
	}

	public Integer getOrderState() {
		return orderState;
	}

	public void setOrderState(Integer orderState) {
		this.orderState = orderState;
	}

	public String getOrderInformation() {
		return orderInformation;
	}

	public void setOrderInformation(String orderInformation) {
		this.orderInformation = orderInformation;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderAddress() {
		return orderAddress;
	}

	public void setOrderAddress(String orderAddress) {
		this.orderAddress = orderAddress;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Goods getGoods() {
		return goods;
	}

	public void setGoods(Goods goods) {
		this.goods = goods;
	}

	@Override
	public String toString() {
		return "Orders [id=" + id + ", userId=" + userId + ", goodsId=" + goodsId + ", orderNum=" + orderNum
				+ ", orderPrice=" + orderPrice + ", orderState=" + orderState + ", orderInformation=" + orderInformation
				+ ", orderDate=" + orderDate + ", orderAddress=" + orderAddress + ", user=" + user + ", goods=" + goods
				+ "]";
	}
    
    
}