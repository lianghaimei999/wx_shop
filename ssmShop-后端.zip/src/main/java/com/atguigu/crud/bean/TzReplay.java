package com.atguigu.crud.bean;

public class TzReplay {
    private Integer id;

    private Integer tzId;

    private Integer userId;

    private String rContent;

    private Integer isLike;

    private String rImage;

    private String rTime;

    private Integer status;

    private User user;
    
    private Tzb tzb;

	public TzReplay(Integer id, Integer tzId, Integer userId, String rContent, Integer isLike, String rImage,
			String rTime, Integer status, User user, Tzb tzb) {
		super();
		this.id = id;
		this.tzId = tzId;
		this.userId = userId;
		this.rContent = rContent;
		this.isLike = isLike;
		this.rImage = rImage;
		this.rTime = rTime;
		this.status = status;
		this.user = user;
		this.tzb = tzb;
	}

	public TzReplay() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTzId() {
		return tzId;
	}

	public void setTzId(Integer tzId) {
		this.tzId = tzId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getrContent() {
		return rContent;
	}

	public void setrContent(String rContent) {
		this.rContent = rContent;
	}

	public Integer getIsLike() {
		return isLike;
	}

	public void setIsLike(Integer isLike) {
		this.isLike = isLike;
	}

	public String getrImage() {
		return rImage;
	}

	public void setrImage(String rImage) {
		this.rImage = rImage;
	}

	public String getrTime() {
		return rTime;
	}

	public void setrTime(String rTime) {
		this.rTime = rTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Tzb getTzb() {
		return tzb;
	}

	public void setTzb(Tzb tzb) {
		this.tzb = tzb;
	}

	@Override
	public String toString() {
		return "TzReplay [id=" + id + ", tzId=" + tzId + ", userId=" + userId + ", rContent=" + rContent + ", isLike="
				+ isLike + ", rImage=" + rImage + ", rTime=" + rTime + ", status=" + status + ", user=" + user
				+ ", tzb=" + tzb + "]";
	}
    
    
}