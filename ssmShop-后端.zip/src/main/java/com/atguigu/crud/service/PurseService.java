package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Purse;
import com.atguigu.crud.bean.PurseExample;
import com.atguigu.crud.dao.PurseMapper;
import com.atguigu.crud.bean.PurseExample.Criteria;




@Service
public class PurseService {
	
	@Autowired
	PurseMapper purseMaper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Purse> getAll() {
		// TODO Auto-generated method stub
		return purseMaper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param employee
	 */
	public void saveEmp(Purse employee) {
		// TODO Auto-generated method stub
		purseMaper.insertSelective(employee);
	}

	
	/**
	 * 按照员工id查询员工
	 * @param id
	 * @return
	 */
	public Purse getEmp(Integer id) {
		// TODO Auto-generated method stub
		Purse employee = purseMaper.selectByPrimaryKey(id);
		return employee;
	}

	/**
	 * 员工更新
	 * @param employee
	 */
	public void updateEmp(Purse employee) {
		// TODO Auto-generated method stub
		purseMaper.updateByPrimaryKeySelective(employee);
	}

	/**
	 * 员工删除
	 * @param id
	 */
	public void deleteEmp(Integer id) {
		// TODO Auto-generated method stub
		purseMaper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		// TODO Auto-generated method stub
		PurseExample example = new PurseExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		purseMaper.deleteByExample(example);
	}

}
