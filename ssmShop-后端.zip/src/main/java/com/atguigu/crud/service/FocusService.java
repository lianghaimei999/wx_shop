package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Focus;
import com.atguigu.crud.bean.FocusExample;
import com.atguigu.crud.bean.Orders;
import com.atguigu.crud.bean.FocusExample.Criteria;
import com.atguigu.crud.dao.FocusMapper;

@Service
public class FocusService {
	
	@Autowired
	FocusMapper focusMapper;
	
	/**
	 * 查询所有
	 * @return
	 */
	public List<Focus> getAll() {
		// TODO Auto-generated method stub
		return focusMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Focus focus) {
		// TODO Auto-generated method stub
		focusMapper.insertSelective(focus);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Focus get(Integer id) {
		Focus focus = focusMapper.selectByPrimaryKey(id);
		return focus;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Focus focus) {
		focusMapper.updateByPrimaryKeySelective(focus);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		focusMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		FocusExample example = new FocusExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		focusMapper.deleteByExample(example);
	}

}
