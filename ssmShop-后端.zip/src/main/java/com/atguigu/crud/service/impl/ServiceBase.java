package com.atguigu.crud.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface ServiceBase<E> {
	/**
	 * 增加一条记录
	 * @param obj
	 * @return 
	 */
	void save(E obj);
	
	/**
	 * 删除一条记录
	 * @param id 记录id（主键或唯一键）
	 * @return 
	 */
	void deleteById(Serializable id);
	
	/**
	 * 删除多条记录
	 * @param id 记录id（主键或唯一键）
	 * @return 
	 */
	void deleteBatch(Serializable id);
	
	/**
	 * 更新一条记录
	 * @param obj 待更新记录（对象）
	 * @return 
	 */
	void update(E obj);
	
	/**
	 * 通过唯一列（主键/唯一键）获取一条记录
	 * @param id 主键/唯一键
	 * @return 
	 */
	E selectByPrimaryKey(Serializable id);
	
	/**
	 * 通过对象参数获取一条记录
	 * @param obj 封装有参数的对象
	 * @return 
	 */
	E selectByObj(E obj);
	
	/**
	 * 获取表里面的所有记录
	 * @return 所有记录
	 */
	List<E> getAll();
	
	/**
	 * 通过对象参数获取记录
	 * @param obj 封装有参数的对象
	 * @return 
	 */
	List<E> listByObj(E obj);
	
	/**
	 * 检验obj是否可用
	 * @param obj
	 * @return true：代表当前可用   fasle：不可用
	 */
	boolean check(String obj);
	
	boolean isExisted(Serializable id);
	
}
