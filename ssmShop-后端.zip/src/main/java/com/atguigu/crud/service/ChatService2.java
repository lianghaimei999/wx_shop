package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Chat;
import com.atguigu.crud.bean.ChatExample;
import com.atguigu.crud.dao.ChatMapper;
import com.atguigu.crud.utils.DateUtil;

@Service
public class ChatService2 {

	@Autowired
	ChatMapper chatMapper;
	
	/**
	 * 查询所有
	 * @return
	 */
	public List<Chat> getAll() {
		return chatMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param employee
	 */
	public void save(Chat employee) {
		chatMapper.insertSelective(employee);
	}

	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Chat get(Integer id) {
		Chat employee = chatMapper.selectByPrimaryKey(id);
		return employee;
	}

	/**
	 * 更新
	 * @param employee
	 */
	public void update(Chat employee) {
		chatMapper.updateByPrimaryKeySelective(employee);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		chatMapper.deleteByPrimaryKey(id);
	}
	
}
