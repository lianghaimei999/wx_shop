package com.atguigu.crud.service.impl;

import java.io.Serializable;
import java.util.List;

public class ServiceBaseAdapter<E> implements ServiceBase<E> {

	@Override
	public void save(E obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(Serializable id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBatch(Serializable id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(E obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public E selectByPrimaryKey(Serializable id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public E selectByObj(E obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<E> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<E> listByObj(E obj) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean check(String obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isExisted(Serializable id) {
		// TODO Auto-generated method stub
		return false;
	}

}
