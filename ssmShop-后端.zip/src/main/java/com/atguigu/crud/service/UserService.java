package com.atguigu.crud.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.bean.UserExample;
import com.atguigu.crud.bean.UserExample.Criteria;
import com.atguigu.crud.dao.UserMapper;
import com.atguigu.crud.utils.DateUtil;



@Service
public class UserService {
	
	@Autowired
	UserMapper userMapper;

	/**
	 * 查询所有员工
	 * @return
	 */
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return userMapper.selectByExample(null);
	}
	public List<User> listByObj(User user) {
		List<User> list = userMapper.listByObj(user);
		return list;
	}

	/**
	 * 保存
	 * @param employee
	 */
	public void saveEmp(User employee) {
		String createAt = DateUtil.getNow();
		employee.setCreateAt(createAt);
		userMapper.insertSelective(employee);
	}

	/**
	 * 检验用户名是否可用
	 * 
	 * @param empName
	 * @return  true：代表当前姓名可用   fasle：不可用
	 */
	public boolean checkUser(String empName) {
		// TODO Auto-generated method stub
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(empName);//名字等于给定值example
		long count = userMapper.countByExample(example);//返回记录数。
		return count == 0;
	}
	
	public boolean checkphone(String phone) {
		// TODO Auto-generated method stub
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andPhoneEqualTo(phone);//名字等于给定值example
		long count = userMapper.countByExample(example);//返回记录数。
		return count == 0;
	}

	/**
	 * 按照员工id查询员工
	 * @param id
	 * @return
	 */
	public User getEmp(Integer id) {
		// TODO Auto-generated method stub
		User employee = userMapper.selectByPrimaryKey(id);
		return employee;
	}

	/**
	 * 员工更新
	 * @param employee
	 */
	public void updateEmp(User employee) {
		// TODO Auto-generated method stub
		userMapper.updateByPrimaryKeySelective(employee);
	}

	/**
	 * 员工删除
	 * @param id
	 */
	public void deleteEmp(Integer id) {
		// TODO Auto-generated method stub
		userMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		// TODO Auto-generated method stub
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		userMapper.deleteByExample(example);
	}

	public User getUserByAccountAndPassword(String phone, String password) {
		//System.out.println(phone);
		//System.out.println(password);
		
		return userMapper.getPhonePwd(phone,password);
	}
	
	public User getPhone(String phone) {
		System.out.println(phone);
		return userMapper.getPhone(phone);
	}
	
	public List<User> selectquery(String goodName){
		return userMapper.selectquery(goodName);
	}

}
