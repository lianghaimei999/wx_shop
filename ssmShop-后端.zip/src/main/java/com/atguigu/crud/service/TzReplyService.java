package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Reply;
import com.atguigu.crud.bean.ReplyExample;
import com.atguigu.crud.bean.TzReplay;
import com.atguigu.crud.bean.TzReplayExample;
import com.atguigu.crud.bean.TzReplayExample.Criteria;
import com.atguigu.crud.dao.ReplyMapper;
import com.atguigu.crud.dao.TzReplayMapper;
import com.atguigu.crud.utils.DateUtil;


@Service
public class TzReplyService {
	
	@Autowired
	TzReplayMapper tzreplyMapper;
	
	public void delete(Integer id) {
		tzreplyMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		TzReplayExample example = new TzReplayExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		tzreplyMapper.deleteByExample(example);
	}

	/**
	 * 查询所有
	 * @return
	 */
	public List<TzReplay> getAll() {
		// TODO Auto-generated method stub
		return tzreplyMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(TzReplay orders) {
		// TODO Auto-generated method stub
		String createAt = DateUtil.getNow();
		orders.setrTime(createAt);
		tzreplyMapper.insertSelective(orders);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public TzReplay get(Integer id) {
		 TzReplay orders = tzreplyMapper.selectByPrimaryKey(id);
		return orders;
	}




}
