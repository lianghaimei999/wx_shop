package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Tzb;
import com.atguigu.crud.bean.TzbExample;
import com.atguigu.crud.bean.CommentsExample;
import com.atguigu.crud.bean.CommentsExample.Criteria;
import com.atguigu.crud.dao.CommentsMapper;
import com.atguigu.crud.dao.TzbMapper;
import com.atguigu.crud.utils.DateUtil;


@Service
public class TzbService {
	
	@Autowired
	TzbMapper tzbMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Tzb> getAll() {
		// TODO Auto-generated method stub
		return tzbMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Tzb com) {
		String createAt = DateUtil.getNow();
		com.settTime(createAt);
		tzbMapper.insertSelective(com);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Tzb get(Integer id) {
		Tzb orders = tzbMapper.selectByPrimaryKey(id);
		return orders;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Tzb orders) {
		tzbMapper.updateByPrimaryKeySelective(orders);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		tzbMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		TzbExample example = new TzbExample();
		com.atguigu.crud.bean.TzbExample.Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		tzbMapper.deleteByExample(example);
	}

}
