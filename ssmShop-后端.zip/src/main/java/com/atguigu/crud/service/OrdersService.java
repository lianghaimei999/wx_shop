package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Orders;
import com.atguigu.crud.bean.OrdersExample;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.bean.OrdersExample.Criteria;
import com.atguigu.crud.dao.OrdersMapper;
import com.atguigu.crud.utils.DateUtil;
import com.atguigu.crud.utils.UUIDUtil;

@Service
public class OrdersService {
	
	@Autowired
	OrdersMapper ordersMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Orders> getAll() {
		// TODO Auto-generated method stub
		return ordersMapper.selectByExampleWithXX(null);
	}
	
	public List<Orders> listByObjOrder(Orders user) {
		List<Orders> list = ordersMapper.listByObjOrder(user);
		return list;
	}

	/**
	 * 保存
	 * @param orders
	 * @return 
	 */
	public void save(Orders orders) {
		Integer userId=orders.getUserId();
		Float orderPrice=orders.getOrderPrice();
		String orderNum="DH"+DateUtil.getNow2();;
		String createAt = DateUtil.getNow();
		orders.setOrderNum(orderNum);
		orders.setOrderDate(createAt);
		
		ordersMapper.insertSelective(orders);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Orders get(Integer id) {
		Orders orders = ordersMapper.selectByPrimaryKey(id);
		return orders;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Orders orders) {
		orders.setOrderState(2);
		ordersMapper.updateByPrimaryKeySelective(orders);
	}
	
	public void update2(Orders orders) {
		orders.setOrderState(3);
		ordersMapper.updateByPrimaryKeySelective(orders);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		ordersMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		OrdersExample example = new OrdersExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		ordersMapper.deleteByExample(example);
	}

}
