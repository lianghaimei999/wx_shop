package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.Goods;
import com.atguigu.crud.bean.GoodsExample;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.bean.GoodsExample.Criteria;
import com.atguigu.crud.dao.GoodsMapper;
import com.atguigu.crud.utils.DateUtil;


@Service
public class GoodsService {
	
	@Autowired
	GoodsMapper goodsMapper;

	/**
	 * 单个删除
	 * @param id
	 */
	public void delete(Integer id) {
		goodsMapper.deleteByPrimaryKey(id);
	}
	
	/**
	 * 批量删除
	 * @param ids
	 */
	public void deleteBatch(List<Integer> ids) {
		GoodsExample example = new GoodsExample();
		Criteria criteria = example.createCriteria();
		criteria.andIdIn(ids);
		goodsMapper.deleteByExample(example);
	}
	
	/**
	 * 更新
	 * @param goods
	 */
	public void update(Goods goods) {
		goodsMapper.updateByPrimaryKeySelective(goods);
	}

	/**
	 *  按照id查
	 * @param id
	 * @return
	 */
	public Goods get(Integer id) {
		return goodsMapper.selectByPrimaryKey(id);
	}

	/**
	 * 保存
	 * @param goods
	 */
	public void save(Goods goods) {
		String createAt = DateUtil.getNow();
		goods.setStartTime(createAt);
		goodsMapper.insertSelective(goods);
	}

	/**
	 * 查所有
	 * @return
	 */
	public List<Goods> getAll() {
		return goodsMapper.selectByExampleWithXX(null);
	}
	
	/**
	 * 条件查询
	 * @param user
	 * @return
	 */
	public List<Goods> listByObj(Goods user) {
		List<Goods> list = goodsMapper.listByObjGoods(user);
		return list;
	}


	/**
	 * 模糊查询--商品名称
	 * @param query
	 * @return
	 */
	public List<Goods> selectquery(String goodName){
		return goodsMapper.selectquery(goodName);
	}
	
	
}
