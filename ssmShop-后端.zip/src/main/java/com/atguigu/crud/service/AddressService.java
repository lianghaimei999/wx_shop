package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Address;
import com.atguigu.crud.bean.AddressExample;
import com.atguigu.crud.bean.Catelog;
import com.atguigu.crud.bean.AddressExample.Criteria;
import com.atguigu.crud.dao.AddressMapper;




@Service
public class AddressService {
	
	@Autowired
	AddressMapper addressMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Address> getAll() {
		// TODO Auto-generated method stub
		return addressMapper.selectByExample(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Address address) {
		// TODO Auto-generated method stub
		addressMapper.insertSelective(address);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Address get(Integer id) {
		Address address = addressMapper.selectByPrimaryKey(id);
		return address;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Address address) {
		addressMapper.updateByPrimaryKeySelective(address);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		addressMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		AddressExample example = new AddressExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andAdIdIn(ids);
		addressMapper.deleteByExample(example);
	}

	public List<Address> getxxId() {
		List<Address> list = addressMapper.selectByExample(null);
		return list;
	}
	
	

}
