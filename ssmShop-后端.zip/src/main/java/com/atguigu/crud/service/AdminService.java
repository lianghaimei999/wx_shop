package com.atguigu.crud.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Admin;
import com.atguigu.crud.bean.User;
import com.atguigu.crud.dao.AdminMapper;
import com.atguigu.crud.service.impl.ServiceBase;
import com.atguigu.crud.service.impl.ServiceBaseAdapter;

@Service
public class AdminService{
	
	@Autowired
	AdminMapper adminMapper;

	public Admin getUserByAccountAndPassword(String phone, String password) {
		
		return adminMapper.getPhonePwd(phone,password);
	}
}
