package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Image;
import com.atguigu.crud.bean.ImageExample;
import com.atguigu.crud.bean.ImageExample.Criteria;
import com.atguigu.crud.dao.ImageMapper;



@Service
public class ImgService {
	
	@Autowired
	ImageMapper imageMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Image> getAll() {
		// TODO Auto-generated method stub
		return imageMapper.selectByExample(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Image orders) {
		// TODO Auto-generated method stub
		imageMapper.insertSelective(orders);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Image get(Integer id) {
		Image orders = imageMapper.selectByPrimaryKey(id);
		return orders;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Image orders) {
		imageMapper.updateByPrimaryKeySelective(orders);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		imageMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		ImageExample example = new ImageExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		imageMapper.deleteByExample(example);
	}

}
