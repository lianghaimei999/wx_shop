package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Comments;
import com.atguigu.crud.bean.CommentsExample;
import com.atguigu.crud.bean.CommentsExample.Criteria;
import com.atguigu.crud.dao.CommentsMapper;
import com.atguigu.crud.utils.DateUtil;


@Service
public class CommentsService {
	
	@Autowired
	CommentsMapper commentsMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Comments> getAll() {
		// TODO Auto-generated method stub
		return commentsMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Comments com) {
		//String createAt = DateUtil.getNow();
		//com.setCreateAt(createAt);
		commentsMapper.insertSelective(com);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Comments get(Integer id) {
		Comments orders = commentsMapper.selectByPrimaryKey(id);
		return orders;
	}

	/**
	 * 更新
	 * @param orders
	 */
	public void update(Comments orders) {
		commentsMapper.updateByPrimaryKeySelective(orders);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void delete(Integer id) {
		commentsMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		CommentsExample example = new CommentsExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		commentsMapper.deleteByExample(example);
	}

}
