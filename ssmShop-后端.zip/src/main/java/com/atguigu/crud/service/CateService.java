package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Catelog;
import com.atguigu.crud.bean.CatelogExample;
import com.atguigu.crud.bean.Department;
import com.atguigu.crud.bean.CatelogExample.Criteria;
import com.atguigu.crud.dao.CatelogMapper;

@Service
public class CateService {
	
	@Autowired
	CatelogMapper catelogMapper;

	/**
	 * 查询所有员工
	 * @return
	 */
	public List<Catelog> getAll() {
		// TODO Auto-generated method stub
		return catelogMapper.selectByExample(null);
	}

	/**
	 * 保存
	 * @param cate
	 */
	public void saveEmp(Catelog cate) {
		// TODO Auto-generated method stub
		catelogMapper.insertSelective(cate);
	}


	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Catelog getEmp(Integer id) {
		Catelog cate = catelogMapper.selectByPrimaryKey(id);
		return cate;
	}

	/**
	 * 更新
	 * @param cate
	 */
	public void updateEmp(Catelog cate) {
		catelogMapper.updateByPrimaryKeySelective(cate);
	}

	/**
	 * 删除
	 * @param id
	 */
	public void deleteEmp(Integer id) {
		// TODO Auto-generated method stub
		catelogMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		// TODO Auto-generated method stub
		CatelogExample example = new CatelogExample();
		Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		catelogMapper.deleteByExample(example);
	}

	public void deleteId(Integer id) {
		// TODO Auto-generated method stub
		catelogMapper.deleteByPrimaryKey(id);
	}

	public void delete(Integer id) {
		catelogMapper.deleteByPrimaryKey(id);
	}

	public List<Catelog> get() {
		List<Catelog> list = catelogMapper.selectByExample(null);
		return list;
	}

	public List<Catelog> getXX() {
		 List<Catelog> cate = catelogMapper.selectByExample(null);
		return cate;
	}
}
