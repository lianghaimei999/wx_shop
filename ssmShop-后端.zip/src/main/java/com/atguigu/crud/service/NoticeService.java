package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.GoodsExample;
import com.atguigu.crud.bean.Notice;
import com.atguigu.crud.bean.NoticeExample;
import com.atguigu.crud.bean.Purse;
import com.atguigu.crud.bean.PurseExample;
import com.atguigu.crud.dao.NoticeMapper;
import com.atguigu.crud.dao.PurseMapper;
import com.atguigu.crud.utils.DateUtil;
import com.atguigu.crud.bean.PurseExample.Criteria;




@Service
public class NoticeService {
	
	@Autowired
	NoticeMapper noticeMapper;

	/**
	 * 查询所有
	 * @return
	 */
	public List<Notice> getAll() {
		// TODO Auto-generated method stub
		return noticeMapper.selectByExample(null);
	}
	
	public void deleteBatch(List<Integer> ids) {
		NoticeExample example = new NoticeExample();
		com.atguigu.crud.bean.NoticeExample.Criteria criteria = example.createCriteria();
		criteria.andIdIn(ids);
		noticeMapper.deleteByExample(example);
	}

	public void save(Notice goods) {
		String createAt = DateUtil.getNow();
		goods.setCreateAt(createAt);
		noticeMapper.insertSelective(goods);
		
	}

	public void delete(Integer id) {
		noticeMapper.deleteByPrimaryKey(id);
		
	}

	

}
