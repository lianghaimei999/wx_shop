package com.atguigu.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atguigu.crud.bean.Reply;
import com.atguigu.crud.bean.ReplyExample;

import com.atguigu.crud.dao.ReplyMapper;
import com.atguigu.crud.utils.DateUtil;


@Service
public class ReplyService {
	
	@Autowired
	ReplyMapper replyMapper;
	
	public void delete(Integer id) {
		replyMapper.deleteByPrimaryKey(id);
	}

	public void deleteBatch(List<Integer> ids) {
		ReplyExample example = new ReplyExample();
		com.atguigu.crud.bean.ReplyExample.Criteria criteria = example.createCriteria();
		//delete from xxx where emp_id in(1,2,3)
		criteria.andIdIn(ids);
		replyMapper.deleteByExample(example);
	}

	/**
	 * 查询所有
	 * @return
	 */
	public List<Reply> getAll() {
		// TODO Auto-generated method stub
		return replyMapper.selectByExampleWithXX(null);
	}

	/**
	 * 保存
	 * @param orders
	 */
	public void save(Reply orders) {
		// TODO Auto-generated method stub
		String createAt = DateUtil.getNow();
		orders.setCreateAt(createAt);
		replyMapper.insertSelective(orders);
	}

	
	/**
	 * 按照id查询
	 * @param id
	 * @return
	 */
	public Reply get(Integer id) {
		Reply orders = replyMapper.selectByPrimaryKey(id);
		return orders;
	}


}
